﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using sql = System.Data.SqlClient;

namespace BigProject
{
    public partial class User : Form
    {
        private bool isNew = false;
        private bool Inserting = false;
        private BindingManagerBase bmb;
        private MainForm myParent;
        DataSet ds;
        public User(MainForm Re)
        {
            InitializeComponent();
            myParent = Re;
        }
        #region SearchBoxVisibility
        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (sender == searchToolStripMenuItem)
            {
                lstSearch.Visible = true;
                searchToolStripMenuItem.Enabled = false;
                finishToolStripMenuItem.Enabled = true;
            }
            else
            {
                lstSearch.Visible = false;
                searchToolStripMenuItem.Enabled = true;
                finishToolStripMenuItem.Enabled = false;
            }
        }
        #endregion
        #region LoadIn
        private void User_Enter(object sender, EventArgs e)
        {
            myParent.toolStripStatusLabel4.Text = "You've entered the Users Form";
        }

        private void User_Leave(object sender, EventArgs e)
        {
            myParent.toolStripStatusLabel4.Text = "OK";
        }

        private void User_Load(object sender, EventArgs e)
        {
            try
            {
                string sqlstate = String.Format("SELECT * FROM Users ORDER BY DisplayName ASC;");
                ds = myParent.GetData(sqlstate, "Users");
                lstSearch.DataSource = ds;
                lstSearch.DisplayMember = "Users.DisplayName";
                lstSearch.ValueMember = "UserId";
                txtLast.DataBindings.Add("Text", ds, "Users.lastName");
                txtFirst.DataBindings.Add("Text", ds, "Users.firstName");
                txtEmail.DataBindings.Add("Text", ds, "Users.UserId");
                txtDisplay.DataBindings.Add("Text", ds, "Users.DisplayName");
                txtIdHold.Text = lstSearch.SelectedValue.ToString();
                chkParent.DataBindings.Add("Checked", ds, "Users.ParentalControl");
                ds.Tables[0].Columns["ParentalControl"].DefaultValue = false;
                bmb = BindingContext[ds, "Users"];
                myParent.toolStripStatusLabel3.Text = "Position " + (bmb.Position + 1) + " out of " + bmb.Count;
                bmb.PositionChanged += new EventHandler(myParent.bmb_PositionChanged);
                setButtons(false);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }
        #endregion
        #region Nav
        private void navigate_Click(object sender, EventArgs e)
        {
            {
                Button btnTemp = (Button)sender;
                switch (btnTemp.Name)
                {
                    case "btnFirst":
                        bmb.Position = 0;
                        break;
                    case "btnNext":
                        bmb.Position += 1;
                        break;
                    case "btnPrevious":
                        bmb.Position -= 1;
                        break;
                    case "btnLast":
                        bmb.Position = bmb.Count - 1;
                        break;
                }
            }
        }
        #endregion
        #region Validations
        private void txtLeave_Validating(object sender, CancelEventArgs e)
        {
            if (sender == txtFirst && txtFirst.Text == "")
            {
                errorProvider1.SetError(txtFirst, "This Field is Mandatory");
            }
            else if (sender == txtLast && txtLast.Text == "")
            {
                errorProvider1.SetError(txtLast, "This Field is Mandatory");
            }
            else if (sender == txtEmail && txtEmail.Text == "")
            {
                errorProvider1.SetError(txtEmail, "This Field is Mandatory");
            }
            else if (sender == txtEmail && !txtEmail.Text.Contains("@"))
            {
                errorProvider1.SetError(txtEmail, "Valid Email Required");
            }
            else if (sender == txtEmail && !isDupeEmail(txtEmail.Text) && isNew == true)
            {
                errorProvider1.SetError(txtEmail, "This Email Address is in Use");
            }
            else if (sender == txtDisplay && txtDisplay.Text == "")
            {
                errorProvider1.SetError(txtDisplay, "This Field is Mandatory");
            }
            else if (sender == txtDisplay && !isDupeDisplay(txtDisplay.Text) && isNew == true)
            {
                errorProvider1.SetError(txtDisplay, "This Display Name is in Use");
            }
            else
            {
                errorProvider1.SetError(txtFirst, "");
                errorProvider1.SetError(txtLast, "");
                errorProvider1.SetError(txtEmail, "");
                errorProvider1.SetError(txtDisplay, "");
            }
        }
        private bool isDupeEmail(string Email)
        {
                string sqlstate = String.Format("SELECT UserId FROM Users WHERE UserId ='{0}';", Email);
                DataSet ds = myParent.GetData(sqlstate, "Users");
                if ((int)ds.Tables[0].Rows.Count > 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
        }
        private bool isDupeDisplay(string Display)
        {
            string sqlstate = String.Format("SELECT DisplayName FROM Users WHERE DisplayName ='{0}';", Display);
            DataSet ds = myParent.GetData(sqlstate, "Users");
            if ((int)ds.Tables[0].Rows.Count > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        private bool isFormClean()
        {
            if (errorProvider1.GetError(txtDisplay) == "" && errorProvider1.GetError(txtEmail) == "" &&
                errorProvider1.GetError(txtFirst) == "" && errorProvider1.GetError(txtLast) == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private string fixString(string StringToFix)
        {
            string temp = StringToFix;
            for (int i = 0; i < temp.Length; i++)
            {
                if (temp[i] == (char)39)
                {
                    temp = temp.Insert(i, "'");
                    i++;
                }
            }
            return temp;
        }
        #endregion
        #region Maintenance
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (Inserting == true && isFormClean() == true)
                {
                    string sqlstate = String.Format("INSERT INTO Users (UserId, DisplayName, ParentalControl," +
                        " LastName, FirstName)VALUES ('{0}','{1}','{2}','{3}','{4}');", fixString(txtEmail.Text), fixString(txtDisplay.Text),
                        chkParent.Checked, fixString(txtLast.Text), fixString(txtFirst.Text));
                    myParent.SendData(sqlstate);
                    string sqlstateM = String.Format("SELECT * FROM Users ORDER BY DisplayName ASC;");
                    ds.Clear();
                    DataSet dsTemp = myParent.GetData(sqlstateM, "Users");
                    ds.Merge(dsTemp);
                    setButtons(false);
                    myParent.toolStripStatusLabel4.Text = "Ready...";
                    isNew = false;
                }
                else if (Inserting == false && isFormClean() == true)
                {
                    string sqlstate = String.Format("UPDATE Users SET DisplayName = '{0}'," +
                        " ParentalControl='{1}',LastName='{2}',FirstName='{3}' WHERE UserId = '{4}';",
                        fixString(txtDisplay.Text), chkParent.Checked, fixString(txtLast.Text), fixString(txtFirst.Text), lstSearch.SelectedValue);
                    myParent.SendData(sqlstate);
                    string sqlstateM = String.Format("SELECT * FROM Users ORDER BY DisplayName ASC;");
                    ds.Clear();
                    DataSet dsTemp = myParent.GetData(sqlstateM, "Users");
                    ds.Merge(dsTemp);
                    setButtons(false);
                    myParent.toolStripStatusLabel4.Text = "Ready...";
                    isNew = false;
                }
                else
                {
                    myParent.toolStripStatusLabel4.Text = "Please Fill Missing Fields, or Check For Errors on This Page.";
                    return;
                }
                Inserting = false;
                txtEmail.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            bmb.CancelCurrentEdit();
            bmb.Position = 0;
            myParent.toolStripStatusLabel3.Text = "Position " + (bmb.Position + 1) + " out of " + bmb.Count;
            setButtons(false);
            myParent.toolStripStatusLabel4.Text = "Ready...";
            isNew = false;
            Inserting = false;
            txtEmail.Enabled = false;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            myParent.toolStripStatusLabel4.Text = "Delete In Progress...";
            DialogResult Response = MessageBox.Show("Are You Sure You Want To Delete This?", "Delete", MessageBoxButtons.YesNo);
            if (Response == DialogResult.Yes)
            {
                try
                {
                    string sqlstateDel = String.Format("DELETE FROM Users WHERE UserId ='{0}';", lstSearch.SelectedValue.ToString());
                    myParent.SendData(sqlstateDel);
                    string sqlstate = String.Format("SELECT * FROM Users ORDER BY DisplayName ASC;");
                    ds.Clear();
                    DataSet dsTemp = myParent.GetData(sqlstate, "Users");
                    ds.Merge(dsTemp);
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("" + ex.Message.ToString());
                }
            }
            myParent.toolStripStatusLabel4.Text = "Ready...";
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            bmb.Position = bmb.Count - 1;
            myParent.toolStripStatusLabel3.Text = "Position " + (bmb.Position + 1) + " out of " + bmb.Count;
            setButtons(true);
            myParent.toolStripStatusLabel4.Text = "Add In Progress...";
            bmb.AddNew();
            Inserting = true;
            isNew = true;
            txtEmail.Enabled = true;
            lstSearch.Visible = false;
            txtFirst.Focus();
        }
        private void setButtons(Boolean state)
        {
            btnCreate.Visible = !state;
            btnDelete.Visible = !state;
            btnUpdate.Visible = state;
            btnCancel.Visible = state;
            btnNext.Enabled = !state;
            btnLast.Enabled = !state;
            btnPrevious.Enabled = !state;
            btnFirst.Enabled = !state;
            cntxtSearch.Enabled = !state;
        }
        private void fieldChanged(object sender, KeyEventArgs e)
        {
            setButtons(true);
            myParent.toolStripStatusLabel4.Text = "Update In Progress...";
        }

        private void chkParent_CheckedChanged(object sender, EventArgs e)
        {
            setButtons(true);
            myParent.toolStripStatusLabel4.Text = "Update In Progress...";
        }
        #endregion
    }
}
