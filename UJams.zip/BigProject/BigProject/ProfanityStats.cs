﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigProject
{
    public partial class ProfanityStats : Form
    {
        private MainForm myParent;
        DataSet Basic;
        private BindingManagerBase bmb;
        public ProfanityStats(MainForm Re)
        {
            InitializeComponent();
            myParent = Re;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            string sqlstate = String.Format("SELECT SongName,Genre FROM Users INNER JOIN PlaylistItems " +
                "ON Users.UserId=PlaylistItems.UserId INNER JOIN Songs ON PlaylistItems.SongId=Songs.SongId " +
                "WHERE Users.Userid='{0}' AND ExplicitTrack='1'", cmbChoice.SelectedValue);
            DataSet Basic = myParent.GetData(sqlstate, "Songs");
            dataGridView1.DataSource = Basic;
            dataGridView1.DataMember = "Songs";
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AutoSizeColumnsMode =
            DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.Columns[0].DefaultCellStyle.BackColor = Color.Salmon;
            dataGridView1.Columns[1].DefaultCellStyle.BackColor = Color.Salmon;
        }

        private void Inquiry3_Load(object sender, EventArgs e)
        {
            string sqlstate = String.Format("SELECT UserId, DisplayName FROM Users ORDER BY DisplayName ASC;");
            DataSet Basic = myParent.GetData(sqlstate, "Users");
            cmbChoice.DataSource = Basic;
            cmbChoice.DisplayMember = "Users.DisplayName";
            cmbChoice.ValueMember = "UserId";
        }
    }
}
