﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using sql = System.Data.SqlClient;

namespace BigProject
{
    public partial class Playlists : Form
    {
        private bool isNew = false;
        private bool Inserting = false;
        private BindingManagerBase bmb;
        private MainForm myParent;
        DataSet ds;
        public Playlists(MainForm Re)
        {
            InitializeComponent();
            myParent = Re;
        }
        #region PageStart
        private void Playlists_Load(object sender, EventArgs e)
        {

        }

        private void Playlists_Enter(object sender, EventArgs e)
        {
            myParent.toolStripStatusLabel4.Text = "You've entered the Playlists Form";
        }

        private void Playlists_Leave(object sender, EventArgs e)
        {
            myParent.toolStripStatusLabel4.Text = "O.K.";
        }
#endregion
        #region MenuButtons
        private void btnAddList_Click(object sender, EventArgs e)
        {
            btnAddNow.Visible = true;
            lblFirstSong.Visible = true;
            lblNewList.Visible = true;
            lblUserNew.Visible = true;
            cmbSongNew.Visible = true;
            cmbUserNameNew.Visible = true;
            txtNewListName.Visible = true;
            btnAddList.Visible = false;
            btnView.Visible = false;
            btnBackAdd.Visible = true;
            txtPrice.Visible = true;
            lblPrice.Visible = true;
            label1.Visible = true;
            string sqlstate = String.Format("SELECT DISTINCT UserId,DisplayName,ParentalControl FROM Users WHERE UserId NOT IN(SELECT UserId FROM PlaylistItems) ORDER BY DisplayName ASC;");
            ds = myParent.GetData(sqlstate, "Users");
            cmbUserNameNew.DataSource = ds;
            cmbUserNameNew.DisplayMember = "Users.DisplayName";
            cmbUserNameNew.ValueMember = "UserId";
        }
        private void btnView_Click(object sender, EventArgs e)
        {
            btnListNameEdit.Visible = true;
            btnDelSong.Visible = true;
            btnPlNameChange.Visible = false;
            lblUser.Visible = true;
            lblSongList.Visible = true;
            lblSongAdd.Visible = true;
            lblPlaylist.Visible = true;
            cmbSongToAdd.Visible = true;
            cmbUserName.Visible = true;
            lstSongList.Visible = true;
            btnAddList.Visible = false;
            txtPlaylistName.Visible = true;
            btnView.Visible = false;
            btnBackView.Visible = true;
            string sqlstate = String.Format("SELECT DISTINCT UserId,DisplayName FROM Users WHERE UserId IN(SELECT UserId FROM PlaylistItems) ORDER BY DisplayName ASC;");
            ds = myParent.GetData(sqlstate, "Users");
            cmbUserName.DataSource = ds;
            cmbUserName.DisplayMember = "Users.DisplayName";
            cmbUserName.ValueMember = "UserId";
            viewLoad();
        }

        private void btnBackView_Click(object sender, EventArgs e)
        {
            txtPrice.Visible = false;
            lblPrice.Visible = false;
            label1.Visible = false;
            btnListNameEdit.Visible = false;
            btnDelSong.Visible = false;
            btnAddSong.Visible = false;
            btnPlNameChange.Visible = false;
            lblUser.Visible = false;
            lblSongList.Visible = false;
            lblSongAdd.Visible = false;
            lblPlaylist.Visible = false;
            cmbSongToAdd.Visible = false;
            cmbUserName.Visible = false;
            lstSongList.Visible = false;
            btnAddList.Visible = true;
            txtPlaylistName.Visible = false;
            btnView.Visible = true;
            btnBackView.Visible = false;
            cmbUserName.DataSource = null;
            lstSongList.DataSource = null;
            txtPlaylistName.DataBindings.Clear();
            cmbSongToAdd.DataSource = null;
        }

        private void btnBackAdd_Click(object sender, EventArgs e)
        {
            txtPrice.Visible = false;
            lblPrice.Visible = false;
            label1.Visible = false;
            txtPrice.Text = "";
            lblFirstSong.Visible = false;
            lblNewList.Visible = false;
            lblUserNew.Visible = false;
            cmbSongNew.Visible = false;
            cmbUserNameNew.Visible = false;
            txtNewListName.Visible = false;
            btnAddList.Visible = true;
            btnView.Visible = true;
            btnBackAdd.Visible = false;
            btnDelSong.Visible = false;
            btnAddNow.Visible = false;
            cmbUserNameNew.DataSource = null;
            cmbSongNew.DataSource = null;
            txtNewListName.Text = "";
        }
        #endregion
        private void cmbUserName_SelectionChangeCommitted(object sender, EventArgs e)
        {
            viewLoad();
        }
        private void viewLoad()
        {
            string sqlstate = String.Format("SELECT PlaylistName,SongName,Songs.SongId FROM PlaylistItems INNER JOIN Songs ON PlaylistItems.SongId=Songs.SongId WHERE UserId='{0}' ORDER BY SongName ASC;", cmbUserName.SelectedValue);
            ds = myParent.GetData(sqlstate, "Playlists");
            lstSongList.DataSource = null;
            lstSongList.DataSource = ds;
            lstSongList.DisplayMember = "Playlists.SongName";
            lstSongList.ValueMember = "PlaylistItems.SongId";
            txtPlaylistName.DataBindings.Clear();
            txtPlaylistName.DataBindings.Add("Text", ds, "Playlists.PlaylistName");
            bmb = BindingContext[ds, "Playlists"];
            myParent.toolStripStatusLabel3.Text = "Position " + (bmb.Position + 1) + " out of " + bmb.Count;
            bmb.PositionChanged += new EventHandler(myParent.bmb_PositionChanged);
            string sqlstateC = String.Format("SELECT SongId, SongName FROM Songs WHERE SongId NOT IN(SELECT SongID FROM PlaylistItems WHERE UserId='{0}')ORDER BY SongName ASC;", cmbUserName.SelectedValue);
            DataSet Combo = myParent.GetData(sqlstateC, "Songs");
            cmbSongToAdd.DataSource = Combo;
            cmbSongToAdd.DisplayMember = "Songs.SongName";
            cmbSongToAdd.ValueMember = "SongId";
        }
        #region Buttons
        private void btnAddNow_Click(object sender, EventArgs e)
        {if (txtNewListName.Text!=""&&cmbSongNew.Text!="")
            {
                string sqlstate = String.Format("INSERT INTO PlaylistItems (UserId,SongId,PlaylistName,ChargedPrice) VALUES('{0}','{1}','{2}','{3}');",cmbUserNameNew.SelectedValue,cmbSongNew.SelectedValue,fixString(txtNewListName.Text),txtPrice.Text);
                myParent.SendData(sqlstate);
                myParent.toolStripStatusLabel4.Text = "Ready...";
            }
            else
            {
                MessageBox.Show("Please Ensure All Fields Are Filled Out.");
                return;
            }
            lblFirstSong.Visible = false;
            lblNewList.Visible = false;
            lblUserNew.Visible = false;
            cmbSongNew.Visible = false;
            cmbUserNameNew.Visible = false;
            txtNewListName.Visible = false;
            btnAddList.Visible = true;
            btnView.Visible = true;
            btnBackAdd.Visible = false;
            btnAddSong.Visible = false;
            btnPlNameChange.Visible = false;
            btnAddNow.Visible = false;
            cmbUserNameNew.DataSource = null;
            cmbSongNew.DataSource = null;
            txtNewListName.Text = "";
            txtPrice.Visible = false;
            lblPrice.Visible = false;
            label1.Visible = false;
        }

        private void cmbUserNameNew_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows[cmbUserNameNew.SelectedIndex]["ParentalControl"].ToString() == "True")
            {
                string sqlstateS = String.Format("SELECT SongId,SongName,SongPrice FROM Songs WHERE ExplicitTrack='False' ORDER BY SongName ASC;");
                DataSet dsN = myParent.GetData(sqlstateS, "Songs");
                cmbSongNew.DataSource = dsN;
                cmbSongNew.DisplayMember = "Songs.SongName";
                cmbSongNew.ValueMember = "SongId";
                txtPrice.DataBindings.Clear();
                txtPrice.DataBindings.Add("Text", dsN, "Songs.SongPrice");
            }
            else
            {
                string sqlstateS = String.Format("SELECT SongId,SongName,SongPrice FROM Songs ORDER BY SongName ASC;");
                DataSet dsN = myParent.GetData(sqlstateS, "Songs");
                cmbSongNew.DataSource = dsN;
                cmbSongNew.DisplayMember = "Songs.SongName";
                cmbSongNew.ValueMember = "SongId";
                txtPrice.DataBindings.Clear();
                txtPrice.DataBindings.Add("Text", dsN, "Songs.SongPrice");
            }
        }
        private void btnPlNameChange_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlstate = String.Format("UPDATE PlaylistItems SET PlaylistName = '{0}' WHERE UserId = '{1}';", fixString(txtPlaylistName.Text), cmbUserName.SelectedValue);
                myParent.SendData(sqlstate);
                myParent.toolStripStatusLabel4.Text = "Ready...";
                btnPlNameChange.Visible = false;
                txtPlaylistName.Enabled = false;
                btnListNameEdit.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private void btnAddSong_Click(object sender, EventArgs e)
        {
            try
            {
                string sqlstate = String.Format("INSERT INTO PlaylistItems (UserId,SongId,PlaylistName,ChargedPrice) VALUES('{0}','{1}','{2}','{3}');", cmbUserName.SelectedValue, cmbSongToAdd.SelectedValue, fixString(txtPlaylistName.Text),txtPrice.Text);
                myParent.SendData(sqlstate);
                string sqlstateM = String.Format("SELECT PlaylistName,SongName,Songs.SongId FROM PlaylistItems INNER JOIN Songs ON PlaylistItems.SongId=Songs.SongId WHERE UserId='{0}' ORDER BY SongName ASC;", cmbUserName.SelectedValue);
                ds.Clear();
                DataSet dsTemp = myParent.GetData(sqlstateM, "Playlists");
                ds.Merge(dsTemp);
                string sqlstateC = String.Format("SELECT SongId, SongName FROM Songs WHERE SongId NOT IN(SELECT SongID FROM PlaylistItems WHERE UserId='{0}')ORDER BY SongName ASC;", cmbUserName.SelectedValue);
                DataSet Combo = myParent.GetData(sqlstateC, "Songs");
                cmbSongToAdd.DataSource = Combo;
                cmbSongToAdd.DisplayMember = "Songs.SongName";
                cmbSongToAdd.ValueMember = "SongId";
                myParent.toolStripStatusLabel4.Text = "Ready...";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
            if (lstSongList.Items.Count % 6==0)
            {
                MessageBox.Show(cmbUserName.Text.ToString() + " Has Purchased Six Songs, Their Next Song is Free!");
            }
            btnAddSong.Visible = false;
            txtPrice.Visible = false;
            lblPrice.Visible = false;
            label1.Visible = false;
        }

        private void btnDelSong_Click(object sender, EventArgs e)
        {
            if (lstSongList.Items.Count == 1)
            {
                myParent.toolStripStatusLabel4.Text = "Delete In Progress...";
                DialogResult Warn = MessageBox.Show("This Will Delete The Entire Playlist, Continue?", "Delete", MessageBoxButtons.YesNo);
                if (Warn == DialogResult.Yes)
                {
                    try
                    {
                        string sqlstateDel = String.Format("DELETE FROM PlaylistItems WHERE SongId ='{0}' AND UserId='{1}';", lstSongList.SelectedValue, cmbUserName.SelectedValue);
                        myParent.SendData(sqlstateDel);
                        string sqlstate = String.Format("SELECT DISTINCT UserId,DisplayName FROM Users WHERE UserId IN(SELECT UserId FROM PlaylistItems) ORDER BY DisplayName ASC;");
                        ds.Clear();
                        DataSet dsTemp = myParent.GetData(sqlstate, "Users");
                        ds.Merge(dsTemp);
                        cmbUserName.DataSource = null;
                        cmbUserName.DataSource = ds;
                        cmbUserName.DisplayMember = "Users.DisplayName";
                        cmbUserName.ValueMember = "UserId";
                        viewLoad();
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show("" + ex.Message.ToString());
                    }
                }
                myParent.toolStripStatusLabel4.Text = "Ready...";
                return;
            }
            else
            {
                myParent.toolStripStatusLabel4.Text = "Delete In Progress...";
                DialogResult Response = MessageBox.Show("Are You Sure You Want To Delete This?", "Delete", MessageBoxButtons.YesNo);
                if (Response == DialogResult.Yes)
                {
                    try
                    {
                        string sqlstateDel = String.Format("DELETE FROM PlaylistItems WHERE SongId ='{0}' AND UserId='{1}';", lstSongList.SelectedValue, cmbUserName.SelectedValue);
                        myParent.SendData(sqlstateDel);
                        string sqlstate = String.Format("SELECT PlaylistName,SongName,Songs.SongId FROM PlaylistItems INNER JOIN Songs ON PlaylistItems.SongId=Songs.SongId WHERE UserId='{0}' ORDER BY SongName ASC;", cmbUserName.SelectedValue);
                        ds.Clear();
                        DataSet dsTemp = myParent.GetData(sqlstate, "Playlists");
                        ds.Merge(dsTemp);
                        string sqlstateC = String.Format("SELECT SongId, SongName FROM Songs WHERE SongId NOT IN(SELECT SongID FROM PlaylistItems WHERE UserId='{0}')ORDER BY SongName ASC;", cmbUserName.SelectedValue);
                        DataSet Combo = myParent.GetData(sqlstateC, "Songs");
                        cmbSongToAdd.DataSource = Combo;
                        cmbSongToAdd.DisplayMember = "Songs.SongName";
                        cmbSongToAdd.ValueMember = "SongId";
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show("" + ex.Message.ToString());
                    }
                }
                myParent.toolStripStatusLabel4.Text = "Ready...";
            }
            }
        private void btnListNameEdit_Click(object sender, EventArgs e)
        {
            btnPlNameChange.Visible = true;
            txtPlaylistName.Enabled = true;
            btnListNameEdit.Visible = false;
        }
        #endregion
        private string fixString(string StringToFix)
        {
            string temp = StringToFix;
            for (int i = 0; i < temp.Length; i++)
            {
                if (temp[i] == (char)39)
                {
                    temp = temp.Insert(i, "'");
                    i++;
                }
            }
            return temp;
        }

        private void cmbSongToAdd_SelectionChangeCommitted(object sender, EventArgs e)
        {
            btnAddSong.Visible = true;
            txtPrice.Visible = true;
            lblPrice.Visible = true;
            label1.Visible = true;
            try
            {
                string sqlstate = String.Format("SELECT SongPrice FROM Songs WHERE SongId='{0}';", cmbSongToAdd.SelectedValue);
                DataSet ds = myParent.GetData(sqlstate, "Songs");
                txtPrice.DataBindings.Clear();
                txtPrice.DataBindings.Add("Text", ds, "Songs.SongPrice");
                if (lstSongList.Items.Count % 6 == 0)
                {
                    txtPrice.Text = "0.00";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }

        }
    }
}
