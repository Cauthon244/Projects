﻿namespace BigProject
{
    partial class Playlists
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddList = new System.Windows.Forms.Button();
            this.btnView = new System.Windows.Forms.Button();
            this.lstSongList = new System.Windows.Forms.ListBox();
            this.lblSongList = new System.Windows.Forms.Label();
            this.cmbUserName = new System.Windows.Forms.ComboBox();
            this.lblUser = new System.Windows.Forms.Label();
            this.txtPlaylistName = new System.Windows.Forms.TextBox();
            this.lblPlaylist = new System.Windows.Forms.Label();
            this.cmbSongToAdd = new System.Windows.Forms.ComboBox();
            this.lblSongAdd = new System.Windows.Forms.Label();
            this.cmbUserNameNew = new System.Windows.Forms.ComboBox();
            this.cmbSongNew = new System.Windows.Forms.ComboBox();
            this.txtNewListName = new System.Windows.Forms.TextBox();
            this.lblUserNew = new System.Windows.Forms.Label();
            this.lblFirstSong = new System.Windows.Forms.Label();
            this.lblNewList = new System.Windows.Forms.Label();
            this.btnBackAdd = new System.Windows.Forms.Button();
            this.btnBackView = new System.Windows.Forms.Button();
            this.btnAddNow = new System.Windows.Forms.Button();
            this.btnAddSong = new System.Windows.Forms.Button();
            this.btnPlNameChange = new System.Windows.Forms.Button();
            this.btnDelSong = new System.Windows.Forms.Button();
            this.btnListNameEdit = new System.Windows.Forms.Button();
            this.lblPrice = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAddList
            // 
            this.btnAddList.Location = new System.Drawing.Point(192, 127);
            this.btnAddList.Name = "btnAddList";
            this.btnAddList.Size = new System.Drawing.Size(150, 75);
            this.btnAddList.TabIndex = 0;
            this.btnAddList.Text = "Add A Playlist";
            this.btnAddList.UseVisualStyleBackColor = true;
            this.btnAddList.Click += new System.EventHandler(this.btnAddList_Click);
            // 
            // btnView
            // 
            this.btnView.Location = new System.Drawing.Point(192, 219);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(150, 75);
            this.btnView.TabIndex = 1;
            this.btnView.Text = "View Exisiting Lists";
            this.btnView.UseVisualStyleBackColor = true;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // lstSongList
            // 
            this.lstSongList.FormattingEnabled = true;
            this.lstSongList.ItemHeight = 16;
            this.lstSongList.Location = new System.Drawing.Point(185, 147);
            this.lstSongList.Name = "lstSongList";
            this.lstSongList.Size = new System.Drawing.Size(174, 244);
            this.lstSongList.TabIndex = 2;
            this.lstSongList.Visible = false;
            // 
            // lblSongList
            // 
            this.lblSongList.AutoSize = true;
            this.lblSongList.Location = new System.Drawing.Point(224, 127);
            this.lblSongList.Name = "lblSongList";
            this.lblSongList.Size = new System.Drawing.Size(100, 17);
            this.lblSongList.TabIndex = 3;
            this.lblSongList.Text = "Song\'s On List";
            this.lblSongList.Visible = false;
            // 
            // cmbUserName
            // 
            this.cmbUserName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUserName.FormattingEnabled = true;
            this.cmbUserName.Location = new System.Drawing.Point(12, 168);
            this.cmbUserName.Name = "cmbUserName";
            this.cmbUserName.Size = new System.Drawing.Size(167, 24);
            this.cmbUserName.TabIndex = 4;
            this.cmbUserName.Visible = false;
            this.cmbUserName.SelectionChangeCommitted += new System.EventHandler(this.cmbUserName_SelectionChangeCommitted);
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(59, 148);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(75, 17);
            this.lblUser.TabIndex = 5;
            this.lblUser.Text = "UserName";
            this.lblUser.Visible = false;
            // 
            // txtPlaylistName
            // 
            this.txtPlaylistName.Enabled = false;
            this.txtPlaylistName.Location = new System.Drawing.Point(185, 85);
            this.txtPlaylistName.MaxLength = 20;
            this.txtPlaylistName.Name = "txtPlaylistName";
            this.txtPlaylistName.Size = new System.Drawing.Size(174, 22);
            this.txtPlaylistName.TabIndex = 6;
            this.txtPlaylistName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPlaylistName.Visible = false;
            // 
            // lblPlaylist
            // 
            this.lblPlaylist.AutoSize = true;
            this.lblPlaylist.Location = new System.Drawing.Point(224, 65);
            this.lblPlaylist.Name = "lblPlaylist";
            this.lblPlaylist.Size = new System.Drawing.Size(89, 17);
            this.lblPlaylist.TabIndex = 7;
            this.lblPlaylist.Text = "PlaylistName";
            this.lblPlaylist.Visible = false;
            // 
            // cmbSongToAdd
            // 
            this.cmbSongToAdd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSongToAdd.FormattingEnabled = true;
            this.cmbSongToAdd.Location = new System.Drawing.Point(365, 168);
            this.cmbSongToAdd.Name = "cmbSongToAdd";
            this.cmbSongToAdd.Size = new System.Drawing.Size(165, 24);
            this.cmbSongToAdd.TabIndex = 8;
            this.cmbSongToAdd.Visible = false;
            this.cmbSongToAdd.SelectionChangeCommitted += new System.EventHandler(this.cmbSongToAdd_SelectionChangeCommitted);
            // 
            // lblSongAdd
            // 
            this.lblSongAdd.AutoSize = true;
            this.lblSongAdd.Location = new System.Drawing.Point(405, 148);
            this.lblSongAdd.Name = "lblSongAdd";
            this.lblSongAdd.Size = new System.Drawing.Size(82, 17);
            this.lblSongAdd.TabIndex = 9;
            this.lblSongAdd.Text = "Add a Song";
            this.lblSongAdd.Visible = false;
            // 
            // cmbUserNameNew
            // 
            this.cmbUserNameNew.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUserNameNew.FormattingEnabled = true;
            this.cmbUserNameNew.Location = new System.Drawing.Point(209, 58);
            this.cmbUserNameNew.Name = "cmbUserNameNew";
            this.cmbUserNameNew.Size = new System.Drawing.Size(125, 24);
            this.cmbUserNameNew.TabIndex = 10;
            this.cmbUserNameNew.Visible = false;
            this.cmbUserNameNew.SelectionChangeCommitted += new System.EventHandler(this.cmbUserNameNew_SelectionChangeCommitted);
            // 
            // cmbSongNew
            // 
            this.cmbSongNew.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSongNew.FormattingEnabled = true;
            this.cmbSongNew.Location = new System.Drawing.Point(210, 127);
            this.cmbSongNew.Name = "cmbSongNew";
            this.cmbSongNew.Size = new System.Drawing.Size(125, 24);
            this.cmbSongNew.TabIndex = 11;
            this.cmbSongNew.Visible = false;
            // 
            // txtNewListName
            // 
            this.txtNewListName.Location = new System.Drawing.Point(209, 191);
            this.txtNewListName.MaxLength = 20;
            this.txtNewListName.Name = "txtNewListName";
            this.txtNewListName.Size = new System.Drawing.Size(125, 22);
            this.txtNewListName.TabIndex = 12;
            this.txtNewListName.Visible = false;
            // 
            // lblUserNew
            // 
            this.lblUserNew.AutoSize = true;
            this.lblUserNew.Location = new System.Drawing.Point(234, 38);
            this.lblUserNew.Name = "lblUserNew";
            this.lblUserNew.Size = new System.Drawing.Size(79, 17);
            this.lblUserNew.TabIndex = 13;
            this.lblUserNew.Text = "User Name";
            this.lblUserNew.Visible = false;
            // 
            // lblFirstSong
            // 
            this.lblFirstSong.AutoSize = true;
            this.lblFirstSong.Location = new System.Drawing.Point(211, 107);
            this.lblFirstSong.Name = "lblFirstSong";
            this.lblFirstSong.Size = new System.Drawing.Size(124, 17);
            this.lblFirstSong.TabIndex = 14;
            this.lblFirstSong.Text = "Choose First Song";
            this.lblFirstSong.Visible = false;
            // 
            // lblNewList
            // 
            this.lblNewList.AutoSize = true;
            this.lblNewList.Location = new System.Drawing.Point(224, 171);
            this.lblNewList.Name = "lblNewList";
            this.lblNewList.Size = new System.Drawing.Size(93, 17);
            this.lblNewList.TabIndex = 15;
            this.lblNewList.Text = "Playlist Name";
            this.lblNewList.Visible = false;
            // 
            // btnBackAdd
            // 
            this.btnBackAdd.Location = new System.Drawing.Point(408, 345);
            this.btnBackAdd.Name = "btnBackAdd";
            this.btnBackAdd.Size = new System.Drawing.Size(107, 46);
            this.btnBackAdd.TabIndex = 16;
            this.btnBackAdd.Text = "Go Back";
            this.btnBackAdd.UseVisualStyleBackColor = true;
            this.btnBackAdd.Visible = false;
            this.btnBackAdd.Click += new System.EventHandler(this.btnBackAdd_Click);
            // 
            // btnBackView
            // 
            this.btnBackView.Location = new System.Drawing.Point(408, 345);
            this.btnBackView.Name = "btnBackView";
            this.btnBackView.Size = new System.Drawing.Size(107, 46);
            this.btnBackView.TabIndex = 17;
            this.btnBackView.Text = "Go Back";
            this.btnBackView.UseVisualStyleBackColor = true;
            this.btnBackView.Visible = false;
            this.btnBackView.Click += new System.EventHandler(this.btnBackView_Click);
            // 
            // btnAddNow
            // 
            this.btnAddNow.Location = new System.Drawing.Point(217, 233);
            this.btnAddNow.Name = "btnAddNow";
            this.btnAddNow.Size = new System.Drawing.Size(107, 46);
            this.btnAddNow.TabIndex = 18;
            this.btnAddNow.Text = "Add Now";
            this.btnAddNow.UseVisualStyleBackColor = true;
            this.btnAddNow.Visible = false;
            this.btnAddNow.Click += new System.EventHandler(this.btnAddNow_Click);
            // 
            // btnAddSong
            // 
            this.btnAddSong.Location = new System.Drawing.Point(399, 198);
            this.btnAddSong.Name = "btnAddSong";
            this.btnAddSong.Size = new System.Drawing.Size(103, 26);
            this.btnAddSong.TabIndex = 19;
            this.btnAddSong.Text = "Add Song";
            this.btnAddSong.UseVisualStyleBackColor = true;
            this.btnAddSong.Visible = false;
            this.btnAddSong.Click += new System.EventHandler(this.btnAddSong_Click);
            // 
            // btnPlNameChange
            // 
            this.btnPlNameChange.Location = new System.Drawing.Point(12, 83);
            this.btnPlNameChange.Name = "btnPlNameChange";
            this.btnPlNameChange.Size = new System.Drawing.Size(162, 27);
            this.btnPlNameChange.TabIndex = 20;
            this.btnPlNameChange.Text = "Change Playlist Name";
            this.btnPlNameChange.UseVisualStyleBackColor = true;
            this.btnPlNameChange.Visible = false;
            this.btnPlNameChange.Click += new System.EventHandler(this.btnPlNameChange_Click);
            // 
            // btnDelSong
            // 
            this.btnDelSong.Location = new System.Drawing.Point(71, 198);
            this.btnDelSong.Name = "btnDelSong";
            this.btnDelSong.Size = new System.Drawing.Size(103, 26);
            this.btnDelSong.TabIndex = 21;
            this.btnDelSong.Text = "Delete Song";
            this.btnDelSong.UseVisualStyleBackColor = true;
            this.btnDelSong.Visible = false;
            this.btnDelSong.Click += new System.EventHandler(this.btnDelSong_Click);
            // 
            // btnListNameEdit
            // 
            this.btnListNameEdit.Location = new System.Drawing.Point(40, 299);
            this.btnListNameEdit.Name = "btnListNameEdit";
            this.btnListNameEdit.Size = new System.Drawing.Size(103, 59);
            this.btnListNameEdit.TabIndex = 22;
            this.btnListNameEdit.Text = "Edit Playlist Name";
            this.btnListNameEdit.UseVisualStyleBackColor = true;
            this.btnListNameEdit.Visible = false;
            this.btnListNameEdit.Click += new System.EventHandler(this.btnListNameEdit_Click);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(418, 237);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(40, 17);
            this.lblPrice.TabIndex = 61;
            this.lblPrice.Text = "Price";
            this.lblPrice.Visible = false;
            // 
            // txtPrice
            // 
            this.txtPrice.Enabled = false;
            this.txtPrice.Location = new System.Drawing.Point(408, 257);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(65, 22);
            this.txtPrice.TabIndex = 60;
            this.txtPrice.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(396, 260);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 62;
            this.label1.Text = "$";
            this.label1.Visible = false;
            // 
            // Playlists
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 403);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnListNameEdit);
            this.Controls.Add(this.btnDelSong);
            this.Controls.Add(this.btnPlNameChange);
            this.Controls.Add(this.btnAddSong);
            this.Controls.Add(this.btnAddNow);
            this.Controls.Add(this.btnBackView);
            this.Controls.Add(this.btnBackAdd);
            this.Controls.Add(this.lblNewList);
            this.Controls.Add(this.lblFirstSong);
            this.Controls.Add(this.lblUserNew);
            this.Controls.Add(this.txtNewListName);
            this.Controls.Add(this.cmbSongNew);
            this.Controls.Add(this.cmbUserNameNew);
            this.Controls.Add(this.lblSongAdd);
            this.Controls.Add(this.cmbSongToAdd);
            this.Controls.Add(this.lblPlaylist);
            this.Controls.Add(this.txtPlaylistName);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.cmbUserName);
            this.Controls.Add(this.lblSongList);
            this.Controls.Add(this.lstSongList);
            this.Controls.Add(this.btnView);
            this.Controls.Add(this.btnAddList);
            this.Name = "Playlists";
            this.Text = "Playlists";
            this.Load += new System.EventHandler(this.Playlists_Load);
            this.Enter += new System.EventHandler(this.Playlists_Enter);
            this.Leave += new System.EventHandler(this.Playlists_Leave);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddList;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.ListBox lstSongList;
        private System.Windows.Forms.Label lblSongList;
        private System.Windows.Forms.ComboBox cmbUserName;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.TextBox txtPlaylistName;
        private System.Windows.Forms.Label lblPlaylist;
        private System.Windows.Forms.ComboBox cmbSongToAdd;
        private System.Windows.Forms.Label lblSongAdd;
        private System.Windows.Forms.ComboBox cmbUserNameNew;
        private System.Windows.Forms.ComboBox cmbSongNew;
        private System.Windows.Forms.TextBox txtNewListName;
        private System.Windows.Forms.Label lblUserNew;
        private System.Windows.Forms.Label lblFirstSong;
        private System.Windows.Forms.Label lblNewList;
        private System.Windows.Forms.Button btnBackAdd;
        private System.Windows.Forms.Button btnBackView;
        private System.Windows.Forms.Button btnAddNow;
        private System.Windows.Forms.Button btnAddSong;
        private System.Windows.Forms.Button btnPlNameChange;
        private System.Windows.Forms.Button btnDelSong;
        private System.Windows.Forms.Button btnListNameEdit;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label label1;
    }
}