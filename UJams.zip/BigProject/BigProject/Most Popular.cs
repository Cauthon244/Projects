﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigProject
{
    public partial class Inquiry1 : Form
    {
        private MainForm myParent;
        private BindingManagerBase bmb;
        public Inquiry1(MainForm Re)
        {
            InitializeComponent();
            myParent = Re;
        }

        private void Inquiry1_Load(object sender, EventArgs e)
        {
            string sqlstate = String.Format("SELECT SongId, SongName FROM Songs ORDER BY SongName ASC;");
            DataSet Basic = myParent.GetData(sqlstate, "Songs");
            cmbChoice.DataSource = Basic;
            cmbChoice.DisplayMember = "Songs.SongName";
            cmbChoice.ValueMember = "SongId";
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            string sqlstate = String.Format("SELECT COUNT(PlaylistItems.SongId)AS 'People Listening', SongName FROM PlaylistItems INNER JOIN Songs ON PlaylistItems.SongId=Songs.SongId WHERE Songs.SongId='{0}' GROUP BY SongName ORDER BY [People Listening] DESC;", cmbChoice.SelectedValue);
            DataSet Basic = myParent.GetData(sqlstate, "Songs");
            dataGridView1.DataSource = Basic;
            dataGridView1.DataMember = "Songs";
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AutoSizeColumnsMode =
            DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.Columns[0].DefaultCellStyle.BackColor = Color.LightGreen;
            dataGridView1.Columns[1].DefaultCellStyle.BackColor = Color.LightGreen;
        }

        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            string sqlstate = String.Format("SELECT COUNT(PlaylistItems.SongId)AS 'People Listening', SongName FROM PlaylistItems INNER JOIN Songs ON PlaylistItems.SongId=Songs.SongId WHERE Songs.SongId IN (SELECT SongId FROM PlaylistItems) GROUP BY SongName ORDER BY [People Listening] DESC;");
            DataSet Basic = myParent.GetData(sqlstate, "Songs");
            dataGridView1.DataSource = Basic;
            dataGridView1.DataMember = "Songs";
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AutoSizeColumnsMode =
            DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.Columns[0].DefaultCellStyle.BackColor = Color.LightGreen;
            dataGridView1.Columns[1].DefaultCellStyle.BackColor = Color.LightGreen;
        }
    }
}
