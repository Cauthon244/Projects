﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using sql = System.Data.SqlClient;

namespace BigProject
{
    public partial class Songs : Form
    {
        private bool isNew = false;
        private bool Inserting = false;
        private MainForm myParent;
        DataSet ds;
        private BindingManagerBase bmb;
        public Songs(MainForm Re)
        {
            InitializeComponent();
            myParent = Re;
        }
        #region LoadIns
        private void Songs_Load(object sender, EventArgs e)
        {
            try
            {
                string sqlstate = String.Format("SELECT * FROM Songs ORDER BY SongName ASC;");
                ds = myParent.GetData(sqlstate, "Songs");
                lstSongs.DataSource = ds;
                loadBox();
                lstSongs.DisplayMember = "Songs.SongName";
                lstSongs.ValueMember = "SongId";
                txtSongName.DataBindings.Add("Text", ds, "Songs.SongName");
                txtArtist.DataBindings.Add("Text", ds, "Songs.ArtistName");
                txtLength.DataBindings.Add("Text", ds, "Songs.TrackLength");
                txtPrice.DataBindings.Add("Text", ds, "Songs.SongPrice");
                txtExplicit.DataBindings.Add("Text", ds, "Songs.ExplicitTrack");
                dtpRelease.DataBindings.Add("Text", ds, "Songs.ReleaseDate");
                CheckExplicit(txtExplicit.Text);
                bmb = BindingContext[ds, "Songs"];
                ds.Tables["Songs"].Columns["ExplicitTrack"].DefaultValue = false;
                myParent.toolStripStatusLabel3.Text = "Position " + (bmb.Position + 1) + " out of " + bmb.Count;
                bmb.PositionChanged += new EventHandler(myParent.bmb_PositionChanged);
                cmbGenre.DataBindings.Add("Text", ds, "Songs.Genre");
                cmbGenre.DataBindings.Add("SelectedItem", ds, "Songs.Genre");
                setButtons(false);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }
        private void loadBox()
        {
            cmbGenre.Items.Add("Rock");
            cmbGenre.Items.Add("Rap");
            cmbGenre.Items.Add("Country");
            cmbGenre.Items.Add("Dance");
        }

        private void Songs_Enter(object sender, EventArgs e)
        {
            myParent.toolStripStatusLabel4.Text = "You've entered the Songs Form";
        }

        private void Songs_Leave(object sender, EventArgs e)
        {
            myParent.toolStripStatusLabel4.Text = "OK";
        }
        private void CheckExplicit(string Explicit)
        {
            if (Explicit == "True")
            {
                rdoYes.Checked = true;
            }
            else if (Explicit == "False")
            {
                rdoNo.Checked = true;
            }
        }

        private void txtExplicit_TextChanged(object sender, EventArgs e)
        {
            CheckExplicit(txtExplicit.Text);
        }

        private void rdoExplicit_Click(object sender, EventArgs e)
        {
            if (sender == rdoNo)
            {
                txtExplicit.Text = "False";
                setButtons(true);
                myParent.toolStripStatusLabel4.Text = "Update In Progress...";
            }
            else if (sender == rdoYes)
            {
                txtExplicit.Text = "True";
                setButtons(true);
                myParent.toolStripStatusLabel4.Text = "Update In Progress...";
            }
        }
        #endregion
        #region Maintenance
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (Inserting == true && isFormClean() == true)
                {
                    string sqlstate = String.Format("INSERT INTO Songs (SongName, ArtistName," +
                        " TrackLength, ExplicitTrack,Genre,SongPrice,ReleaseDate)VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}');", fixString(txtSongName.Text), fixString(txtArtist.Text)
                        , fixString(txtLength.Text), fixString(txtExplicit.Text), cmbGenre.Text, fixString(txtPrice.Text), dtpRelease.Value);
                    myParent.SendData(sqlstate);
                    string sqlstateM = String.Format("SELECT * FROM Songs ORDER BY SongName ASC;");
                    ds.Clear();
                    DataSet dsTemp = myParent.GetData(sqlstateM, "Songs");
                    ds.Merge(dsTemp);
                    setButtons(false);
                    myParent.toolStripStatusLabel4.Text = "Ready...";
                    isNew = false;
                }
                else if (Inserting == false && isFormClean() == true)
                {
                    string sqlstate = String.Format("UPDATE Songs SET SongName = '{0}'," +
                        " ArtistName='{1}',TrackLength='{2}',ExplicitTrack='{3}',Genre='{4}',SongPrice='{5}',ReleaseDate='{6}'" +
                        " WHERE SongId = '{7}';", fixString(txtSongName.Text), fixString(txtArtist.Text)
                        , fixString(txtLength.Text), fixString(txtExplicit.Text), cmbGenre.Text, fixString(txtPrice.Text), dtpRelease.Value, lstSongs.SelectedValue);
                    myParent.SendData(sqlstate);
                    string sqlstateM = String.Format("SELECT * FROM Songs ORDER BY SongName ASC;");
                    ds.Clear();
                    DataSet dsTemp = myParent.GetData(sqlstateM, "Songs");
                    ds.Merge(dsTemp);
                    setButtons(false);
                    myParent.toolStripStatusLabel4.Text = "Ready...";
                    isNew = false;
                }
                else
                {
                    myParent.toolStripStatusLabel4.Text = "Please Fill Missing Fields, or Check For Errors on This Page.";
                    return;
                }
                Inserting = false;
                lstSongs.Visible = true;
                lblChoice.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            bmb.CancelCurrentEdit();
            bmb.Position = 0;
            myParent.toolStripStatusLabel3.Text = "Position " + (bmb.Position + 1) + " out of " + bmb.Count;
            setButtons(false);
            myParent.toolStripStatusLabel4.Text = "Ready...";
            isNew = false;
            Inserting = false;
            lstSongs.Visible = true;
            lblChoice.Visible = true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            bmb.Position = bmb.Count - 1;
            myParent.toolStripStatusLabel3.Text = "Position " + (bmb.Position + 1) + " out of " + bmb.Count;
            setButtons(true);
            myParent.toolStripStatusLabel4.Text = "Add In Progress...";
            bmb.AddNew();
            Inserting = true;
            isNew = true;
            lstSongs.Visible = false;
            lblChoice.Visible = false; ;
            txtSongName.Focus();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            myParent.toolStripStatusLabel4.Text = "Delete In Progress...";
            DialogResult Response = MessageBox.Show("Are You Sure You Want To Delete This?", "Delete", MessageBoxButtons.YesNo);
            if (Response == DialogResult.Yes)
            {
                try
                {
                    string sqlstateDel = String.Format("DELETE FROM Songs WHERE SongId ='{0}';", lstSongs.SelectedValue.ToString());
                    myParent.SendData(sqlstateDel);
                    string sqlstate = String.Format("SELECT * FROM Songs ORDER BY SongName ASC;");
                    ds.Clear();
                    DataSet dsTemp = myParent.GetData(sqlstate, "Songs");
                    ds.Merge(dsTemp);
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("" + ex.Message.ToString());
                }
            }
            myParent.toolStripStatusLabel4.Text = "Ready...";
        }
        private void fieldChanged(object sender, KeyEventArgs e)
        {
            setButtons(true);
            myParent.toolStripStatusLabel4.Text = "Update In Progress...";
        }
        private void setButtons(Boolean state)
        {
            btnAdd.Visible = !state;
            btnDelete.Visible = !state;
            btnUpdate.Visible = state;
            btnCancel.Visible = state;
        }

        private void cmbGenre_SelectionChangeCommitted(object sender, EventArgs e)
        {
            setButtons(true);
            myParent.toolStripStatusLabel4.Text = "Update In Progress...";
        }
        private void dtpRelease_MouseDown(object sender, MouseEventArgs e)
        {
            setButtons(true);
            myParent.toolStripStatusLabel4.Text = "Update In Progress...";
        }
        #endregion
        #region Validations
        private void validate_Event(object sender, CancelEventArgs e)
        {
            if (sender == txtSongName && txtSongName.Text == "")
            {
                errorProvider1.SetError(txtSongName, "This Field is Mandatory");
            }
            else if (sender == txtArtist && txtArtist.Text == "")
            {
                errorProvider1.SetError(txtArtist, "This Field is Mandatory");
            }
            else if (sender == txtLength && txtLength.Text == "")
            {
                errorProvider1.SetError(txtLength, "This Field is Mandatory");
            }
            else if (sender == cmbGenre && cmbGenre.Text=="")
            {
                errorProvider1.SetError(cmbGenre, "This Field is Mandatory");
            }
            else if (sender == txtLength && !txtLength.Text.Contains(":"))
            {
                errorProvider1.SetError(txtLength, "Invalid! Track Length 00:00 Format Please");
            }
            else
            {
                errorProvider1.SetError(txtSongName, "");
                errorProvider1.SetError(txtArtist, "");
                errorProvider1.SetError(txtLength, "");
                errorProvider1.SetError(cmbGenre, "");
            }
        }
        private void cmbGenre_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbGenre.Text == "Rock")
            {
                txtPrice.Text = "1.00";
            }
            else if (cmbGenre.Text == "Rap")
            {
                txtPrice.Text = "3.00";
            }
            else if (cmbGenre.Text == "Country")
            {
                txtPrice.Text = "4.00";
            }
            else if (cmbGenre.Text == "Dance")
            {
                txtPrice.Text = "2.00";
            }
        }
        private bool isFormClean()
        {
            if (errorProvider1.GetError(txtSongName) == "" && errorProvider1.GetError(txtArtist) == "" &&
                errorProvider1.GetError(txtLength) == "" && errorProvider1.GetError(cmbGenre) == "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private string fixString(string StringToFix)
        {
            string temp = StringToFix;
            for (int i = 0; i < temp.Length; i++)
            {
                if (temp[i] == (char)39)
                {
                    temp = temp.Insert(i, "'");
                    i++;
                }
            }
            return temp;
        }
        #endregion
    }
}
