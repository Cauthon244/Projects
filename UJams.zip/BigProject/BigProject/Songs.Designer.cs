﻿namespace BigProject
{
    partial class Songs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtExplicit = new System.Windows.Forms.TextBox();
            this.lstSongs = new System.Windows.Forms.ListBox();
            this.lblArtist = new System.Windows.Forms.Label();
            this.txtLength = new System.Windows.Forms.TextBox();
            this.txtSongName = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.cmbGenre = new System.Windows.Forms.ComboBox();
            this.txtArtist = new System.Windows.Forms.TextBox();
            this.lblSongName = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblLength = new System.Windows.Forms.Label();
            this.lblGenre = new System.Windows.Forms.Label();
            this.lblChoice = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.dtpRelease = new System.Windows.Forms.DateTimePicker();
            this.lblRelease = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.rdoYes = new System.Windows.Forms.RadioButton();
            this.rdoNo = new System.Windows.Forms.RadioButton();
            this.pnlExplicit = new System.Windows.Forms.GroupBox();
            this.lblExplicit = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.pnlExplicit.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtExplicit
            // 
            this.txtExplicit.Location = new System.Drawing.Point(141, 204);
            this.txtExplicit.Margin = new System.Windows.Forms.Padding(4);
            this.txtExplicit.Name = "txtExplicit";
            this.txtExplicit.Size = new System.Drawing.Size(14, 22);
            this.txtExplicit.TabIndex = 36;
            this.txtExplicit.TextChanged += new System.EventHandler(this.txtExplicit_TextChanged);
            // 
            // lstSongs
            // 
            this.lstSongs.FormattingEnabled = true;
            this.lstSongs.ItemHeight = 16;
            this.lstSongs.Location = new System.Drawing.Point(285, 94);
            this.lstSongs.Name = "lstSongs";
            this.lstSongs.Size = new System.Drawing.Size(174, 244);
            this.lstSongs.TabIndex = 41;
            // 
            // lblArtist
            // 
            this.lblArtist.AutoSize = true;
            this.lblArtist.Location = new System.Drawing.Point(35, 184);
            this.lblArtist.Name = "lblArtist";
            this.lblArtist.Size = new System.Drawing.Size(81, 17);
            this.lblArtist.TabIndex = 42;
            this.lblArtist.Text = "Artist Name";
            // 
            // txtLength
            // 
            this.txtLength.Location = new System.Drawing.Point(35, 316);
            this.txtLength.MaxLength = 6;
            this.txtLength.Name = "txtLength";
            this.txtLength.Size = new System.Drawing.Size(70, 22);
            this.txtLength.TabIndex = 3;
            this.txtLength.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldChanged);
            this.txtLength.Validating += new System.ComponentModel.CancelEventHandler(this.validate_Event);
            // 
            // txtSongName
            // 
            this.txtSongName.Location = new System.Drawing.Point(35, 149);
            this.txtSongName.MaxLength = 50;
            this.txtSongName.Name = "txtSongName";
            this.txtSongName.Size = new System.Drawing.Size(151, 22);
            this.txtSongName.TabIndex = 1;
            this.txtSongName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldChanged);
            this.txtSongName.Validating += new System.ComponentModel.CancelEventHandler(this.validate_Event);
            // 
            // txtPrice
            // 
            this.txtPrice.Enabled = false;
            this.txtPrice.Location = new System.Drawing.Point(35, 262);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(65, 22);
            this.txtPrice.TabIndex = 45;
            // 
            // cmbGenre
            // 
            this.cmbGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGenre.FormattingEnabled = true;
            this.cmbGenre.Location = new System.Drawing.Point(35, 94);
            this.cmbGenre.Name = "cmbGenre";
            this.cmbGenre.Size = new System.Drawing.Size(151, 24);
            this.cmbGenre.TabIndex = 0;
            this.cmbGenre.SelectionChangeCommitted += new System.EventHandler(this.cmbGenre_SelectionChangeCommitted);
            this.cmbGenre.SelectedValueChanged += new System.EventHandler(this.cmbGenre_SelectedValueChanged);
            this.cmbGenre.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldChanged);
            this.cmbGenre.Validating += new System.ComponentModel.CancelEventHandler(this.validate_Event);
            // 
            // txtArtist
            // 
            this.txtArtist.Location = new System.Drawing.Point(35, 204);
            this.txtArtist.MaxLength = 50;
            this.txtArtist.Name = "txtArtist";
            this.txtArtist.Size = new System.Drawing.Size(151, 22);
            this.txtArtist.TabIndex = 2;
            this.txtArtist.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fieldChanged);
            this.txtArtist.Validating += new System.ComponentModel.CancelEventHandler(this.validate_Event);
            // 
            // lblSongName
            // 
            this.lblSongName.AutoSize = true;
            this.lblSongName.Location = new System.Drawing.Point(32, 128);
            this.lblSongName.Name = "lblSongName";
            this.lblSongName.Size = new System.Drawing.Size(82, 17);
            this.lblSongName.TabIndex = 48;
            this.lblSongName.Text = "Song Name";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(35, 242);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(40, 17);
            this.lblPrice.TabIndex = 49;
            this.lblPrice.Text = "Price";
            // 
            // lblLength
            // 
            this.lblLength.AutoSize = true;
            this.lblLength.Location = new System.Drawing.Point(32, 296);
            this.lblLength.Name = "lblLength";
            this.lblLength.Size = new System.Drawing.Size(92, 17);
            this.lblLength.TabIndex = 50;
            this.lblLength.Text = "Track Length";
            // 
            // lblGenre
            // 
            this.lblGenre.AutoSize = true;
            this.lblGenre.Location = new System.Drawing.Point(32, 74);
            this.lblGenre.Name = "lblGenre";
            this.lblGenre.Size = new System.Drawing.Size(48, 17);
            this.lblGenre.TabIndex = 51;
            this.lblGenre.Text = "Genre";
            // 
            // lblChoice
            // 
            this.lblChoice.AutoSize = true;
            this.lblChoice.Location = new System.Drawing.Point(282, 74);
            this.lblChoice.Name = "lblChoice";
            this.lblChoice.Size = new System.Drawing.Size(105, 17);
            this.lblChoice.TabIndex = 52;
            this.lblChoice.Text = "Choose a Song";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(141, 346);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(145, 45);
            this.btnAdd.TabIndex = 53;
            this.btnAdd.Text = "Add Song";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(314, 346);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(145, 45);
            this.btnDelete.TabIndex = 54;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(141, 346);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(145, 45);
            this.btnUpdate.TabIndex = 6;
            this.btnUpdate.Text = "Update Now";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Visible = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(314, 346);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(145, 45);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Visible = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // dtpRelease
            // 
            this.dtpRelease.Location = new System.Drawing.Point(35, 39);
            this.dtpRelease.Name = "dtpRelease";
            this.dtpRelease.Size = new System.Drawing.Size(200, 22);
            this.dtpRelease.TabIndex = 57;
            this.dtpRelease.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dtpRelease_MouseDown);
            this.dtpRelease.Validating += new System.ComponentModel.CancelEventHandler(this.validate_Event);
            // 
            // lblRelease
            // 
            this.lblRelease.AutoSize = true;
            this.lblRelease.Location = new System.Drawing.Point(35, 19);
            this.lblRelease.Name = "lblRelease";
            this.lblRelease.Size = new System.Drawing.Size(102, 17);
            this.lblRelease.TabIndex = 58;
            this.lblRelease.Text = "Date Released";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 265);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 59;
            this.label1.Text = "$";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // rdoYes
            // 
            this.rdoYes.AutoSize = true;
            this.rdoYes.Location = new System.Drawing.Point(7, 40);
            this.rdoYes.Name = "rdoYes";
            this.rdoYes.Size = new System.Drawing.Size(52, 20);
            this.rdoYes.TabIndex = 45;
            this.rdoYes.TabStop = true;
            this.rdoYes.Text = "Yes";
            this.rdoYes.UseVisualStyleBackColor = true;
            this.rdoYes.Click += new System.EventHandler(this.rdoExplicit_Click);
            // 
            // rdoNo
            // 
            this.rdoNo.AutoSize = true;
            this.rdoNo.Location = new System.Drawing.Point(7, 62);
            this.rdoNo.Name = "rdoNo";
            this.rdoNo.Size = new System.Drawing.Size(46, 20);
            this.rdoNo.TabIndex = 46;
            this.rdoNo.TabStop = true;
            this.rdoNo.Text = "No";
            this.rdoNo.UseVisualStyleBackColor = true;
            this.rdoNo.Click += new System.EventHandler(this.rdoExplicit_Click);
            // 
            // pnlExplicit
            // 
            this.pnlExplicit.BackColor = System.Drawing.SystemColors.Control;
            this.pnlExplicit.Controls.Add(this.rdoNo);
            this.pnlExplicit.Controls.Add(this.rdoYes);
            this.pnlExplicit.Controls.Add(this.lblExplicit);
            this.pnlExplicit.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlExplicit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnlExplicit.Location = new System.Drawing.Point(141, 242);
            this.pnlExplicit.Margin = new System.Windows.Forms.Padding(4);
            this.pnlExplicit.Name = "pnlExplicit";
            this.pnlExplicit.Padding = new System.Windows.Forms.Padding(4);
            this.pnlExplicit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.pnlExplicit.Size = new System.Drawing.Size(121, 91);
            this.pnlExplicit.TabIndex = 5;
            this.pnlExplicit.TabStop = false;
            // 
            // lblExplicit
            // 
            this.lblExplicit.BackColor = System.Drawing.SystemColors.Control;
            this.lblExplicit.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblExplicit.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExplicit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblExplicit.Location = new System.Drawing.Point(4, 20);
            this.lblExplicit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblExplicit.Name = "lblExplicit";
            this.lblExplicit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblExplicit.Size = new System.Drawing.Size(92, 17);
            this.lblExplicit.TabIndex = 37;
            this.lblExplicit.Text = "Explicit Track";
            // 
            // Songs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 403);
            this.Controls.Add(this.lblRelease);
            this.Controls.Add(this.dtpRelease);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblChoice);
            this.Controls.Add(this.lblGenre);
            this.Controls.Add(this.lblLength);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblSongName);
            this.Controls.Add(this.txtArtist);
            this.Controls.Add(this.cmbGenre);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtSongName);
            this.Controls.Add(this.txtLength);
            this.Controls.Add(this.lblArtist);
            this.Controls.Add(this.lstSongs);
            this.Controls.Add(this.pnlExplicit);
            this.Controls.Add(this.txtExplicit);
            this.Controls.Add(this.label1);
            this.Name = "Songs";
            this.Text = "Songs";
            this.Load += new System.EventHandler(this.Songs_Load);
            this.Enter += new System.EventHandler(this.Songs_Enter);
            this.Leave += new System.EventHandler(this.Songs_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.pnlExplicit.ResumeLayout(false);
            this.pnlExplicit.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtExplicit;
        private System.Windows.Forms.ListBox lstSongs;
        private System.Windows.Forms.Label lblArtist;
        private System.Windows.Forms.TextBox txtLength;
        private System.Windows.Forms.TextBox txtSongName;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.ComboBox cmbGenre;
        private System.Windows.Forms.TextBox txtArtist;
        private System.Windows.Forms.Label lblSongName;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblLength;
        private System.Windows.Forms.Label lblGenre;
        private System.Windows.Forms.Label lblChoice;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DateTimePicker dtpRelease;
        private System.Windows.Forms.Label lblRelease;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.GroupBox pnlExplicit;
        private System.Windows.Forms.RadioButton rdoNo;
        private System.Windows.Forms.RadioButton rdoYes;
        private System.Windows.Forms.Label lblExplicit;
    }
}