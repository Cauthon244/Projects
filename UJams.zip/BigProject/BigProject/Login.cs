﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using sql = System.Data.SqlClient;

namespace BigProject
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            txtUser.Text = Properties.Settings.Default.user;
            txtPass.Text = Properties.Settings.Default.password;
            if (txtPass.Text != string.Empty)
            {
                chkRemember.Checked = true;
            }
        }
        int count = 0;
        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (passwordCheck(txtPass.Text, txtUser.Text))
                {
                    if (chkRemember.Checked)
                    {
                        Properties.Settings.Default.user = txtUser.Text;
                        Properties.Settings.Default.password = txtPass.Text;
                    }
                    else
                    {
                        Properties.Settings.Default.user = string.Empty;
                        Properties.Settings.Default.password = string.Empty;
                    }
                    Properties.Settings.Default.Save();
                    DialogResult = DialogResult.OK;
                }
                else
                {
                    count += 1;
                    MessageBox.Show("Incorrect Password");
                    txtPass.Focus();
                    txtPass.SelectAll();
                    if (count == 3)
                    {
                        DialogResult = DialogResult.Cancel;
                        MessageBox.Show("To Many Failed Attempts");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }
        private bool passwordCheck(string password, string userid)
        {
            string sqlstate = String.Format("SELECT userid from {0} where UserId='{1}' and Password ='{2}';", "Authenticate", txtUser.Text, password);  //"Select userid from authenticate where userid = '" + userid + "'" + " and password = '" + password + "';";
            DataSet Basic = GetData(sqlstate, null);
            if (Basic.Tables[0].Rows.Count == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        private DataSet GetData(string sqlstatement, string tablename)
        {
            sql.SqlConnection cnn = new sql.SqlConnection(Properties.Settings.Default.cnnString);
            sql.SqlCommand cmd = new sql.SqlCommand();
            sql.SqlDataAdapter da = new sql.SqlDataAdapter();
            DataSet ds = new DataSet();
            cmd.CommandText = sqlstatement;
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.Text;
            da.SelectCommand = cmd;
            da.Fill(ds, "tablename");
            return ds;
        }
    }
}
