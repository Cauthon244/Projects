﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using sql = System.Data.SqlClient;

namespace BigProject
{
    public partial class MainForm : Form
    {
        
        public MainForm()
        {
            InitializeComponent();
        }
        Inquiry1 InqForm1;
        ReleaseDates InqForm2;
        ProfanityStats InqForm3;
        Songs songForm;
        Playlists playForm;
        User userForm;
        private void MainForm_Load(object sender, EventArgs e)
        {
            SplashForm mySplash = new SplashForm();
            mySplash.ShowDialog();
            Login myLog = new Login();
            myLog.ShowDialog();
            SetUpStatusStrip();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 myAbout = new AboutBox1();
            myAbout.ShowDialog();
        }
        internal DataSet GetData(string sqlstatement, string tablename)
        {
            sql.SqlConnection cnn = new sql.SqlConnection(Properties.Settings.Default.cnnString);
            sql.SqlCommand cmd = new sql.SqlCommand();
            sql.SqlDataAdapter da = new sql.SqlDataAdapter();
            DataSet ds = new DataSet();
            cmd.CommandText = sqlstatement;
            cmd.Connection = cnn;
            cmd.CommandType = CommandType.Text;
            da.SelectCommand = cmd;
            da.Fill(ds, tablename);
            return ds;
        }
        internal Int32 SendData(string sqlstate)
        {
            sql.SqlConnection cnn = new sql.SqlConnection(Properties.Settings.Default.cnnString);
            sql.SqlCommand cmd = new sql.SqlCommand();
            cmd.CommandText = sqlstate;
            cmd.Connection = cnn;
            Int32 RecAffect;
            using (cnn)
            {
                cnn.Open();
                RecAffect = cmd.ExecuteNonQuery();
                cnn.Close();
            }
            return RecAffect;
        }
        private void SetUpStatusStrip()
        {
            statusStrip1.LayoutStyle = ToolStripLayoutStyle.Table;

            toolStripStatusLabel1.Text = System.DateTime.Now.ToShortTimeString();
            toolStripStatusLabel1.TextAlign = ContentAlignment.MiddleLeft;
            toolStripStatusLabel1.BorderSides = ToolStripStatusLabelBorderSides.Right;

            toolStripStatusLabel2.Text = Environment.UserName;
            toolStripStatusLabel2.TextAlign = ContentAlignment.MiddleLeft;
            toolStripStatusLabel2.BorderSides = ToolStripStatusLabelBorderSides.Right;

            toolStripStatusLabel3.Text = "Position: 0 of 0";
            toolStripStatusLabel3.TextAlign = ContentAlignment.MiddleLeft;
            toolStripStatusLabel3.BorderSides = ToolStripStatusLabelBorderSides.Right;

            toolStripStatusLabel4.Text = "Ready...";
            toolStripStatusLabel4.TextAlign = ContentAlignment.MiddleRight;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = System.DateTime.Now.ToShortTimeString();
        }

        internal void bmb_PositionChanged(object sender, EventArgs e)
        {
            BindingManagerBase bmb = (BindingManagerBase)sender;
            toolStripStatusLabel3.Text = "Position " + (bmb.Position + 1) + " out of " + bmb.Count;
        }
        private void Tools_Click(object sender, EventArgs e)
        {
            if (sender == UserToolStripMenuItem || sender == toolStripButton1)
            {
                if (userForm == null || userForm.IsDisposed)
                    userForm = new User(this);
                isOpen(userForm);
            }
            else if (sender == PlaylistToolStripMenuItem || sender == toolStripButton2)
            {
                if (playForm == null || playForm.IsDisposed)
                    playForm = new Playlists(this);
                isOpen(playForm);
            }
            else if (sender == songsToolStripMenuItem || sender == toolStripButton3)
            {
                if (songForm == null || songForm.IsDisposed)
                    songForm = new Songs(this);
                isOpen(songForm);
            }
            else if (sender == report1ToolStripMenuItem)
            {
                if (InqForm1 == null || InqForm1.IsDisposed)
                    InqForm1 = new Inquiry1(this);
                isOpen(InqForm1);
            }
            else if (sender == report2ToolStripMenuItem)
            {
                if (InqForm2 == null || InqForm2.IsDisposed)
                    InqForm2 = new ReleaseDates(this);
                isOpen(InqForm2);
            }
            else if (sender == inquiry3ToolStripMenuItem)
            {
                if (InqForm3 == null || InqForm3.IsDisposed)
                    InqForm3 = new ProfanityStats(this);
                isOpen(InqForm3);
            }
        }
        private void isOpen(Form thisForm)
        {
            if (tabControl1.Contains(thisForm))
            {
                tabControl1.TabPages[thisForm].Select();
            }
            else
                tabControl1.TabPages.Add(thisForm);
        }
    }
}
