﻿namespace FrontEnd
{
    partial class Returns
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnResSearch = new System.Windows.Forms.Button();
            this.lblStudID = new System.Windows.Forms.Label();
            this.lblResources = new System.Windows.Forms.Label();
            this.lblResTitleTitle = new System.Windows.Forms.Label();
            this.btnReturn = new System.Windows.Forms.Button();
            this.lblCheckDateTitle = new System.Windows.Forms.Label();
            this.lblCheckDate1 = new System.Windows.Forms.Label();
            this.lblResStatTitle = new System.Windows.Forms.Label();
            this.lblResStatus1 = new System.Windows.Forms.Label();
            this.lblResTypeTitle = new System.Windows.Forms.Label();
            this.lblResType1 = new System.Windows.Forms.Label();
            this.lblTitle1 = new System.Windows.Forms.Label();
            this.lblResSearch = new System.Windows.Forms.Label();
            this.txtResource = new System.Windows.Forms.TextBox();
            this.txtfName = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.pnlResInfo = new System.Windows.Forms.Panel();
            this.pnlRet1 = new System.Windows.Forms.Panel();
            this.rdoMiss1 = new System.Windows.Forms.RadioButton();
            this.rdoStan1 = new System.Windows.Forms.RadioButton();
            this.rdoDam1 = new System.Windows.Forms.RadioButton();
            this.lblDueDateTitle = new System.Windows.Forms.Label();
            this.chk1 = new System.Windows.Forms.CheckBox();
            this.lblDueDate1 = new System.Windows.Forms.Label();
            this.lblIDTitle = new System.Windows.Forms.Label();
            this.lblResId1 = new System.Windows.Forms.Label();
            this.txtProgram = new System.Windows.Forms.TextBox();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.pnlInfo = new System.Windows.Forms.Panel();
            this.txtStudentStatus = new System.Windows.Forms.TextBox();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.lblStudent = new System.Windows.Forms.Label();
            this.lblLName = new System.Windows.Forms.Label();
            this.lblProgram = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblStudStatus = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.lblFName = new System.Windows.Forms.Label();
            this.pnlResInfo2 = new System.Windows.Forms.Panel();
            this.pnlRet2 = new System.Windows.Forms.Panel();
            this.rdoMiss2 = new System.Windows.Forms.RadioButton();
            this.rdoStan2 = new System.Windows.Forms.RadioButton();
            this.rdoDam2 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.chk2 = new System.Windows.Forms.CheckBox();
            this.lblDueDate2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblResId2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblCheckDate2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblResStatus2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblType2 = new System.Windows.Forms.Label();
            this.lblTitle2 = new System.Windows.Forms.Label();
            this.pnlResInfo3 = new System.Windows.Forms.Panel();
            this.pnlRet3 = new System.Windows.Forms.Panel();
            this.rdoMiss3 = new System.Windows.Forms.RadioButton();
            this.rdoStan3 = new System.Windows.Forms.RadioButton();
            this.rdoDam3 = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.chk3 = new System.Windows.Forms.CheckBox();
            this.lblDueDate3 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblResId3 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lblCheckDate3 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lblResStatus3 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.lblType3 = new System.Windows.Forms.Label();
            this.lblTitle3 = new System.Windows.Forms.Label();
            this.pnlResInfo.SuspendLayout();
            this.pnlRet1.SuspendLayout();
            this.pnlInfo.SuspendLayout();
            this.pnlResInfo2.SuspendLayout();
            this.pnlRet2.SuspendLayout();
            this.pnlResInfo3.SuspendLayout();
            this.pnlRet3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnResSearch
            // 
            this.btnResSearch.Location = new System.Drawing.Point(195, 151);
            this.btnResSearch.Name = "btnResSearch";
            this.btnResSearch.Size = new System.Drawing.Size(97, 30);
            this.btnResSearch.TabIndex = 62;
            this.btnResSearch.Text = "Search";
            this.btnResSearch.UseVisualStyleBackColor = true;
            this.btnResSearch.Click += new System.EventHandler(this.btnResSearch_Click);
            // 
            // lblStudID
            // 
            this.lblStudID.AutoSize = true;
            this.lblStudID.Location = new System.Drawing.Point(215, 6);
            this.lblStudID.Name = "lblStudID";
            this.lblStudID.Size = new System.Drawing.Size(0, 17);
            this.lblStudID.TabIndex = 46;
            this.lblStudID.Visible = false;
            // 
            // lblResources
            // 
            this.lblResources.AutoSize = true;
            this.lblResources.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResources.Location = new System.Drawing.Point(16, 11);
            this.lblResources.Name = "lblResources";
            this.lblResources.Size = new System.Drawing.Size(132, 25);
            this.lblResources.TabIndex = 37;
            this.lblResources.Text = "Resource Info";
            // 
            // lblResTitleTitle
            // 
            this.lblResTitleTitle.AutoSize = true;
            this.lblResTitleTitle.Location = new System.Drawing.Point(34, 41);
            this.lblResTitleTitle.Name = "lblResTitleTitle";
            this.lblResTitleTitle.Size = new System.Drawing.Size(35, 17);
            this.lblResTitleTitle.TabIndex = 36;
            this.lblResTitleTitle.Text = "Title";
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(893, 714);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(147, 47);
            this.btnReturn.TabIndex = 45;
            this.btnReturn.Text = "Return Selected Loans";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Visible = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // lblCheckDateTitle
            // 
            this.lblCheckDateTitle.AutoSize = true;
            this.lblCheckDateTitle.Location = new System.Drawing.Point(262, 104);
            this.lblCheckDateTitle.Name = "lblCheckDateTitle";
            this.lblCheckDateTitle.Size = new System.Drawing.Size(108, 17);
            this.lblCheckDateTitle.TabIndex = 38;
            this.lblCheckDateTitle.Text = "Check Out Date";
            // 
            // lblCheckDate1
            // 
            this.lblCheckDate1.AutoSize = true;
            this.lblCheckDate1.Location = new System.Drawing.Point(262, 121);
            this.lblCheckDate1.Name = "lblCheckDate1";
            this.lblCheckDate1.Size = new System.Drawing.Size(46, 17);
            this.lblCheckDate1.TabIndex = 44;
            this.lblCheckDate1.Text = "label8";
            // 
            // lblResStatTitle
            // 
            this.lblResStatTitle.AutoSize = true;
            this.lblResStatTitle.Location = new System.Drawing.Point(262, 41);
            this.lblResStatTitle.Name = "lblResStatTitle";
            this.lblResStatTitle.Size = new System.Drawing.Size(113, 17);
            this.lblResStatTitle.TabIndex = 39;
            this.lblResStatTitle.Text = "Resource Status";
            // 
            // lblResStatus1
            // 
            this.lblResStatus1.AutoSize = true;
            this.lblResStatus1.Location = new System.Drawing.Point(262, 58);
            this.lblResStatus1.Name = "lblResStatus1";
            this.lblResStatus1.Size = new System.Drawing.Size(46, 17);
            this.lblResStatus1.TabIndex = 43;
            this.lblResStatus1.Text = "label7";
            // 
            // lblResTypeTitle
            // 
            this.lblResTypeTitle.AutoSize = true;
            this.lblResTypeTitle.Location = new System.Drawing.Point(34, 104);
            this.lblResTypeTitle.Name = "lblResTypeTitle";
            this.lblResTypeTitle.Size = new System.Drawing.Size(40, 17);
            this.lblResTypeTitle.TabIndex = 40;
            this.lblResTypeTitle.Text = "Type";
            // 
            // lblResType1
            // 
            this.lblResType1.AutoSize = true;
            this.lblResType1.Location = new System.Drawing.Point(34, 121);
            this.lblResType1.Name = "lblResType1";
            this.lblResType1.Size = new System.Drawing.Size(46, 17);
            this.lblResType1.TabIndex = 42;
            this.lblResType1.Text = "label6";
            // 
            // lblTitle1
            // 
            this.lblTitle1.AutoSize = true;
            this.lblTitle1.Location = new System.Drawing.Point(34, 58);
            this.lblTitle1.Name = "lblTitle1";
            this.lblTitle1.Size = new System.Drawing.Size(46, 17);
            this.lblTitle1.TabIndex = 41;
            this.lblTitle1.Text = "label5";
            // 
            // lblResSearch
            // 
            this.lblResSearch.AutoSize = true;
            this.lblResSearch.Location = new System.Drawing.Point(178, 83);
            this.lblResSearch.Name = "lblResSearch";
            this.lblResSearch.Size = new System.Drawing.Size(143, 17);
            this.lblResSearch.TabIndex = 63;
            this.lblResSearch.Text = "Search For Resource";
            // 
            // txtResource
            // 
            this.txtResource.Location = new System.Drawing.Point(132, 108);
            this.txtResource.Name = "txtResource";
            this.txtResource.Size = new System.Drawing.Size(224, 22);
            this.txtResource.TabIndex = 61;
            // 
            // txtfName
            // 
            this.txtfName.Location = new System.Drawing.Point(115, 42);
            this.txtfName.Name = "txtfName";
            this.txtfName.ReadOnly = true;
            this.txtfName.Size = new System.Drawing.Size(200, 22);
            this.txtfName.TabIndex = 3;
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(115, 70);
            this.txtLName.Name = "txtLName";
            this.txtLName.ReadOnly = true;
            this.txtLName.Size = new System.Drawing.Size(200, 22);
            this.txtLName.TabIndex = 4;
            // 
            // pnlResInfo
            // 
            this.pnlResInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlResInfo.Controls.Add(this.pnlRet1);
            this.pnlResInfo.Controls.Add(this.lblDueDateTitle);
            this.pnlResInfo.Controls.Add(this.chk1);
            this.pnlResInfo.Controls.Add(this.lblDueDate1);
            this.pnlResInfo.Controls.Add(this.lblIDTitle);
            this.pnlResInfo.Controls.Add(this.lblResId1);
            this.pnlResInfo.Controls.Add(this.lblResources);
            this.pnlResInfo.Controls.Add(this.lblResTitleTitle);
            this.pnlResInfo.Controls.Add(this.lblCheckDateTitle);
            this.pnlResInfo.Controls.Add(this.lblCheckDate1);
            this.pnlResInfo.Controls.Add(this.lblResStatTitle);
            this.pnlResInfo.Controls.Add(this.lblResStatus1);
            this.pnlResInfo.Controls.Add(this.lblResTypeTitle);
            this.pnlResInfo.Controls.Add(this.lblResType1);
            this.pnlResInfo.Controls.Add(this.lblTitle1);
            this.pnlResInfo.Location = new System.Drawing.Point(12, 263);
            this.pnlResInfo.Name = "pnlResInfo";
            this.pnlResInfo.Size = new System.Drawing.Size(837, 162);
            this.pnlResInfo.TabIndex = 67;
            this.pnlResInfo.Visible = false;
            // 
            // pnlRet1
            // 
            this.pnlRet1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRet1.Controls.Add(this.rdoMiss1);
            this.pnlRet1.Controls.Add(this.rdoStan1);
            this.pnlRet1.Controls.Add(this.rdoDam1);
            this.pnlRet1.Enabled = false;
            this.pnlRet1.Location = new System.Drawing.Point(714, 74);
            this.pnlRet1.Name = "pnlRet1";
            this.pnlRet1.Size = new System.Drawing.Size(118, 83);
            this.pnlRet1.TabIndex = 73;
            // 
            // rdoMiss1
            // 
            this.rdoMiss1.AutoSize = true;
            this.rdoMiss1.Location = new System.Drawing.Point(2, 59);
            this.rdoMiss1.Name = "rdoMiss1";
            this.rdoMiss1.Size = new System.Drawing.Size(76, 21);
            this.rdoMiss1.TabIndex = 72;
            this.rdoMiss1.Text = "Missing";
            this.rdoMiss1.UseVisualStyleBackColor = true;
            // 
            // rdoStan1
            // 
            this.rdoStan1.AutoSize = true;
            this.rdoStan1.Checked = true;
            this.rdoStan1.Location = new System.Drawing.Point(2, 4);
            this.rdoStan1.Name = "rdoStan1";
            this.rdoStan1.Size = new System.Drawing.Size(87, 21);
            this.rdoStan1.TabIndex = 70;
            this.rdoStan1.TabStop = true;
            this.rdoStan1.Text = "Standard";
            this.rdoStan1.UseVisualStyleBackColor = true;
            // 
            // rdoDam1
            // 
            this.rdoDam1.AutoSize = true;
            this.rdoDam1.Location = new System.Drawing.Point(2, 31);
            this.rdoDam1.Name = "rdoDam1";
            this.rdoDam1.Size = new System.Drawing.Size(90, 21);
            this.rdoDam1.TabIndex = 71;
            this.rdoDam1.Text = "Damaged";
            this.rdoDam1.UseVisualStyleBackColor = true;
            // 
            // lblDueDateTitle
            // 
            this.lblDueDateTitle.AutoSize = true;
            this.lblDueDateTitle.Location = new System.Drawing.Point(497, 104);
            this.lblDueDateTitle.Name = "lblDueDateTitle";
            this.lblDueDateTitle.Size = new System.Drawing.Size(68, 17);
            this.lblDueDateTitle.TabIndex = 47;
            this.lblDueDateTitle.Text = "Due Date";
            // 
            // chk1
            // 
            this.chk1.AutoSize = true;
            this.chk1.Location = new System.Drawing.Point(734, 3);
            this.chk1.Name = "chk1";
            this.chk1.Size = new System.Drawing.Size(92, 21);
            this.chk1.TabIndex = 55;
            this.chk1.Text = "Returning";
            this.chk1.UseVisualStyleBackColor = true;
            this.chk1.CheckedChanged += new System.EventHandler(this.chk1_CheckedChanged);
            // 
            // lblDueDate1
            // 
            this.lblDueDate1.AutoSize = true;
            this.lblDueDate1.Location = new System.Drawing.Point(497, 121);
            this.lblDueDate1.Name = "lblDueDate1";
            this.lblDueDate1.Size = new System.Drawing.Size(46, 17);
            this.lblDueDate1.TabIndex = 50;
            this.lblDueDate1.Text = "label8";
            // 
            // lblIDTitle
            // 
            this.lblIDTitle.AutoSize = true;
            this.lblIDTitle.Location = new System.Drawing.Point(497, 41);
            this.lblIDTitle.Name = "lblIDTitle";
            this.lblIDTitle.Size = new System.Drawing.Size(86, 17);
            this.lblIDTitle.TabIndex = 48;
            this.lblIDTitle.Text = "Resource ID";
            // 
            // lblResId1
            // 
            this.lblResId1.AutoSize = true;
            this.lblResId1.Location = new System.Drawing.Point(497, 58);
            this.lblResId1.Name = "lblResId1";
            this.lblResId1.Size = new System.Drawing.Size(46, 17);
            this.lblResId1.TabIndex = 49;
            this.lblResId1.Text = "label7";
            // 
            // txtProgram
            // 
            this.txtProgram.Location = new System.Drawing.Point(115, 126);
            this.txtProgram.Name = "txtProgram";
            this.txtProgram.ReadOnly = true;
            this.txtProgram.Size = new System.Drawing.Size(200, 22);
            this.txtProgram.TabIndex = 5;
            // 
            // txtBalance
            // 
            this.txtBalance.Location = new System.Drawing.Point(115, 98);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.Size = new System.Drawing.Size(200, 22);
            this.txtBalance.TabIndex = 6;
            // 
            // pnlInfo
            // 
            this.pnlInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInfo.Controls.Add(this.txtfName);
            this.pnlInfo.Controls.Add(this.txtLName);
            this.pnlInfo.Controls.Add(this.txtProgram);
            this.pnlInfo.Controls.Add(this.txtBalance);
            this.pnlInfo.Controls.Add(this.txtStudentStatus);
            this.pnlInfo.Controls.Add(this.dtpEnd);
            this.pnlInfo.Controls.Add(this.lblStudID);
            this.pnlInfo.Controls.Add(this.dtpStart);
            this.pnlInfo.Controls.Add(this.lblStudent);
            this.pnlInfo.Controls.Add(this.lblLName);
            this.pnlInfo.Controls.Add(this.lblProgram);
            this.pnlInfo.Controls.Add(this.lblStartDate);
            this.pnlInfo.Controls.Add(this.lblEndDate);
            this.pnlInfo.Controls.Add(this.lblStudStatus);
            this.pnlInfo.Controls.Add(this.lblBalance);
            this.pnlInfo.Controls.Add(this.lblFName);
            this.pnlInfo.Location = new System.Drawing.Point(501, 12);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(348, 244);
            this.pnlInfo.TabIndex = 65;
            this.pnlInfo.Visible = false;
            // 
            // txtStudentStatus
            // 
            this.txtStudentStatus.Location = new System.Drawing.Point(115, 154);
            this.txtStudentStatus.Name = "txtStudentStatus";
            this.txtStudentStatus.ReadOnly = true;
            this.txtStudentStatus.Size = new System.Drawing.Size(200, 22);
            this.txtStudentStatus.TabIndex = 7;
            // 
            // dtpEnd
            // 
            this.dtpEnd.Enabled = false;
            this.dtpEnd.Location = new System.Drawing.Point(115, 210);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(200, 22);
            this.dtpEnd.TabIndex = 8;
            // 
            // dtpStart
            // 
            this.dtpStart.Enabled = false;
            this.dtpStart.Location = new System.Drawing.Point(115, 182);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(200, 22);
            this.dtpStart.TabIndex = 9;
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudent.Location = new System.Drawing.Point(98, 6);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(117, 25);
            this.lblStudent.TabIndex = 16;
            this.lblStudent.Text = "Student Info";
            // 
            // lblLName
            // 
            this.lblLName.AutoSize = true;
            this.lblLName.Location = new System.Drawing.Point(33, 73);
            this.lblLName.Name = "lblLName";
            this.lblLName.Size = new System.Drawing.Size(76, 17);
            this.lblLName.TabIndex = 17;
            this.lblLName.Text = "Last Name";
            // 
            // lblProgram
            // 
            this.lblProgram.AutoSize = true;
            this.lblProgram.Location = new System.Drawing.Point(47, 129);
            this.lblProgram.Name = "lblProgram";
            this.lblProgram.Size = new System.Drawing.Size(62, 17);
            this.lblProgram.TabIndex = 18;
            this.lblProgram.Text = "Program";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(37, 187);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(72, 17);
            this.lblStartDate.TabIndex = 19;
            this.lblStartDate.Text = "Start Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Location = new System.Drawing.Point(47, 215);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(67, 17);
            this.lblEndDate.TabIndex = 29;
            this.lblEndDate.Text = "End Date";
            // 
            // lblStudStatus
            // 
            this.lblStudStatus.AutoSize = true;
            this.lblStudStatus.Location = new System.Drawing.Point(8, 157);
            this.lblStudStatus.Name = "lblStudStatus";
            this.lblStudStatus.Size = new System.Drawing.Size(101, 17);
            this.lblStudStatus.TabIndex = 27;
            this.lblStudStatus.Text = "Student Status";
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Location = new System.Drawing.Point(20, 101);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(89, 17);
            this.lblBalance.TabIndex = 26;
            this.lblBalance.Text = "Balance Due";
            // 
            // lblFName
            // 
            this.lblFName.AutoSize = true;
            this.lblFName.Location = new System.Drawing.Point(33, 45);
            this.lblFName.Name = "lblFName";
            this.lblFName.Size = new System.Drawing.Size(76, 17);
            this.lblFName.TabIndex = 25;
            this.lblFName.Text = "First Name";
            // 
            // pnlResInfo2
            // 
            this.pnlResInfo2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlResInfo2.Controls.Add(this.pnlRet2);
            this.pnlResInfo2.Controls.Add(this.label1);
            this.pnlResInfo2.Controls.Add(this.chk2);
            this.pnlResInfo2.Controls.Add(this.lblDueDate2);
            this.pnlResInfo2.Controls.Add(this.label3);
            this.pnlResInfo2.Controls.Add(this.lblResId2);
            this.pnlResInfo2.Controls.Add(this.label5);
            this.pnlResInfo2.Controls.Add(this.label6);
            this.pnlResInfo2.Controls.Add(this.label7);
            this.pnlResInfo2.Controls.Add(this.label8);
            this.pnlResInfo2.Controls.Add(this.lblCheckDate2);
            this.pnlResInfo2.Controls.Add(this.label10);
            this.pnlResInfo2.Controls.Add(this.lblResStatus2);
            this.pnlResInfo2.Controls.Add(this.label12);
            this.pnlResInfo2.Controls.Add(this.lblType2);
            this.pnlResInfo2.Controls.Add(this.lblTitle2);
            this.pnlResInfo2.Location = new System.Drawing.Point(12, 431);
            this.pnlResInfo2.Name = "pnlResInfo2";
            this.pnlResInfo2.Size = new System.Drawing.Size(837, 162);
            this.pnlResInfo2.TabIndex = 68;
            this.pnlResInfo2.Visible = false;
            // 
            // pnlRet2
            // 
            this.pnlRet2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRet2.Controls.Add(this.rdoMiss2);
            this.pnlRet2.Controls.Add(this.rdoStan2);
            this.pnlRet2.Controls.Add(this.rdoDam2);
            this.pnlRet2.Enabled = false;
            this.pnlRet2.Location = new System.Drawing.Point(714, 74);
            this.pnlRet2.Name = "pnlRet2";
            this.pnlRet2.Size = new System.Drawing.Size(118, 83);
            this.pnlRet2.TabIndex = 74;
            // 
            // rdoMiss2
            // 
            this.rdoMiss2.AutoSize = true;
            this.rdoMiss2.Location = new System.Drawing.Point(2, 59);
            this.rdoMiss2.Name = "rdoMiss2";
            this.rdoMiss2.Size = new System.Drawing.Size(76, 21);
            this.rdoMiss2.TabIndex = 72;
            this.rdoMiss2.Text = "Missing";
            this.rdoMiss2.UseVisualStyleBackColor = true;
            // 
            // rdoStan2
            // 
            this.rdoStan2.AutoSize = true;
            this.rdoStan2.Checked = true;
            this.rdoStan2.Location = new System.Drawing.Point(2, 4);
            this.rdoStan2.Name = "rdoStan2";
            this.rdoStan2.Size = new System.Drawing.Size(87, 21);
            this.rdoStan2.TabIndex = 70;
            this.rdoStan2.TabStop = true;
            this.rdoStan2.Text = "Standard";
            this.rdoStan2.UseVisualStyleBackColor = true;
            // 
            // rdoDam2
            // 
            this.rdoDam2.AutoSize = true;
            this.rdoDam2.Location = new System.Drawing.Point(2, 31);
            this.rdoDam2.Name = "rdoDam2";
            this.rdoDam2.Size = new System.Drawing.Size(90, 21);
            this.rdoDam2.TabIndex = 71;
            this.rdoDam2.Text = "Damaged";
            this.rdoDam2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(497, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 17);
            this.label1.TabIndex = 47;
            this.label1.Text = "Due Date";
            // 
            // chk2
            // 
            this.chk2.AutoSize = true;
            this.chk2.Location = new System.Drawing.Point(734, 3);
            this.chk2.Name = "chk2";
            this.chk2.Size = new System.Drawing.Size(92, 21);
            this.chk2.TabIndex = 55;
            this.chk2.Text = "Returning";
            this.chk2.UseVisualStyleBackColor = true;
            this.chk2.CheckedChanged += new System.EventHandler(this.chk1_CheckedChanged);
            // 
            // lblDueDate2
            // 
            this.lblDueDate2.AutoSize = true;
            this.lblDueDate2.Location = new System.Drawing.Point(497, 121);
            this.lblDueDate2.Name = "lblDueDate2";
            this.lblDueDate2.Size = new System.Drawing.Size(46, 17);
            this.lblDueDate2.TabIndex = 50;
            this.lblDueDate2.Text = "label8";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(497, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 17);
            this.label3.TabIndex = 48;
            this.label3.Text = "Resource ID";
            // 
            // lblResId2
            // 
            this.lblResId2.AutoSize = true;
            this.lblResId2.Location = new System.Drawing.Point(497, 58);
            this.lblResId2.Name = "lblResId2";
            this.lblResId2.Size = new System.Drawing.Size(46, 17);
            this.lblResId2.TabIndex = 49;
            this.lblResId2.Text = "label7";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(146, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 17);
            this.label5.TabIndex = 46;
            this.label5.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(16, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 25);
            this.label6.TabIndex = 37;
            this.label6.Text = "Resource Info";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 17);
            this.label7.TabIndex = 36;
            this.label7.Text = "Title";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(262, 104);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 17);
            this.label8.TabIndex = 38;
            this.label8.Text = "Check Out Date";
            // 
            // lblCheckDate2
            // 
            this.lblCheckDate2.AutoSize = true;
            this.lblCheckDate2.Location = new System.Drawing.Point(262, 121);
            this.lblCheckDate2.Name = "lblCheckDate2";
            this.lblCheckDate2.Size = new System.Drawing.Size(46, 17);
            this.lblCheckDate2.TabIndex = 44;
            this.lblCheckDate2.Text = "label8";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(262, 41);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(113, 17);
            this.label10.TabIndex = 39;
            this.label10.Text = "Resource Status";
            // 
            // lblResStatus2
            // 
            this.lblResStatus2.AutoSize = true;
            this.lblResStatus2.Location = new System.Drawing.Point(262, 58);
            this.lblResStatus2.Name = "lblResStatus2";
            this.lblResStatus2.Size = new System.Drawing.Size(46, 17);
            this.lblResStatus2.TabIndex = 43;
            this.lblResStatus2.Text = "label7";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(34, 104);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 17);
            this.label12.TabIndex = 40;
            this.label12.Text = "Type";
            // 
            // lblType2
            // 
            this.lblType2.AutoSize = true;
            this.lblType2.Location = new System.Drawing.Point(34, 121);
            this.lblType2.Name = "lblType2";
            this.lblType2.Size = new System.Drawing.Size(46, 17);
            this.lblType2.TabIndex = 42;
            this.lblType2.Text = "label6";
            // 
            // lblTitle2
            // 
            this.lblTitle2.AutoSize = true;
            this.lblTitle2.Location = new System.Drawing.Point(34, 58);
            this.lblTitle2.Name = "lblTitle2";
            this.lblTitle2.Size = new System.Drawing.Size(46, 17);
            this.lblTitle2.TabIndex = 41;
            this.lblTitle2.Text = "label5";
            // 
            // pnlResInfo3
            // 
            this.pnlResInfo3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlResInfo3.Controls.Add(this.pnlRet3);
            this.pnlResInfo3.Controls.Add(this.label15);
            this.pnlResInfo3.Controls.Add(this.chk3);
            this.pnlResInfo3.Controls.Add(this.lblDueDate3);
            this.pnlResInfo3.Controls.Add(this.label17);
            this.pnlResInfo3.Controls.Add(this.lblResId3);
            this.pnlResInfo3.Controls.Add(this.label19);
            this.pnlResInfo3.Controls.Add(this.label20);
            this.pnlResInfo3.Controls.Add(this.label21);
            this.pnlResInfo3.Controls.Add(this.label22);
            this.pnlResInfo3.Controls.Add(this.lblCheckDate3);
            this.pnlResInfo3.Controls.Add(this.label24);
            this.pnlResInfo3.Controls.Add(this.lblResStatus3);
            this.pnlResInfo3.Controls.Add(this.label26);
            this.pnlResInfo3.Controls.Add(this.lblType3);
            this.pnlResInfo3.Controls.Add(this.lblTitle3);
            this.pnlResInfo3.Location = new System.Drawing.Point(12, 599);
            this.pnlResInfo3.Name = "pnlResInfo3";
            this.pnlResInfo3.Size = new System.Drawing.Size(837, 162);
            this.pnlResInfo3.TabIndex = 69;
            this.pnlResInfo3.Visible = false;
            // 
            // pnlRet3
            // 
            this.pnlRet3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRet3.Controls.Add(this.rdoMiss3);
            this.pnlRet3.Controls.Add(this.rdoStan3);
            this.pnlRet3.Controls.Add(this.rdoDam3);
            this.pnlRet3.Enabled = false;
            this.pnlRet3.Location = new System.Drawing.Point(714, 74);
            this.pnlRet3.Name = "pnlRet3";
            this.pnlRet3.Size = new System.Drawing.Size(118, 83);
            this.pnlRet3.TabIndex = 74;
            // 
            // rdoMiss3
            // 
            this.rdoMiss3.AutoSize = true;
            this.rdoMiss3.Location = new System.Drawing.Point(2, 59);
            this.rdoMiss3.Name = "rdoMiss3";
            this.rdoMiss3.Size = new System.Drawing.Size(76, 21);
            this.rdoMiss3.TabIndex = 72;
            this.rdoMiss3.Text = "Missing";
            this.rdoMiss3.UseVisualStyleBackColor = true;
            // 
            // rdoStan3
            // 
            this.rdoStan3.AutoSize = true;
            this.rdoStan3.Checked = true;
            this.rdoStan3.Location = new System.Drawing.Point(2, 4);
            this.rdoStan3.Name = "rdoStan3";
            this.rdoStan3.Size = new System.Drawing.Size(87, 21);
            this.rdoStan3.TabIndex = 70;
            this.rdoStan3.TabStop = true;
            this.rdoStan3.Text = "Standard";
            this.rdoStan3.UseVisualStyleBackColor = true;
            // 
            // rdoDam3
            // 
            this.rdoDam3.AutoSize = true;
            this.rdoDam3.Location = new System.Drawing.Point(2, 31);
            this.rdoDam3.Name = "rdoDam3";
            this.rdoDam3.Size = new System.Drawing.Size(90, 21);
            this.rdoDam3.TabIndex = 71;
            this.rdoDam3.Text = "Damaged";
            this.rdoDam3.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(497, 104);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 17);
            this.label15.TabIndex = 47;
            this.label15.Text = "Due Date";
            // 
            // chk3
            // 
            this.chk3.AutoSize = true;
            this.chk3.Location = new System.Drawing.Point(734, 3);
            this.chk3.Name = "chk3";
            this.chk3.Size = new System.Drawing.Size(92, 21);
            this.chk3.TabIndex = 55;
            this.chk3.Text = "Returning";
            this.chk3.UseVisualStyleBackColor = true;
            this.chk3.CheckedChanged += new System.EventHandler(this.chk1_CheckedChanged);
            // 
            // lblDueDate3
            // 
            this.lblDueDate3.AutoSize = true;
            this.lblDueDate3.Location = new System.Drawing.Point(497, 121);
            this.lblDueDate3.Name = "lblDueDate3";
            this.lblDueDate3.Size = new System.Drawing.Size(46, 17);
            this.lblDueDate3.TabIndex = 50;
            this.lblDueDate3.Text = "label8";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(497, 41);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(86, 17);
            this.label17.TabIndex = 48;
            this.label17.Text = "Resource ID";
            // 
            // lblResId3
            // 
            this.lblResId3.AutoSize = true;
            this.lblResId3.Location = new System.Drawing.Point(497, 58);
            this.lblResId3.Name = "lblResId3";
            this.lblResId3.Size = new System.Drawing.Size(46, 17);
            this.lblResId3.TabIndex = 49;
            this.lblResId3.Text = "label7";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(146, 18);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(0, 17);
            this.label19.TabIndex = 46;
            this.label19.Visible = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(16, 11);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(132, 25);
            this.label20.TabIndex = 37;
            this.label20.Text = "Resource Info";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(34, 41);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 17);
            this.label21.TabIndex = 36;
            this.label21.Text = "Title";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(262, 104);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(108, 17);
            this.label22.TabIndex = 38;
            this.label22.Text = "Check Out Date";
            // 
            // lblCheckDate3
            // 
            this.lblCheckDate3.AutoSize = true;
            this.lblCheckDate3.Location = new System.Drawing.Point(262, 121);
            this.lblCheckDate3.Name = "lblCheckDate3";
            this.lblCheckDate3.Size = new System.Drawing.Size(46, 17);
            this.lblCheckDate3.TabIndex = 44;
            this.lblCheckDate3.Text = "label8";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(262, 41);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(113, 17);
            this.label24.TabIndex = 39;
            this.label24.Text = "Resource Status";
            // 
            // lblResStatus3
            // 
            this.lblResStatus3.AutoSize = true;
            this.lblResStatus3.Location = new System.Drawing.Point(262, 58);
            this.lblResStatus3.Name = "lblResStatus3";
            this.lblResStatus3.Size = new System.Drawing.Size(46, 17);
            this.lblResStatus3.TabIndex = 43;
            this.lblResStatus3.Text = "label7";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(34, 104);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(40, 17);
            this.label26.TabIndex = 40;
            this.label26.Text = "Type";
            // 
            // lblType3
            // 
            this.lblType3.AutoSize = true;
            this.lblType3.Location = new System.Drawing.Point(34, 121);
            this.lblType3.Name = "lblType3";
            this.lblType3.Size = new System.Drawing.Size(46, 17);
            this.lblType3.TabIndex = 42;
            this.lblType3.Text = "label6";
            // 
            // lblTitle3
            // 
            this.lblTitle3.AutoSize = true;
            this.lblTitle3.Location = new System.Drawing.Point(34, 58);
            this.lblTitle3.Name = "lblTitle3";
            this.lblTitle3.Size = new System.Drawing.Size(46, 17);
            this.lblTitle3.TabIndex = 41;
            this.lblTitle3.Text = "label5";
            // 
            // Returns
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 778);
            this.Controls.Add(this.pnlResInfo3);
            this.Controls.Add(this.pnlResInfo2);
            this.Controls.Add(this.btnResSearch);
            this.Controls.Add(this.lblResSearch);
            this.Controls.Add(this.txtResource);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.pnlResInfo);
            this.Controls.Add(this.pnlInfo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Returns";
            this.Text = "Returns";
            this.Load += new System.EventHandler(this.Returns_Load);
            this.pnlResInfo.ResumeLayout(false);
            this.pnlResInfo.PerformLayout();
            this.pnlRet1.ResumeLayout(false);
            this.pnlRet1.PerformLayout();
            this.pnlInfo.ResumeLayout(false);
            this.pnlInfo.PerformLayout();
            this.pnlResInfo2.ResumeLayout(false);
            this.pnlResInfo2.PerformLayout();
            this.pnlRet2.ResumeLayout(false);
            this.pnlRet2.PerformLayout();
            this.pnlResInfo3.ResumeLayout(false);
            this.pnlResInfo3.PerformLayout();
            this.pnlRet3.ResumeLayout(false);
            this.pnlRet3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnResSearch;
        private System.Windows.Forms.Label lblStudID;
        private System.Windows.Forms.Label lblResources;
        private System.Windows.Forms.Label lblResTitleTitle;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Label lblCheckDateTitle;
        private System.Windows.Forms.Label lblCheckDate1;
        private System.Windows.Forms.Label lblResStatTitle;
        private System.Windows.Forms.Label lblResStatus1;
        private System.Windows.Forms.Label lblResTypeTitle;
        private System.Windows.Forms.Label lblResType1;
        private System.Windows.Forms.Label lblTitle1;
        private System.Windows.Forms.Label lblResSearch;
        private System.Windows.Forms.TextBox txtResource;
        private System.Windows.Forms.TextBox txtfName;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.Panel pnlResInfo;
        private System.Windows.Forms.TextBox txtProgram;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.Panel pnlInfo;
        private System.Windows.Forms.TextBox txtStudentStatus;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.Label lblStudent;
        private System.Windows.Forms.Label lblLName;
        private System.Windows.Forms.Label lblProgram;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblStudStatus;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label lblFName;
        private System.Windows.Forms.Label lblDueDateTitle;
        private System.Windows.Forms.CheckBox chk1;
        private System.Windows.Forms.Label lblDueDate1;
        private System.Windows.Forms.Label lblIDTitle;
        private System.Windows.Forms.Label lblResId1;
        private System.Windows.Forms.Panel pnlResInfo2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chk2;
        private System.Windows.Forms.Label lblDueDate2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblResId2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblCheckDate2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblResStatus2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblType2;
        private System.Windows.Forms.Label lblTitle2;
        private System.Windows.Forms.Panel pnlResInfo3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox chk3;
        private System.Windows.Forms.Label lblDueDate3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblResId3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblCheckDate3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblResStatus3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label lblType3;
        private System.Windows.Forms.Label lblTitle3;
        private System.Windows.Forms.RadioButton rdoStan1;
        private System.Windows.Forms.RadioButton rdoDam1;
        private System.Windows.Forms.RadioButton rdoMiss1;
        private System.Windows.Forms.Panel pnlRet1;
        private System.Windows.Forms.Panel pnlRet2;
        private System.Windows.Forms.RadioButton rdoMiss2;
        private System.Windows.Forms.RadioButton rdoStan2;
        private System.Windows.Forms.RadioButton rdoDam2;
        private System.Windows.Forms.Panel pnlRet3;
        private System.Windows.Forms.RadioButton rdoMiss3;
        private System.Windows.Forms.RadioButton rdoStan3;
        private System.Windows.Forms.RadioButton rdoDam3;
    }
}