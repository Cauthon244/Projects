﻿namespace FrontEnd
{
    partial class Reserve
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbSearchResult = new System.Windows.Forms.ComboBox();
            this.lblStudSearch = new System.Windows.Forms.Label();
            this.btnStudSearch = new System.Windows.Forms.Button();
            this.txtSearchStud = new System.Windows.Forms.TextBox();
            this.lblResSearch = new System.Windows.Forms.Label();
            this.btnResSearch = new System.Windows.Forms.Button();
            this.txtResource = new System.Windows.Forms.TextBox();
            this.pnlResInfo = new System.Windows.Forms.Panel();
            this.lblResID = new System.Windows.Forms.Label();
            this.lblResources = new System.Windows.Forms.Label();
            this.lblResTitleTitle = new System.Windows.Forms.Label();
            this.lblReserveStatTitle = new System.Windows.Forms.Label();
            this.lblReserveStat = new System.Windows.Forms.Label();
            this.lblResStatTitle = new System.Windows.Forms.Label();
            this.lblResStatus = new System.Windows.Forms.Label();
            this.lblResTypeTitle = new System.Windows.Forms.Label();
            this.lblResType = new System.Windows.Forms.Label();
            this.lblResTitle = new System.Windows.Forms.Label();
            this.pnlInfo = new System.Windows.Forms.Panel();
            this.txtfName = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtProgram = new System.Windows.Forms.TextBox();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.txtStudentStatus = new System.Windows.Forms.TextBox();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.lblStudent = new System.Windows.Forms.Label();
            this.lblLName = new System.Windows.Forms.Label();
            this.lblProgram = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblStudStatus = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.lblFName = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblStuId = new System.Windows.Forms.Label();
            this.pnlResInfo.SuspendLayout();
            this.pnlInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbSearchResult
            // 
            this.cmbSearchResult.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSearchResult.FormattingEnabled = true;
            this.cmbSearchResult.Location = new System.Drawing.Point(64, 409);
            this.cmbSearchResult.Name = "cmbSearchResult";
            this.cmbSearchResult.Size = new System.Drawing.Size(224, 24);
            this.cmbSearchResult.TabIndex = 50;
            this.cmbSearchResult.Visible = false;
            this.cmbSearchResult.SelectionChangeCommitted += new System.EventHandler(this.cmbSearchResult_SelectionChangeCommitted);
            // 
            // lblStudSearch
            // 
            this.lblStudSearch.AutoSize = true;
            this.lblStudSearch.Location = new System.Drawing.Point(111, 319);
            this.lblStudSearch.Name = "lblStudSearch";
            this.lblStudSearch.Size = new System.Drawing.Size(131, 17);
            this.lblStudSearch.TabIndex = 49;
            this.lblStudSearch.Text = "Search For Student";
            this.lblStudSearch.Visible = false;
            // 
            // btnStudSearch
            // 
            this.btnStudSearch.Location = new System.Drawing.Point(127, 371);
            this.btnStudSearch.Name = "btnStudSearch";
            this.btnStudSearch.Size = new System.Drawing.Size(97, 30);
            this.btnStudSearch.TabIndex = 48;
            this.btnStudSearch.Text = "Search";
            this.btnStudSearch.UseVisualStyleBackColor = true;
            this.btnStudSearch.Visible = false;
            this.btnStudSearch.Click += new System.EventHandler(this.btnStudSearch_Click);
            // 
            // txtSearchStud
            // 
            this.txtSearchStud.Location = new System.Drawing.Point(65, 339);
            this.txtSearchStud.Name = "txtSearchStud";
            this.txtSearchStud.Size = new System.Drawing.Size(224, 22);
            this.txtSearchStud.TabIndex = 47;
            this.txtSearchStud.Visible = false;
            // 
            // lblResSearch
            // 
            this.lblResSearch.AutoSize = true;
            this.lblResSearch.Location = new System.Drawing.Point(111, 108);
            this.lblResSearch.Name = "lblResSearch";
            this.lblResSearch.Size = new System.Drawing.Size(143, 17);
            this.lblResSearch.TabIndex = 53;
            this.lblResSearch.Text = "Search For Resource";
            // 
            // btnResSearch
            // 
            this.btnResSearch.Location = new System.Drawing.Point(128, 176);
            this.btnResSearch.Name = "btnResSearch";
            this.btnResSearch.Size = new System.Drawing.Size(97, 30);
            this.btnResSearch.TabIndex = 52;
            this.btnResSearch.Text = "Search";
            this.btnResSearch.UseVisualStyleBackColor = true;
            this.btnResSearch.Click += new System.EventHandler(this.btnResSearch_Click);
            // 
            // txtResource
            // 
            this.txtResource.Location = new System.Drawing.Point(65, 133);
            this.txtResource.Name = "txtResource";
            this.txtResource.Size = new System.Drawing.Size(224, 22);
            this.txtResource.TabIndex = 51;
            // 
            // pnlResInfo
            // 
            this.pnlResInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlResInfo.Controls.Add(this.lblResID);
            this.pnlResInfo.Controls.Add(this.lblResources);
            this.pnlResInfo.Controls.Add(this.lblResTitleTitle);
            this.pnlResInfo.Controls.Add(this.lblReserveStatTitle);
            this.pnlResInfo.Controls.Add(this.lblReserveStat);
            this.pnlResInfo.Controls.Add(this.lblResStatTitle);
            this.pnlResInfo.Controls.Add(this.lblResStatus);
            this.pnlResInfo.Controls.Add(this.lblResTypeTitle);
            this.pnlResInfo.Controls.Add(this.lblResType);
            this.pnlResInfo.Controls.Add(this.lblResTitle);
            this.pnlResInfo.Cursor = System.Windows.Forms.Cursors.Default;
            this.pnlResInfo.Location = new System.Drawing.Point(391, 108);
            this.pnlResInfo.Name = "pnlResInfo";
            this.pnlResInfo.Size = new System.Drawing.Size(454, 162);
            this.pnlResInfo.TabIndex = 54;
            this.pnlResInfo.Visible = false;
            // 
            // lblResID
            // 
            this.lblResID.AutoSize = true;
            this.lblResID.Location = new System.Drawing.Point(146, 18);
            this.lblResID.Name = "lblResID";
            this.lblResID.Size = new System.Drawing.Size(0, 17);
            this.lblResID.TabIndex = 46;
            this.lblResID.Visible = false;
            // 
            // lblResources
            // 
            this.lblResources.AutoSize = true;
            this.lblResources.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResources.Location = new System.Drawing.Point(16, 11);
            this.lblResources.Name = "lblResources";
            this.lblResources.Size = new System.Drawing.Size(132, 25);
            this.lblResources.TabIndex = 37;
            this.lblResources.Text = "Resource Info";
            // 
            // lblResTitleTitle
            // 
            this.lblResTitleTitle.AutoSize = true;
            this.lblResTitleTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResTitleTitle.Location = new System.Drawing.Point(34, 41);
            this.lblResTitleTitle.Name = "lblResTitleTitle";
            this.lblResTitleTitle.Size = new System.Drawing.Size(40, 17);
            this.lblResTitleTitle.TabIndex = 36;
            this.lblResTitleTitle.Text = "Title";
            // 
            // lblReserveStatTitle
            // 
            this.lblReserveStatTitle.AutoSize = true;
            this.lblReserveStatTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReserveStatTitle.Location = new System.Drawing.Point(304, 104);
            this.lblReserveStatTitle.Name = "lblReserveStatTitle";
            this.lblReserveStatTitle.Size = new System.Drawing.Size(119, 17);
            this.lblReserveStatTitle.TabIndex = 38;
            this.lblReserveStatTitle.Text = "Reserve Status";
            // 
            // lblReserveStat
            // 
            this.lblReserveStat.AutoSize = true;
            this.lblReserveStat.Location = new System.Drawing.Point(304, 121);
            this.lblReserveStat.Name = "lblReserveStat";
            this.lblReserveStat.Size = new System.Drawing.Size(46, 17);
            this.lblReserveStat.TabIndex = 44;
            this.lblReserveStat.Text = "label8";
            // 
            // lblResStatTitle
            // 
            this.lblResStatTitle.AutoSize = true;
            this.lblResStatTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResStatTitle.Location = new System.Drawing.Point(304, 41);
            this.lblResStatTitle.Name = "lblResStatTitle";
            this.lblResStatTitle.Size = new System.Drawing.Size(128, 17);
            this.lblResStatTitle.TabIndex = 39;
            this.lblResStatTitle.Text = "Resource Status";
            // 
            // lblResStatus
            // 
            this.lblResStatus.AutoSize = true;
            this.lblResStatus.Location = new System.Drawing.Point(304, 58);
            this.lblResStatus.Name = "lblResStatus";
            this.lblResStatus.Size = new System.Drawing.Size(46, 17);
            this.lblResStatus.TabIndex = 43;
            this.lblResStatus.Text = "label7";
            // 
            // lblResTypeTitle
            // 
            this.lblResTypeTitle.AutoSize = true;
            this.lblResTypeTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResTypeTitle.Location = new System.Drawing.Point(34, 104);
            this.lblResTypeTitle.Name = "lblResTypeTitle";
            this.lblResTypeTitle.Size = new System.Drawing.Size(44, 17);
            this.lblResTypeTitle.TabIndex = 40;
            this.lblResTypeTitle.Text = "Type";
            // 
            // lblResType
            // 
            this.lblResType.AutoSize = true;
            this.lblResType.Location = new System.Drawing.Point(34, 121);
            this.lblResType.Name = "lblResType";
            this.lblResType.Size = new System.Drawing.Size(46, 17);
            this.lblResType.TabIndex = 42;
            this.lblResType.Text = "label6";
            // 
            // lblResTitle
            // 
            this.lblResTitle.AutoSize = true;
            this.lblResTitle.Location = new System.Drawing.Point(34, 58);
            this.lblResTitle.Name = "lblResTitle";
            this.lblResTitle.Size = new System.Drawing.Size(46, 17);
            this.lblResTitle.TabIndex = 41;
            this.lblResTitle.Text = "label5";
            // 
            // pnlInfo
            // 
            this.pnlInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInfo.Controls.Add(this.lblStuId);
            this.pnlInfo.Controls.Add(this.txtfName);
            this.pnlInfo.Controls.Add(this.txtLName);
            this.pnlInfo.Controls.Add(this.txtProgram);
            this.pnlInfo.Controls.Add(this.txtBalance);
            this.pnlInfo.Controls.Add(this.txtStudentStatus);
            this.pnlInfo.Controls.Add(this.dtpEnd);
            this.pnlInfo.Controls.Add(this.dtpStart);
            this.pnlInfo.Controls.Add(this.lblStudent);
            this.pnlInfo.Controls.Add(this.lblLName);
            this.pnlInfo.Controls.Add(this.lblProgram);
            this.pnlInfo.Controls.Add(this.lblStartDate);
            this.pnlInfo.Controls.Add(this.lblEndDate);
            this.pnlInfo.Controls.Add(this.lblStudStatus);
            this.pnlInfo.Controls.Add(this.lblBalance);
            this.pnlInfo.Controls.Add(this.lblFName);
            this.pnlInfo.Location = new System.Drawing.Point(391, 319);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(454, 244);
            this.pnlInfo.TabIndex = 55;
            this.pnlInfo.Visible = false;
            // 
            // txtfName
            // 
            this.txtfName.Location = new System.Drawing.Point(115, 42);
            this.txtfName.Name = "txtfName";
            this.txtfName.ReadOnly = true;
            this.txtfName.Size = new System.Drawing.Size(200, 22);
            this.txtfName.TabIndex = 3;
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(115, 70);
            this.txtLName.Name = "txtLName";
            this.txtLName.ReadOnly = true;
            this.txtLName.Size = new System.Drawing.Size(200, 22);
            this.txtLName.TabIndex = 4;
            // 
            // txtProgram
            // 
            this.txtProgram.Location = new System.Drawing.Point(115, 126);
            this.txtProgram.Name = "txtProgram";
            this.txtProgram.ReadOnly = true;
            this.txtProgram.Size = new System.Drawing.Size(200, 22);
            this.txtProgram.TabIndex = 5;
            // 
            // txtBalance
            // 
            this.txtBalance.Location = new System.Drawing.Point(115, 98);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.Size = new System.Drawing.Size(200, 22);
            this.txtBalance.TabIndex = 6;
            // 
            // txtStudentStatus
            // 
            this.txtStudentStatus.Location = new System.Drawing.Point(115, 154);
            this.txtStudentStatus.Name = "txtStudentStatus";
            this.txtStudentStatus.ReadOnly = true;
            this.txtStudentStatus.Size = new System.Drawing.Size(200, 22);
            this.txtStudentStatus.TabIndex = 7;
            // 
            // dtpEnd
            // 
            this.dtpEnd.Enabled = false;
            this.dtpEnd.Location = new System.Drawing.Point(115, 210);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(200, 22);
            this.dtpEnd.TabIndex = 8;
            // 
            // dtpStart
            // 
            this.dtpStart.Enabled = false;
            this.dtpStart.Location = new System.Drawing.Point(115, 182);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(200, 22);
            this.dtpStart.TabIndex = 9;
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudent.Location = new System.Drawing.Point(98, 6);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(117, 25);
            this.lblStudent.TabIndex = 16;
            this.lblStudent.Text = "Student Info";
            // 
            // lblLName
            // 
            this.lblLName.AutoSize = true;
            this.lblLName.Location = new System.Drawing.Point(33, 73);
            this.lblLName.Name = "lblLName";
            this.lblLName.Size = new System.Drawing.Size(76, 17);
            this.lblLName.TabIndex = 17;
            this.lblLName.Text = "Last Name";
            // 
            // lblProgram
            // 
            this.lblProgram.AutoSize = true;
            this.lblProgram.Location = new System.Drawing.Point(47, 129);
            this.lblProgram.Name = "lblProgram";
            this.lblProgram.Size = new System.Drawing.Size(62, 17);
            this.lblProgram.TabIndex = 18;
            this.lblProgram.Text = "Program";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(37, 187);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(72, 17);
            this.lblStartDate.TabIndex = 19;
            this.lblStartDate.Text = "Start Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Location = new System.Drawing.Point(47, 215);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(67, 17);
            this.lblEndDate.TabIndex = 29;
            this.lblEndDate.Text = "End Date";
            // 
            // lblStudStatus
            // 
            this.lblStudStatus.AutoSize = true;
            this.lblStudStatus.Location = new System.Drawing.Point(8, 157);
            this.lblStudStatus.Name = "lblStudStatus";
            this.lblStudStatus.Size = new System.Drawing.Size(101, 17);
            this.lblStudStatus.TabIndex = 27;
            this.lblStudStatus.Text = "Student Status";
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Location = new System.Drawing.Point(20, 101);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(89, 17);
            this.lblBalance.TabIndex = 26;
            this.lblBalance.Text = "Balance Due";
            // 
            // lblFName
            // 
            this.lblFName.AutoSize = true;
            this.lblFName.Location = new System.Drawing.Point(33, 45);
            this.lblFName.Name = "lblFName";
            this.lblFName.Size = new System.Drawing.Size(76, 17);
            this.lblFName.TabIndex = 25;
            this.lblFName.Text = "First Name";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(105, 505);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(159, 58);
            this.btnSubmit.TabIndex = 56;
            this.btnSubmit.Text = "Confirm Reservation";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Visible = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lblStuId
            // 
            this.lblStuId.AutoSize = true;
            this.lblStuId.Location = new System.Drawing.Point(222, 13);
            this.lblStuId.Name = "lblStuId";
            this.lblStuId.Size = new System.Drawing.Size(0, 17);
            this.lblStuId.TabIndex = 30;
            this.lblStuId.Visible = false;
            // 
            // Reserve
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 773);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.pnlInfo);
            this.Controls.Add(this.pnlResInfo);
            this.Controls.Add(this.lblResSearch);
            this.Controls.Add(this.btnResSearch);
            this.Controls.Add(this.txtResource);
            this.Controls.Add(this.cmbSearchResult);
            this.Controls.Add(this.lblStudSearch);
            this.Controls.Add(this.btnStudSearch);
            this.Controls.Add(this.txtSearchStud);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "Reserve";
            this.Text = "Reserve";
            this.Load += new System.EventHandler(this.Reserve_Load);
            this.pnlResInfo.ResumeLayout(false);
            this.pnlResInfo.PerformLayout();
            this.pnlInfo.ResumeLayout(false);
            this.pnlInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbSearchResult;
        private System.Windows.Forms.Label lblStudSearch;
        private System.Windows.Forms.Button btnStudSearch;
        private System.Windows.Forms.TextBox txtSearchStud;
        private System.Windows.Forms.Label lblResSearch;
        private System.Windows.Forms.Button btnResSearch;
        private System.Windows.Forms.TextBox txtResource;
        private System.Windows.Forms.Panel pnlResInfo;
        private System.Windows.Forms.Label lblResID;
        private System.Windows.Forms.Label lblResources;
        private System.Windows.Forms.Label lblResTitleTitle;
        private System.Windows.Forms.Label lblReserveStatTitle;
        private System.Windows.Forms.Label lblReserveStat;
        private System.Windows.Forms.Label lblResStatTitle;
        private System.Windows.Forms.Label lblResStatus;
        private System.Windows.Forms.Label lblResTypeTitle;
        private System.Windows.Forms.Label lblResType;
        private System.Windows.Forms.Label lblResTitle;
        private System.Windows.Forms.Panel pnlInfo;
        private System.Windows.Forms.TextBox txtfName;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtProgram;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.TextBox txtStudentStatus;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.Label lblStudent;
        private System.Windows.Forms.Label lblLName;
        private System.Windows.Forms.Label lblProgram;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblStudStatus;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label lblFName;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label lblStuId;
    }
}