﻿namespace FrontEnd
{
    partial class Payments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbSearchResult = new System.Windows.Forms.ComboBox();
            this.lblStudSearch = new System.Windows.Forms.Label();
            this.btnStudSearch = new System.Windows.Forms.Button();
            this.txtSearchStud = new System.Windows.Forms.TextBox();
            this.pnlInfo = new System.Windows.Forms.Panel();
            this.lblStudID = new System.Windows.Forms.Label();
            this.txtfName = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtProgram = new System.Windows.Forms.TextBox();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.txtStudentStatus = new System.Windows.Forms.TextBox();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.lblStudent = new System.Windows.Forms.Label();
            this.lblLName = new System.Windows.Forms.Label();
            this.lblProgram = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblStudStatus = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.lblFName = new System.Windows.Forms.Label();
            this.lblPay = new System.Windows.Forms.Label();
            this.txtPayAmount = new System.Windows.Forms.TextBox();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.pnlPayments = new System.Windows.Forms.Panel();
            this.rdoCredit = new System.Windows.Forms.RadioButton();
            this.rdoDebit = new System.Windows.Forms.RadioButton();
            this.btnDaily = new System.Windows.Forms.Button();
            this.pnlInfo.SuspendLayout();
            this.pnlPayments.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbSearchResult
            // 
            this.cmbSearchResult.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSearchResult.FormattingEnabled = true;
            this.cmbSearchResult.Location = new System.Drawing.Point(111, 149);
            this.cmbSearchResult.Name = "cmbSearchResult";
            this.cmbSearchResult.Size = new System.Drawing.Size(224, 24);
            this.cmbSearchResult.TabIndex = 50;
            this.cmbSearchResult.Visible = false;
            this.cmbSearchResult.SelectionChangeCommitted += new System.EventHandler(this.cmbSearchResult_SelectionChangeCommitted);
            // 
            // lblStudSearch
            // 
            this.lblStudSearch.AutoSize = true;
            this.lblStudSearch.Location = new System.Drawing.Point(158, 59);
            this.lblStudSearch.Name = "lblStudSearch";
            this.lblStudSearch.Size = new System.Drawing.Size(131, 17);
            this.lblStudSearch.TabIndex = 49;
            this.lblStudSearch.Text = "Search For Student";
            // 
            // btnStudSearch
            // 
            this.btnStudSearch.Location = new System.Drawing.Point(174, 111);
            this.btnStudSearch.Name = "btnStudSearch";
            this.btnStudSearch.Size = new System.Drawing.Size(97, 30);
            this.btnStudSearch.TabIndex = 48;
            this.btnStudSearch.Text = "Search";
            this.btnStudSearch.UseVisualStyleBackColor = true;
            this.btnStudSearch.Click += new System.EventHandler(this.btnStudSearch_Click);
            // 
            // txtSearchStud
            // 
            this.txtSearchStud.Location = new System.Drawing.Point(112, 79);
            this.txtSearchStud.Name = "txtSearchStud";
            this.txtSearchStud.Size = new System.Drawing.Size(224, 22);
            this.txtSearchStud.TabIndex = 47;
            // 
            // pnlInfo
            // 
            this.pnlInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInfo.Controls.Add(this.lblStudID);
            this.pnlInfo.Controls.Add(this.txtfName);
            this.pnlInfo.Controls.Add(this.txtLName);
            this.pnlInfo.Controls.Add(this.txtProgram);
            this.pnlInfo.Controls.Add(this.txtBalance);
            this.pnlInfo.Controls.Add(this.txtStudentStatus);
            this.pnlInfo.Controls.Add(this.dtpEnd);
            this.pnlInfo.Controls.Add(this.dtpStart);
            this.pnlInfo.Controls.Add(this.lblStudent);
            this.pnlInfo.Controls.Add(this.lblLName);
            this.pnlInfo.Controls.Add(this.lblProgram);
            this.pnlInfo.Controls.Add(this.lblStartDate);
            this.pnlInfo.Controls.Add(this.lblEndDate);
            this.pnlInfo.Controls.Add(this.lblStudStatus);
            this.pnlInfo.Controls.Add(this.lblBalance);
            this.pnlInfo.Controls.Add(this.lblFName);
            this.pnlInfo.Location = new System.Drawing.Point(57, 207);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(348, 244);
            this.pnlInfo.TabIndex = 51;
            this.pnlInfo.Visible = false;
            // 
            // lblStudID
            // 
            this.lblStudID.AutoSize = true;
            this.lblStudID.Location = new System.Drawing.Point(184, 6);
            this.lblStudID.Name = "lblStudID";
            this.lblStudID.Size = new System.Drawing.Size(0, 17);
            this.lblStudID.TabIndex = 30;
            this.lblStudID.Visible = false;
            // 
            // txtfName
            // 
            this.txtfName.Location = new System.Drawing.Point(115, 42);
            this.txtfName.Name = "txtfName";
            this.txtfName.ReadOnly = true;
            this.txtfName.Size = new System.Drawing.Size(200, 22);
            this.txtfName.TabIndex = 3;
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(115, 70);
            this.txtLName.Name = "txtLName";
            this.txtLName.ReadOnly = true;
            this.txtLName.Size = new System.Drawing.Size(200, 22);
            this.txtLName.TabIndex = 4;
            // 
            // txtProgram
            // 
            this.txtProgram.Location = new System.Drawing.Point(115, 126);
            this.txtProgram.Name = "txtProgram";
            this.txtProgram.ReadOnly = true;
            this.txtProgram.Size = new System.Drawing.Size(200, 22);
            this.txtProgram.TabIndex = 5;
            // 
            // txtBalance
            // 
            this.txtBalance.Location = new System.Drawing.Point(115, 98);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.Size = new System.Drawing.Size(200, 22);
            this.txtBalance.TabIndex = 6;
            // 
            // txtStudentStatus
            // 
            this.txtStudentStatus.Location = new System.Drawing.Point(115, 154);
            this.txtStudentStatus.Name = "txtStudentStatus";
            this.txtStudentStatus.ReadOnly = true;
            this.txtStudentStatus.Size = new System.Drawing.Size(200, 22);
            this.txtStudentStatus.TabIndex = 7;
            // 
            // dtpEnd
            // 
            this.dtpEnd.Enabled = false;
            this.dtpEnd.Location = new System.Drawing.Point(115, 210);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(200, 22);
            this.dtpEnd.TabIndex = 8;
            // 
            // dtpStart
            // 
            this.dtpStart.Enabled = false;
            this.dtpStart.Location = new System.Drawing.Point(115, 182);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(200, 22);
            this.dtpStart.TabIndex = 9;
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudent.Location = new System.Drawing.Point(98, 6);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(117, 25);
            this.lblStudent.TabIndex = 16;
            this.lblStudent.Text = "Student Info";
            // 
            // lblLName
            // 
            this.lblLName.AutoSize = true;
            this.lblLName.Location = new System.Drawing.Point(33, 73);
            this.lblLName.Name = "lblLName";
            this.lblLName.Size = new System.Drawing.Size(76, 17);
            this.lblLName.TabIndex = 17;
            this.lblLName.Text = "Last Name";
            // 
            // lblProgram
            // 
            this.lblProgram.AutoSize = true;
            this.lblProgram.Location = new System.Drawing.Point(47, 129);
            this.lblProgram.Name = "lblProgram";
            this.lblProgram.Size = new System.Drawing.Size(62, 17);
            this.lblProgram.TabIndex = 18;
            this.lblProgram.Text = "Program";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(37, 187);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(72, 17);
            this.lblStartDate.TabIndex = 19;
            this.lblStartDate.Text = "Start Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Location = new System.Drawing.Point(47, 215);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(67, 17);
            this.lblEndDate.TabIndex = 29;
            this.lblEndDate.Text = "End Date";
            // 
            // lblStudStatus
            // 
            this.lblStudStatus.AutoSize = true;
            this.lblStudStatus.Location = new System.Drawing.Point(8, 157);
            this.lblStudStatus.Name = "lblStudStatus";
            this.lblStudStatus.Size = new System.Drawing.Size(101, 17);
            this.lblStudStatus.TabIndex = 27;
            this.lblStudStatus.Text = "Student Status";
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Location = new System.Drawing.Point(20, 101);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(89, 17);
            this.lblBalance.TabIndex = 26;
            this.lblBalance.Text = "Balance Due";
            // 
            // lblFName
            // 
            this.lblFName.AutoSize = true;
            this.lblFName.Location = new System.Drawing.Point(33, 45);
            this.lblFName.Name = "lblFName";
            this.lblFName.Size = new System.Drawing.Size(76, 17);
            this.lblFName.TabIndex = 25;
            this.lblFName.Text = "First Name";
            // 
            // lblPay
            // 
            this.lblPay.AutoSize = true;
            this.lblPay.Location = new System.Drawing.Point(156, 13);
            this.lblPay.Name = "lblPay";
            this.lblPay.Size = new System.Drawing.Size(105, 17);
            this.lblPay.TabIndex = 53;
            this.lblPay.Text = "Amount To Pay";
            // 
            // txtPayAmount
            // 
            this.txtPayAmount.Location = new System.Drawing.Point(96, 33);
            this.txtPayAmount.Name = "txtPayAmount";
            this.txtPayAmount.Size = new System.Drawing.Size(224, 22);
            this.txtPayAmount.TabIndex = 52;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(159, 61);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(97, 30);
            this.btnConfirm.TabIndex = 54;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // pnlPayments
            // 
            this.pnlPayments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPayments.Controls.Add(this.rdoCredit);
            this.pnlPayments.Controls.Add(this.rdoDebit);
            this.pnlPayments.Controls.Add(this.lblPay);
            this.pnlPayments.Controls.Add(this.btnConfirm);
            this.pnlPayments.Controls.Add(this.txtPayAmount);
            this.pnlPayments.Location = new System.Drawing.Point(69, 498);
            this.pnlPayments.Name = "pnlPayments";
            this.pnlPayments.Size = new System.Drawing.Size(328, 100);
            this.pnlPayments.TabIndex = 55;
            this.pnlPayments.Visible = false;
            // 
            // rdoCredit
            // 
            this.rdoCredit.AutoSize = true;
            this.rdoCredit.Location = new System.Drawing.Point(7, 60);
            this.rdoCredit.Name = "rdoCredit";
            this.rdoCredit.Size = new System.Drawing.Size(66, 21);
            this.rdoCredit.TabIndex = 56;
            this.rdoCredit.TabStop = true;
            this.rdoCredit.Text = "Credit";
            this.rdoCredit.UseVisualStyleBackColor = true;
            // 
            // rdoDebit
            // 
            this.rdoDebit.AutoSize = true;
            this.rdoDebit.Checked = true;
            this.rdoDebit.Location = new System.Drawing.Point(7, 24);
            this.rdoDebit.Name = "rdoDebit";
            this.rdoDebit.Size = new System.Drawing.Size(62, 21);
            this.rdoDebit.TabIndex = 55;
            this.rdoDebit.TabStop = true;
            this.rdoDebit.Text = "Debit";
            this.rdoDebit.UseVisualStyleBackColor = true;
            // 
            // btnDaily
            // 
            this.btnDaily.Location = new System.Drawing.Point(407, 79);
            this.btnDaily.Name = "btnDaily";
            this.btnDaily.Size = new System.Drawing.Size(145, 60);
            this.btnDaily.TabIndex = 56;
            this.btnDaily.Text = "Daily Overdue Check";
            this.btnDaily.UseVisualStyleBackColor = true;
            this.btnDaily.Click += new System.EventHandler(this.btnDaily_Click);
            // 
            // Payments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 773);
            this.Controls.Add(this.btnDaily);
            this.Controls.Add(this.pnlPayments);
            this.Controls.Add(this.pnlInfo);
            this.Controls.Add(this.cmbSearchResult);
            this.Controls.Add(this.lblStudSearch);
            this.Controls.Add(this.btnStudSearch);
            this.Controls.Add(this.txtSearchStud);
            this.Name = "Payments";
            this.Text = "Payment";
            this.pnlInfo.ResumeLayout(false);
            this.pnlInfo.PerformLayout();
            this.pnlPayments.ResumeLayout(false);
            this.pnlPayments.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbSearchResult;
        private System.Windows.Forms.Label lblStudSearch;
        private System.Windows.Forms.Button btnStudSearch;
        private System.Windows.Forms.TextBox txtSearchStud;
        private System.Windows.Forms.Panel pnlInfo;
        private System.Windows.Forms.TextBox txtfName;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtProgram;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.TextBox txtStudentStatus;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.Label lblStudent;
        private System.Windows.Forms.Label lblLName;
        private System.Windows.Forms.Label lblProgram;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblStudStatus;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label lblFName;
        private System.Windows.Forms.Label lblPay;
        private System.Windows.Forms.TextBox txtPayAmount;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Panel pnlPayments;
        private System.Windows.Forms.RadioButton rdoCredit;
        private System.Windows.Forms.RadioButton rdoDebit;
        private System.Windows.Forms.Label lblStudID;
        private System.Windows.Forms.Button btnDaily;
    }
}