﻿using BLL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Model.Lists.Lookups;

namespace FrontEnd
{
    public partial class ManageStudents : Form
    {
        private Form1 myParent;
        public ManageStudents(Form1 Re)
        {
            InitializeComponent();
        }
        private List<Loan> loans = new List<Loan>();
        private Loan lon = new Loan();
        private Student stu = new Student();
        private Resource res = new Resource();

        private void btnStudSearch_Click(object sender, EventArgs e)
        {
            string errMsg = CheckNameAndLength();

            if (errMsg != string.Empty)
            {
                MessageBox.Show(errMsg);
            }
            else
            {

                ListsBL listsBl = new ListsBL();
                List<StudentLookup> sups = listsBl.GetStudentList(txtSearchStud.Text);
                if (sups.Count > 0)
                {
                    cmbSearchResult.DataSource = sups;
                    cmbSearchResult.DisplayMember = "LastName";
                    cmbSearchResult.ValueMember = "StudentId";
                    cmbSearchResult.SelectedIndex = 0;
                    cmbSearchResult.Visible = true;
                }
                else
                {
                    MessageBox.Show("No Student With That Name or ID, Please Try Again.");
                }
            }
        }

        private string CheckNameAndLength()
        {
            string errMsg = string.Empty;
            if (txtSearchStud.Text == string.Empty || txtSearchStud.TextLength > 50)
            {
                errMsg = "Please Supply a Valid Name.";
                txtSearchStud.Focus();
            }
            return errMsg;
        }

        private void cmbSearchResult_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {

                StudentBL StuBL = new StudentBL();
                stu = StuBL.getStudent(Convert.ToInt32(cmbSearchResult.SelectedValue));

                PopulateStudentRecord();
                pnlInfo.Visible = true;
                btnDelete.Visible = true;
                btnUpdate.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void PopulateStudentRecord()
        {
            txtStudID.Text = stu.StudentID.ToString();
            txtfName.Text = stu.FirstName.ToString();
            txtLName.Text = stu.LastName.ToString();
            if (stu.Program == 1) { rdoStandard.Checked = true; }
            else { rdoBlock.Checked = true; }
            if (stu.StudentStatus == 1) { chkActive.Checked=true; }
            else { chkActive.Checked = false; }
            txtBalance.Text = stu.BalanceDue.ToString("c");
            dtpStart.Text = stu.StartDate.ToString();
            dtpEnd.Text = stu.EndDate.ToString();
            txtAddress.Text = stu.Address.ToString();
            txtCity.Text = stu.City.ToString();
            txtPost.Text = stu.PostalCode.ToString();
            txtPhone.Text = stu.Phone.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                FillStudent();
                StudentBL stuBL = new StudentBL();
                bool res = stuBL.updateStudent(stu);

                if (res)
                {
                    MessageBox.Show("Student Updated Successfully");
                    ClearForm();
                }
                else
                {
                    string message = "";
                    foreach (ValidationErrors error in stuBL.validationErrors)
                    {
                        message += error.description + Environment.NewLine;
                    }
                    MessageBox.Show(message);
                    StudentBL StuBL = new StudentBL();
                    stu = StuBL.getStudent(Convert.ToInt32(cmbSearchResult.SelectedValue));

                    PopulateStudentRecord();
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void FillStudent()
        {
            stu = new Student();
            stu.StudentID = Convert.ToInt32(txtStudID.Text);
            stu.FirstName = txtfName.Text;
            stu.LastName = txtLName.Text;
            if (rdoStandard.Checked) stu.Program = 1;
            else { stu.Program = 0; }
            stu.StudentStatus = Convert.ToInt32(chkActive.Checked);
            stu.StartDate = dtpStart.Value;
            stu.EndDate = dtpEnd.Value;
            stu.Address = txtAddress.Text;
            stu.City = txtCity.Text;
            stu.PostalCode = txtPost.Text;
            stu.Phone = txtPhone.Text;
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want to Delete This Student?", "Warning",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                txtSearchStud.Focus();
                return;
            }
            try
            {
                StudentBL stuBL = new StudentBL();
                stuBL.deleteStudent(txtStudID.Text);

                    MessageBox.Show("Student Deleted Successfully");
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearForm()
        {
            pnlInfo.Visible = false;
            btnUpdate.Visible = false;
            btnDelete.Visible = false;
            cmbSearchResult.Visible = false;
            txtSearchStud.Clear();
            txtSearchStud.Focus();
        }
        private void ManageStudents_Load(object sender, EventArgs e)
        {
            txtSearchStud.Focus();
        }
    }
}
