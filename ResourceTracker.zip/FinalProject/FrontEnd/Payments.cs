﻿using BLL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Model.Lists.Lookups;

namespace FrontEnd
{
    public partial class Payments : Form
    {
        private Form1 myParent;
        public Payments(Form1 Re)
        {
            InitializeComponent();
        }
        private List<Loan> loans = new List<Loan>();
        private Loan lon = new Loan();
        private Student stu = new Student();
        private Resource res = new Resource();
        private Payment pay = new Payment();

        private void btnStudSearch_Click(object sender, EventArgs e)
        {
            string errMsg = CheckNameAndLength();

            if (errMsg != string.Empty)
            {
                MessageBox.Show(errMsg);
            }
            else
            {

                ListsBL listsBl = new ListsBL();
                List<StudentLookup> sups = listsBl.GetStudentList(txtSearchStud.Text);
                if (sups.Count > 0)
                {
                    cmbSearchResult.DataSource = sups;
                    cmbSearchResult.DisplayMember = "LastName";
                    cmbSearchResult.ValueMember = "StudentId";
                    cmbSearchResult.SelectedIndex = 0;
                    cmbSearchResult.Visible = true;
                }
                else
                {
                    MessageBox.Show("No Student With That Name or ID, Please Try Again.");
                }
            }
        }

        private string CheckNameAndLength()
        {
            string errMsg = string.Empty;
            if (txtSearchStud.Text == string.Empty || txtSearchStud.TextLength > 50)
            {
                errMsg = "Please Supply a Valid Name.";
            }
            return errMsg;
        }

        private void cmbSearchResult_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {

                StudentBL StuBL = new StudentBL();
                stu = StuBL.getStudent(Convert.ToInt32(cmbSearchResult.SelectedValue));
                if (stu.BalanceDue == 0)
                {
                    MessageBox.Show("This Student Has No Outstanding Balance Due.");
                }
                else
                {
                    PopulateStudentRecord();
                    pnlInfo.Visible = true;
                    pnlPayments.Visible = true;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void PopulateStudentRecord()
        {
            lblStudID.Text = stu.StudentID.ToString();
            txtfName.Text = stu.FirstName.ToString();
            txtLName.Text = stu.LastName.ToString();
            if (stu.Program.ToString() == "True") { txtProgram.Text = "Regular Program"; }
            else { txtProgram.Text = "Block Release"; }
            if (Convert.ToInt32(stu.StudentStatus) == 1) { txtStudentStatus.Text = "Active"; }
            else { txtStudentStatus.Text = "Inactive"; }
            txtBalance.Text = stu.BalanceDue.ToString("c");
            dtpStart.Text = stu.StartDate.ToString();
            dtpEnd.Text = stu.EndDate.ToString();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                FillPayment();
                PaymentBL payBL = new PaymentBL();
                bool res = payBL.MakePayment(pay);

                if (res)
                {
                    MessageBox.Show("Payment Successfully Made.");
                    pnlInfo.Visible = false;
                    pnlPayments.Visible = false;
                    cmbSearchResult.Visible = false;
                    txtSearchStud.ResetText();
                    txtSearchStud.Focus();
                }
                else
                {
                    string message = "";
                    foreach (ValidationErrors error in payBL.validationErrors)
                    {
                        message += error.description + Environment.NewLine;
                    }
                    MessageBox.Show(message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void FillPayment()
        {
            pay = new Payment();
            pay.StudentID = Convert.ToInt32(lblStudID.Text);
            if (rdoCredit.Checked) { pay.PaymentType = 0; }
            else { pay.PaymentType = 1; }
            pay.PaymentAmount = Convert.ToDouble(txtPayAmount.Text);      
        }

        private void btnDaily_Click(object sender, EventArgs e)
        {
            string message = "";
            PaymentBL payBL = new PaymentBL();
            payBL.GetOverdues();
            message = payBL.NonReturnedList();
            MessageBox.Show(message);
        }
    }
}
