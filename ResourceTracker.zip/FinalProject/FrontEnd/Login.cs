﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using Types;

namespace FrontEnd
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string useName = txtUser.Text;
                string pass = txtPass.Text;
                    List<ParmStruct> parms = new List<ParmStruct>();
                    parms.Add(new ParmStruct("@USERNAME", useName, 0, SqlDbType.VarChar, ParameterDirection.Input));
                    parms.Add(new ParmStruct("@PASSWORD", pass, 0, SqlDbType.VarChar, ParameterDirection.Input));
                Data db = new Data();
                    DataTable dt = db.Execute("spLogin", CommandType.StoredProcedure, parms);
                DialogResult = DialogResult.OK;

                Properties.Settings.Default.Priviledge = dt.Rows[0][0].ToString();
                Properties.Settings.Default.Head = dt.Rows[0][1].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, ex.GetType().ToString());
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            txtUser.Focus();
        }
    }
}
