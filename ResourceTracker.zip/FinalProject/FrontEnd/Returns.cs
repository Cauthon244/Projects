﻿using BLL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Types;

namespace FrontEnd
{
    public partial class Returns : Form
    {
        private Form1 myParent;
        public Returns(Form1 Re)
        {
            InitializeComponent();
        }
        private Loan lon = new Loan();
        private Student stu = new Student();
        private Resource res = new Resource();
        private DataTable dt = new DataTable();
        private void btnResSearch_Click(object sender, EventArgs e)
        {
            string errMsg = CheckResourceID();

            if (errMsg != string.Empty)
            {
                MessageBox.Show(errMsg);
            }
            else
            {
                try
                {

                    ResourceBL ResBL = new ResourceBL();
                    LoanBL lonBL = new LoanBL();
                    StudentBL stuBL= new StudentBL();
                    if (!int.TryParse(txtResource.Text, out int result)) { MessageBox.Show("No Resource With That ID, Please Try Again."); FormClear(); }
                    else
                    {
                        lon = lonBL.GetLoanAndResource(Convert.ToInt32(txtResource.Text));
                        stu = stuBL.getStudent(Convert.ToInt32(lon.StudentID));
                        res = ResBL.getResource(lon.ResourceID.ToString());
                        if (lonBL.NumbOfLoans(lon.StudentID)==1)
                        {
                            PopulateRecord();
                            pnlResInfo.Visible = true;
                            pnlInfo.Visible = true;
                            pnlResInfo2.Visible = false;
                            pnlResInfo3.Visible = false;
                        }
                        else if (lonBL.NumbOfLoans(lon.StudentID) == 2)
                        {
                            dt = new DataTable();
                            dt = lonBL.GetLoanForReturn(lon.StudentID,lon.ResourceID);
                            PopulateRecord();
                            PopulateRecord2(dt);
                            pnlResInfo.Visible = true;
                            pnlInfo.Visible = true;
                            pnlResInfo2.Visible = true;
                            pnlResInfo3.Visible = false;
                        }
                        else if (lonBL.NumbOfLoans(lon.StudentID) == 3)
                        {
                            dt = new DataTable();
                            dt = lonBL.GetLoanForReturn(lon.StudentID,lon.ResourceID);
                            PopulateRecord();
                            PopulateRecord2(dt);
                            PopulateRecord3(dt);
                            pnlResInfo.Visible = true;
                            pnlInfo.Visible = true;
                            pnlResInfo2.Visible = true;
                            pnlResInfo3.Visible = true;
                        }
                        else
                        {
                            MessageBox.Show("No Loan For That Resource, Please Try Again.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private string CheckResourceID()
        {
            ResourceBL resBL = new ResourceBL();
            string errMsg = string.Empty;
            if (txtResource.Text == string.Empty)
            {
                errMsg = "Please Supply a Valid ID.";
                FormClear();
            }
            if (resBL.CheckResourceForLoan(Convert.ToInt32(txtResource.Text))){
                errMsg = "No Associated Loans";
                FormClear();
            }
            return errMsg;
        }
        private void PopulateRecord()
        {
            lblStudID.Text = stu.StudentID.ToString();
            txtfName.Text = stu.FirstName.ToString();
            txtLName.Text = stu.LastName.ToString();
            if (stu.Program.ToString() == "True") { txtProgram.Text = "Regular Program"; }
            else { txtProgram.Text = "Block Release"; }
            if (Convert.ToInt32(stu.StudentStatus) == 1) { txtStudentStatus.Text = "Active"; }
            else { txtStudentStatus.Text = "Inactive"; }
            txtBalance.Text = stu.BalanceDue.ToString("c");
            dtpStart.Text = stu.StartDate.ToString();
            dtpEnd.Text = stu.EndDate.ToString();
            lblResId1.Text = res.ResourceID.ToString();
            lblTitle1.Text = res.ResourceName.ToString();
            lblResType1.Text = res.ResourceType.ToString();
            lblResStatus1.Text = res.ResourceStatus.ToString();
            lblCheckDate1.Text = lon.CheckoutDate.ToString();
            lblDueDate1.Text = lon.DueDate.ToString();
            chk1.Checked = false;
        }
        private void PopulateRecord2(DataTable dt)
        {
            ResourceBL resBL = new ResourceBL();
            res = resBL.getResourceRet(Convert.ToInt32(dt.Rows[0][0]));
            lblResId2.Text =dt.Rows[0][0].ToString();
            lblTitle2.Text = res.ResourceName.ToString();
            lblType2.Text = res.ResourceType.ToString();
            lblResStatus2.Text = res.ResourceStatus.ToString();
            lblCheckDate2.Text = dt.Rows[0][2].ToString();
            lblDueDate2.Text = dt.Rows[0][3].ToString();
            chk2.Checked = false;
        }
        private void PopulateRecord3(DataTable dt)
        {
            ResourceBL resBL = new ResourceBL();
            res = resBL.getResourceRet(Convert.ToInt32(dt.Rows[1][0]));
            lblResId3.Text = dt.Rows[1][0].ToString();
            lblTitle3.Text = res.ResourceName.ToString();
            lblType3.Text = res.ResourceType.ToString();
            lblResStatus3.Text = res.ResourceStatus.ToString();
            lblCheckDate3.Text = dt.Rows[1][2].ToString();
            lblDueDate3.Text = dt.Rows[1][3].ToString();
            chk3.Checked = false;
        }

        private void Returns_Load(object sender, EventArgs e)
        {
            txtResource.Focus();
        }

        private void chk1_CheckedChanged(object sender, EventArgs e)
        {
            if (chk1.Checked)
            {
                pnlRet1.Enabled = true;
                btnReturn.Visible = true;
            }
            else
            {
                pnlRet1.Enabled = false;
            }
            if (chk2.Checked)
            {
                pnlRet2.Enabled = true;
                btnReturn.Visible = true;
            }
            else
            {
                pnlRet2.Enabled = false;
            }
            if (chk3.Checked)
            {
                pnlRet3.Enabled = true;
                btnReturn.Visible = true;
            }
            else
            {
                pnlRet3.Enabled = false;
            }
            if (chk1.Checked == false&& chk2.Checked == false && chk3.Checked == false)
            {
                btnReturn.Visible = false;
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            lon = new Loan();
            lon.StudentID= Convert.ToInt32(lblStudID.Text);
            if (chk1.Checked)
            { 
                lon.ResourceID = Convert.ToInt32(lblResId1.Text); 
                if (rdoStan1.Checked)
                {
                    lon.LoanStatus = LoanStatus.Returned;
                    LoanReturnMethod(lon, ResourceStatus.Available);
                }
                else if (rdoMiss1.Checked)
                {
                    lon.LoanStatus = LoanStatus.NotReturned;
                    LoanReturnMethod(lon, ResourceStatus.NotAvailable);
                }
                else if (rdoDam1.Checked)
                {
                    lon.LoanStatus = LoanStatus.Damaged;
                    LoanReturnMethod(lon, ResourceStatus.NotAvailable);
                }
                
            }
            if (chk2.Checked)
            {
                lon.ResourceID = Convert.ToInt32(lblResId2.Text);
                if (rdoStan2.Checked)
                {
                    lon.LoanStatus = LoanStatus.Returned;
                    LoanReturnMethod(lon, ResourceStatus.Available);
                }
                else if (rdoMiss2.Checked)
                {
                    lon.LoanStatus = LoanStatus.NotReturned;
                    LoanReturnMethod(lon, ResourceStatus.NotAvailable);
                }
                else if (rdoDam2.Checked)
                {
                    lon.LoanStatus = LoanStatus.Damaged;
                    LoanReturnMethod(lon, ResourceStatus.NotAvailable);
                }
            }
            if (chk3.Checked)
            {
                lon.ResourceID = Convert.ToInt32(lblResId3.Text);
                if (rdoStan3.Checked)
                {
                    lon.LoanStatus = LoanStatus.Returned;
                    LoanReturnMethod(lon, ResourceStatus.Available);
                }
                else if (rdoMiss3.Checked)
                {
                    lon.LoanStatus = LoanStatus.NotReturned;
                    LoanReturnMethod(lon, ResourceStatus.NotAvailable);
                }
                else if (rdoDam3.Checked)
                {
                    lon.LoanStatus = LoanStatus.Damaged;
                    LoanReturnMethod(lon, ResourceStatus.NotAvailable);
                }
            }

            MessageBox.Show("Selected Loan Returned");
            FormClear();
        }
        private void LoanReturnMethod(Loan lon,ResourceStatus resStat)
        {
            try
            {
                LoanBL lonBL = new LoanBL();

                    lonBL.ReturnLoan(lon,resStat);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void FormClear()
        {
            txtResource.Focus();
            pnlInfo.Visible = false;
            pnlResInfo.Visible = false;
            pnlResInfo2.Visible = false;
            pnlResInfo3.Visible = false;
            btnReturn.Visible = false;
        }
    }
}
