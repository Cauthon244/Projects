﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrontEnd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Loans checkOutForm;
        Returns returnForm;
        Reserve reserveForm;
        ModifyResourceStatus modResStatForm;
        Payments payForm;
        ManageStudents manStudForm;
        CreateStudent createStudForm;
        AddResource addResForm;
        private void Form1_Load(object sender, EventArgs e)
        {
            SplashForm mySplash = new SplashForm();
            mySplash.ShowDialog();
            Login myLog = new Login();
            myLog.ShowDialog();
            if (myLog.DialogResult != DialogResult.OK)
            {
                Close();
            }
            SetUpStatusStrip();
        }
        private void SetUpStatusStrip()
        {
            statusStrip1.LayoutStyle = ToolStripLayoutStyle.Table;

            toolStripStatusLabel1.Text = System.DateTime.Now.ToShortTimeString();
            toolStripStatusLabel1.TextAlign = ContentAlignment.MiddleLeft;
            toolStripStatusLabel1.BorderSides = ToolStripStatusLabelBorderSides.Right;

            toolStripStatusLabel2.Text = Environment.UserName;
            toolStripStatusLabel2.TextAlign = ContentAlignment.MiddleLeft;
            toolStripStatusLabel2.BorderSides = ToolStripStatusLabelBorderSides.Right;

            toolStripStatusLabel4.Text = "Ready...";
            toolStripStatusLabel4.TextAlign = ContentAlignment.MiddleRight;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = System.DateTime.Now.ToShortTimeString();
        }

        #region forms
        private void isOpen(Form thisForm)
        {
            if (tabControl1.Contains(thisForm))
            {
                tabControl1.TabPages[thisForm].Select();
            }
            else
                tabControl1.TabPages.Add(thisForm);
        }

        private void tsbReturn_Click(object sender, EventArgs e)
        {
            if (returnForm == null || returnForm.IsDisposed)
                returnForm = new Returns(this);
            isOpen(returnForm);
        }
        private void tsbCheckOut_Click(object sender, EventArgs e)
        {
            if (checkOutForm == null || checkOutForm.IsDisposed)
                checkOutForm = new Loans(this);
            isOpen(checkOutForm);
        }

        private void tsbReserve_Click(object sender, EventArgs e)
        {
            if (reserveForm == null || reserveForm.IsDisposed)
                reserveForm = new Reserve(this);
            isOpen(reserveForm);
        }
        

        private void modifyResourceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.Priviledge == "True")
            {
                if (modResStatForm == null || modResStatForm.IsDisposed)
                modResStatForm = new ModifyResourceStatus(this);
            isOpen(modResStatForm);
            }
            else
            {
                MessageBox.Show("You Lack Permissions For This Page.");
            }
        }

        private void makePaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (payForm == null || payForm.IsDisposed)
                payForm = new Payments(this);
            isOpen(payForm);
        }

        private void addResourceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.Head == "True")
            {
                if (addResForm == null || addResForm.IsDisposed)
                    addResForm = new AddResource(this);
                isOpen(addResForm);
            }
            else
            {
                MessageBox.Show("This Form is Accessible Only to The Department Head.");
            }
        }

        private void addStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.Priviledge == "True")
            {
                if (createStudForm == null || createStudForm.IsDisposed)
                    createStudForm = new CreateStudent(this);
                isOpen(createStudForm);
            }
            else
            {
                MessageBox.Show("You Lack Permissions For This Page.");
            }
        }

        private void maintainStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.Priviledge == "True")
            {
                if (manStudForm == null || manStudForm.IsDisposed)
                manStudForm = new ManageStudents(this);
            isOpen(manStudForm);
            }
            else
            {
                MessageBox.Show("You Lack Permissions For This Page.");
            }
        }
 #endregion
    }
}
