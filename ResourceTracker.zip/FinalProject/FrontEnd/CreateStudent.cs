﻿using BLL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrontEnd
{
    public partial class CreateStudent : Form
    {
        private Form1 myParent;
        public CreateStudent(Form1 Re)
        {
            InitializeComponent();
        }
        private List<Loan> loans = new List<Loan>();
        private Loan lon = new Loan();
        private Student stu = new Student();
        private Resource res = new Resource();

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                FillStudent();
                StudentBL stuBL = new StudentBL();
                    bool res = stuBL.addStudent(stu);

                    if (res)
                    {
                        MessageBox.Show("Student Added Successfully");
                    ResetForm();
                    }
                    else
                    {
                        string message = "";
                        foreach (ValidationErrors error in stuBL.validationErrors)
                        {
                            message += error.description + Environment.NewLine;
                        }
                        MessageBox.Show(message);
                    }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ResetForm()
        {
            foreach (Control control in pnlInfo.Controls)
            {
                if (control is TextBox)
                {
                    ((TextBox)control).Text = "";
                }
            }
            rdoStandard.Checked = true ;
            chkActive.Checked = true ;
            dtpEnd.ResetText();
            dtpStart.ResetText();
        }
        private void FillStudent()
        {
            stu = new Student();
            if (txtStudID.Text == ""||int.TryParse(txtStudID.Text,out int result)==false) { stu.StudentID = 0; }
            else { stu.StudentID = Convert.ToInt32(txtStudID.Text); }
            stu.FirstName = txtfName.Text.ToString();
            stu.LastName = txtLName.Text.ToString();
            if (rdoStandard.Checked) stu.Program = 1;
            else { stu.Program = 0; }
            stu.StudentStatus = Convert.ToInt32(chkActive.Checked);
            stu.StartDate = dtpStart.Value;
            stu.EndDate = dtpEnd.Value;
            stu.Address = txtAddress.Text.ToString();
            stu.City = txtCity.Text.ToString();
            stu.PostalCode = txtPostal.Text.ToString();
            stu.Phone = txtPhone.Text.ToString();
        }
    }
}
