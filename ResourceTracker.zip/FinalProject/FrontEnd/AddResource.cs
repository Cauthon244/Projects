﻿using BLL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Types;

namespace FrontEnd
{
    public partial class AddResource : Form
    {
        private Form1 myParent;
        public AddResource(Form1 Re)
        {
            InitializeComponent();
        }
        private List<Loan> loans = new List<Loan>();
        private Loan lon = new Loan();
        private Student stu = new Student();
        private Resource reso = new Resource();

        private void btnCreate_Click(object sender, EventArgs e)
        {
                try
                {
                    FillResource();
                    ResourceBL resBL = new ResourceBL();
                    bool res = resBL.addResource(reso);

                    if (res)
                    {
                        MessageBox.Show("Resource Added Successfully");
                        ResetForm();
                    }
                    else
                    {
                        string message = "";
                        foreach (ValidationErrors error in resBL.validationErrors)
                        {
                            message += error.description + Environment.NewLine;
                        }
                        MessageBox.Show(message);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }          
        }
        private void ResetForm()
            {
                foreach (Control control in pnlInfo.Controls)
                {
                    if (control is TextBox)
                    {
                        ((TextBox)control).Text = "";
                    }
                }
                dtpDoP.ResetText();
            }
        private void FillResource()
        {
            reso = new Resource();
            reso.ResourceName = txtResName.Text;
            reso.ResourceType = (ResourceType)Enum.Parse(typeof(ResourceType), cmbType.SelectedValue.ToString());
            reso.Publisher = txtPub.Text;
            if (txtPrice.Text == "" || double.TryParse(txtPrice.Text, out double result) == false|| Convert.ToDouble(txtPrice.Text)<1) { reso.Price = null; }
            else { reso.Price = Convert.ToDouble(txtPrice.Text); }
            if (txtPubID.Text == "" || int.TryParse(txtPubID.Text, out int result2) == false) { reso.PubID = null; }
            else { reso.PubID = Convert.ToInt32(txtPubID.Text); }
            reso.DateOfPurchase = dtpDoP.Value;
            reso.Image = txtImage.Text;
            reso.Description = txtDescript.Text;
        }

        private void AddResource_Load(object sender, EventArgs e)
        {
            cmbType.DataSource = Enum.GetValues(typeof(ResourceType));
            txtResName.Focus();

        }
    }
}
