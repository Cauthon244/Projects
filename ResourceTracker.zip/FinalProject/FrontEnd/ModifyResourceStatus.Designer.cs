﻿namespace FrontEnd
{
    partial class ModifyResourceStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblResSearch = new System.Windows.Forms.Label();
            this.btnResSearch = new System.Windows.Forms.Button();
            this.txtResource = new System.Windows.Forms.TextBox();
            this.pnlResInfo = new System.Windows.Forms.Panel();
            this.chkAvailable = new System.Windows.Forms.CheckBox();
            this.lblResStatTitle = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblResID = new System.Windows.Forms.Label();
            this.lblResources = new System.Windows.Forms.Label();
            this.lblResTitleTitle = new System.Windows.Forms.Label();
            this.lblReserveStatTitle = new System.Windows.Forms.Label();
            this.lblResTypeTitle = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtType = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtPub = new System.Windows.Forms.TextBox();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.txtDoP = new System.Windows.Forms.TextBox();
            this.txtDateRem = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.pnlResInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblResSearch
            // 
            this.lblResSearch.AutoSize = true;
            this.lblResSearch.Location = new System.Drawing.Point(150, 139);
            this.lblResSearch.Name = "lblResSearch";
            this.lblResSearch.Size = new System.Drawing.Size(143, 17);
            this.lblResSearch.TabIndex = 53;
            this.lblResSearch.Text = "Search For Resource";
            // 
            // btnResSearch
            // 
            this.btnResSearch.Location = new System.Drawing.Point(167, 207);
            this.btnResSearch.Name = "btnResSearch";
            this.btnResSearch.Size = new System.Drawing.Size(97, 30);
            this.btnResSearch.TabIndex = 52;
            this.btnResSearch.Text = "Search";
            this.btnResSearch.UseVisualStyleBackColor = true;
            this.btnResSearch.Click += new System.EventHandler(this.btnResSearch_Click);
            // 
            // txtResource
            // 
            this.txtResource.Location = new System.Drawing.Point(104, 164);
            this.txtResource.Name = "txtResource";
            this.txtResource.Size = new System.Drawing.Size(224, 22);
            this.txtResource.TabIndex = 51;
            // 
            // pnlResInfo
            // 
            this.pnlResInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlResInfo.Controls.Add(this.txtTitle);
            this.pnlResInfo.Controls.Add(this.txtDateRem);
            this.pnlResInfo.Controls.Add(this.txtDoP);
            this.pnlResInfo.Controls.Add(this.txtStatus);
            this.pnlResInfo.Controls.Add(this.txtPub);
            this.pnlResInfo.Controls.Add(this.txtPrice);
            this.pnlResInfo.Controls.Add(this.txtType);
            this.pnlResInfo.Controls.Add(this.chkAvailable);
            this.pnlResInfo.Controls.Add(this.lblResStatTitle);
            this.pnlResInfo.Controls.Add(this.label1);
            this.pnlResInfo.Controls.Add(this.label2);
            this.pnlResInfo.Controls.Add(this.label4);
            this.pnlResInfo.Controls.Add(this.label6);
            this.pnlResInfo.Controls.Add(this.lblResID);
            this.pnlResInfo.Controls.Add(this.lblResources);
            this.pnlResInfo.Controls.Add(this.lblResTitleTitle);
            this.pnlResInfo.Controls.Add(this.lblReserveStatTitle);
            this.pnlResInfo.Controls.Add(this.lblResTypeTitle);
            this.pnlResInfo.Location = new System.Drawing.Point(387, 127);
            this.pnlResInfo.Name = "pnlResInfo";
            this.pnlResInfo.Size = new System.Drawing.Size(541, 353);
            this.pnlResInfo.TabIndex = 54;
            this.pnlResInfo.Visible = false;
            // 
            // chkAvailable
            // 
            this.chkAvailable.AutoSize = true;
            this.chkAvailable.Location = new System.Drawing.Point(149, 315);
            this.chkAvailable.Name = "chkAvailable";
            this.chkAvailable.Size = new System.Drawing.Size(95, 21);
            this.chkAvailable.TabIndex = 55;
            this.chkAvailable.Text = "Available?";
            this.chkAvailable.UseVisualStyleBackColor = true;
            // 
            // lblResStatTitle
            // 
            this.lblResStatTitle.AutoSize = true;
            this.lblResStatTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResStatTitle.Location = new System.Drawing.Point(146, 294);
            this.lblResStatTitle.Name = "lblResStatTitle";
            this.lblResStatTitle.Size = new System.Drawing.Size(128, 17);
            this.lblResStatTitle.TabIndex = 39;
            this.lblResStatTitle.Text = "Resource Status";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 171);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 17);
            this.label1.TabIndex = 47;
            this.label1.Text = "Publisher";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(294, 234);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 17);
            this.label2.TabIndex = 48;
            this.label2.Text = "Date Removed";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(294, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 17);
            this.label4.TabIndex = 49;
            this.label4.Text = "DateOfPurchase";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(34, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 17);
            this.label6.TabIndex = 50;
            this.label6.Text = "Price";
            // 
            // lblResID
            // 
            this.lblResID.AutoSize = true;
            this.lblResID.Location = new System.Drawing.Point(146, 18);
            this.lblResID.Name = "lblResID";
            this.lblResID.Size = new System.Drawing.Size(0, 17);
            this.lblResID.TabIndex = 46;
            this.lblResID.Visible = false;
            // 
            // lblResources
            // 
            this.lblResources.AutoSize = true;
            this.lblResources.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResources.Location = new System.Drawing.Point(16, 11);
            this.lblResources.Name = "lblResources";
            this.lblResources.Size = new System.Drawing.Size(132, 25);
            this.lblResources.TabIndex = 37;
            this.lblResources.Text = "Resource Info";
            // 
            // lblResTitleTitle
            // 
            this.lblResTitleTitle.AutoSize = true;
            this.lblResTitleTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResTitleTitle.Location = new System.Drawing.Point(204, 36);
            this.lblResTitleTitle.Name = "lblResTitleTitle";
            this.lblResTitleTitle.Size = new System.Drawing.Size(40, 17);
            this.lblResTitleTitle.TabIndex = 36;
            this.lblResTitleTitle.Text = "Title";
            // 
            // lblReserveStatTitle
            // 
            this.lblReserveStatTitle.AutoSize = true;
            this.lblReserveStatTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReserveStatTitle.Location = new System.Drawing.Point(294, 104);
            this.lblReserveStatTitle.Name = "lblReserveStatTitle";
            this.lblReserveStatTitle.Size = new System.Drawing.Size(119, 17);
            this.lblReserveStatTitle.TabIndex = 38;
            this.lblReserveStatTitle.Text = "Reserve Status";
            // 
            // lblResTypeTitle
            // 
            this.lblResTypeTitle.AutoSize = true;
            this.lblResTypeTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResTypeTitle.Location = new System.Drawing.Point(34, 104);
            this.lblResTypeTitle.Name = "lblResTypeTitle";
            this.lblResTypeTitle.Size = new System.Drawing.Size(44, 17);
            this.lblResTypeTitle.TabIndex = 40;
            this.lblResTypeTitle.Text = "Type";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(580, 486);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(118, 47);
            this.btnUpdate.TabIndex = 45;
            this.btnUpdate.Text = "Update Status";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Visible = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(21, 124);
            this.txtType.Name = "txtType";
            this.txtType.ReadOnly = true;
            this.txtType.Size = new System.Drawing.Size(223, 22);
            this.txtType.TabIndex = 56;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(21, 254);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.ReadOnly = true;
            this.txtPrice.Size = new System.Drawing.Size(223, 22);
            this.txtPrice.TabIndex = 60;
            // 
            // txtPub
            // 
            this.txtPub.Location = new System.Drawing.Point(21, 191);
            this.txtPub.Name = "txtPub";
            this.txtPub.ReadOnly = true;
            this.txtPub.Size = new System.Drawing.Size(223, 22);
            this.txtPub.TabIndex = 61;
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(297, 124);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.ReadOnly = true;
            this.txtStatus.Size = new System.Drawing.Size(223, 22);
            this.txtStatus.TabIndex = 62;
            // 
            // txtDoP
            // 
            this.txtDoP.Location = new System.Drawing.Point(297, 191);
            this.txtDoP.Name = "txtDoP";
            this.txtDoP.ReadOnly = true;
            this.txtDoP.Size = new System.Drawing.Size(223, 22);
            this.txtDoP.TabIndex = 63;
            // 
            // txtDateRem
            // 
            this.txtDateRem.Location = new System.Drawing.Point(297, 254);
            this.txtDateRem.Name = "txtDateRem";
            this.txtDateRem.ReadOnly = true;
            this.txtDateRem.Size = new System.Drawing.Size(223, 22);
            this.txtDateRem.TabIndex = 64;
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(121, 56);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.ReadOnly = true;
            this.txtTitle.Size = new System.Drawing.Size(223, 22);
            this.txtTitle.TabIndex = 65;
            // 
            // ModifyResourceStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 773);
            this.Controls.Add(this.lblResSearch);
            this.Controls.Add(this.btnResSearch);
            this.Controls.Add(this.txtResource);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.pnlResInfo);
            this.Name = "ModifyResourceStatus";
            this.Text = "ModifyResourceStatus";
            this.Load += new System.EventHandler(this.ModifyResourceStatus_Load);
            this.pnlResInfo.ResumeLayout(false);
            this.pnlResInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblResSearch;
        private System.Windows.Forms.Button btnResSearch;
        private System.Windows.Forms.TextBox txtResource;
        private System.Windows.Forms.Panel pnlResInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblResID;
        private System.Windows.Forms.Label lblResources;
        private System.Windows.Forms.Label lblResTitleTitle;
        private System.Windows.Forms.Label lblReserveStatTitle;
        private System.Windows.Forms.Label lblResTypeTitle;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.CheckBox chkAvailable;
        private System.Windows.Forms.Label lblResStatTitle;
        private System.Windows.Forms.TextBox txtDateRem;
        private System.Windows.Forms.TextBox txtDoP;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.TextBox txtPub;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.TextBox txtTitle;
    }
}