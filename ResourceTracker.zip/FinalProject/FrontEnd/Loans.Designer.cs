﻿namespace FrontEnd
{
    partial class Loans
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Loans));
            this.txtSearchStud = new System.Windows.Forms.TextBox();
            this.btnStudSearch = new System.Windows.Forms.Button();
            this.txtfName = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtProgram = new System.Windows.Forms.TextBox();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.txtStudentStatus = new System.Windows.Forms.TextBox();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.lblStudent = new System.Windows.Forms.Label();
            this.lblLName = new System.Windows.Forms.Label();
            this.lblProgram = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblFName = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.lblStudStatus = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblStudSearch = new System.Windows.Forms.Label();
            this.lblResSearch = new System.Windows.Forms.Label();
            this.btnResSearch = new System.Windows.Forms.Button();
            this.txtResource = new System.Windows.Forms.TextBox();
            this.lblResTitleTitle = new System.Windows.Forms.Label();
            this.lblResources = new System.Windows.Forms.Label();
            this.lblReserveStatTitle = new System.Windows.Forms.Label();
            this.lblResStatTitle = new System.Windows.Forms.Label();
            this.lblResTypeTitle = new System.Windows.Forms.Label();
            this.lblResTitle = new System.Windows.Forms.Label();
            this.lblResType = new System.Windows.Forms.Label();
            this.lblResStatus = new System.Windows.Forms.Label();
            this.lblReserveStat = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.cmbSearchResult = new System.Windows.Forms.ComboBox();
            this.pnlInfo = new System.Windows.Forms.Panel();
            this.lblOutstanding = new System.Windows.Forms.Label();
            this.dgvLoans = new System.Windows.Forms.DataGridView();
            this.pnlResInfo = new System.Windows.Forms.Panel();
            this.lblResID = new System.Windows.Forms.Label();
            this.lblSelRes = new System.Windows.Forms.Label();
            this.btnCreateLoan = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.lstSelRes = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoans)).BeginInit();
            this.pnlResInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSearchStud
            // 
            this.txtSearchStud.Location = new System.Drawing.Point(40, 53);
            this.txtSearchStud.Name = "txtSearchStud";
            this.txtSearchStud.Size = new System.Drawing.Size(224, 22);
            this.txtSearchStud.TabIndex = 1;
            // 
            // btnStudSearch
            // 
            this.btnStudSearch.Location = new System.Drawing.Point(102, 85);
            this.btnStudSearch.Name = "btnStudSearch";
            this.btnStudSearch.Size = new System.Drawing.Size(97, 30);
            this.btnStudSearch.TabIndex = 2;
            this.btnStudSearch.Text = "Search";
            this.btnStudSearch.UseVisualStyleBackColor = true;
            this.btnStudSearch.Click += new System.EventHandler(this.btnStudSearch_Click);
            // 
            // txtfName
            // 
            this.txtfName.Location = new System.Drawing.Point(115, 42);
            this.txtfName.Name = "txtfName";
            this.txtfName.ReadOnly = true;
            this.txtfName.Size = new System.Drawing.Size(200, 22);
            this.txtfName.TabIndex = 3;
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(115, 70);
            this.txtLName.Name = "txtLName";
            this.txtLName.ReadOnly = true;
            this.txtLName.Size = new System.Drawing.Size(200, 22);
            this.txtLName.TabIndex = 4;
            // 
            // txtProgram
            // 
            this.txtProgram.Location = new System.Drawing.Point(115, 126);
            this.txtProgram.Name = "txtProgram";
            this.txtProgram.ReadOnly = true;
            this.txtProgram.Size = new System.Drawing.Size(200, 22);
            this.txtProgram.TabIndex = 5;
            // 
            // txtBalance
            // 
            this.txtBalance.Location = new System.Drawing.Point(115, 98);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.Size = new System.Drawing.Size(200, 22);
            this.txtBalance.TabIndex = 6;
            // 
            // txtStudentStatus
            // 
            this.txtStudentStatus.Location = new System.Drawing.Point(115, 154);
            this.txtStudentStatus.Name = "txtStudentStatus";
            this.txtStudentStatus.ReadOnly = true;
            this.txtStudentStatus.Size = new System.Drawing.Size(200, 22);
            this.txtStudentStatus.TabIndex = 7;
            // 
            // dtpEnd
            // 
            this.dtpEnd.Enabled = false;
            this.dtpEnd.Location = new System.Drawing.Point(115, 210);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(200, 22);
            this.dtpEnd.TabIndex = 8;
            // 
            // dtpStart
            // 
            this.dtpStart.Enabled = false;
            this.dtpStart.Location = new System.Drawing.Point(115, 182);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(200, 22);
            this.dtpStart.TabIndex = 9;
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudent.Location = new System.Drawing.Point(98, 6);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(117, 25);
            this.lblStudent.TabIndex = 16;
            this.lblStudent.Text = "Student Info";
            // 
            // lblLName
            // 
            this.lblLName.AutoSize = true;
            this.lblLName.Location = new System.Drawing.Point(33, 73);
            this.lblLName.Name = "lblLName";
            this.lblLName.Size = new System.Drawing.Size(76, 17);
            this.lblLName.TabIndex = 17;
            this.lblLName.Text = "Last Name";
            // 
            // lblProgram
            // 
            this.lblProgram.AutoSize = true;
            this.lblProgram.Location = new System.Drawing.Point(47, 129);
            this.lblProgram.Name = "lblProgram";
            this.lblProgram.Size = new System.Drawing.Size(62, 17);
            this.lblProgram.TabIndex = 18;
            this.lblProgram.Text = "Program";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(37, 187);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(72, 17);
            this.lblStartDate.TabIndex = 19;
            this.lblStartDate.Text = "Start Date";
            // 
            // lblFName
            // 
            this.lblFName.AutoSize = true;
            this.lblFName.Location = new System.Drawing.Point(33, 45);
            this.lblFName.Name = "lblFName";
            this.lblFName.Size = new System.Drawing.Size(76, 17);
            this.lblFName.TabIndex = 25;
            this.lblFName.Text = "First Name";
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Enabled = false;
            this.lblBalance.Location = new System.Drawing.Point(20, 101);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(89, 17);
            this.lblBalance.TabIndex = 26;
            this.lblBalance.Text = "Balance Due";
            // 
            // lblStudStatus
            // 
            this.lblStudStatus.AutoSize = true;
            this.lblStudStatus.Location = new System.Drawing.Point(8, 157);
            this.lblStudStatus.Name = "lblStudStatus";
            this.lblStudStatus.Size = new System.Drawing.Size(101, 17);
            this.lblStudStatus.TabIndex = 27;
            this.lblStudStatus.Text = "Student Status";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Location = new System.Drawing.Point(47, 215);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(67, 17);
            this.lblEndDate.TabIndex = 29;
            this.lblEndDate.Text = "End Date";
            // 
            // lblStudSearch
            // 
            this.lblStudSearch.AutoSize = true;
            this.lblStudSearch.Location = new System.Drawing.Point(86, 33);
            this.lblStudSearch.Name = "lblStudSearch";
            this.lblStudSearch.Size = new System.Drawing.Size(131, 17);
            this.lblStudSearch.TabIndex = 31;
            this.lblStudSearch.Text = "Search For Student";
            // 
            // lblResSearch
            // 
            this.lblResSearch.AutoSize = true;
            this.lblResSearch.Location = new System.Drawing.Point(73, 624);
            this.lblResSearch.Name = "lblResSearch";
            this.lblResSearch.Size = new System.Drawing.Size(143, 17);
            this.lblResSearch.TabIndex = 35;
            this.lblResSearch.Text = "Search For Resource";
            this.lblResSearch.Visible = false;
            // 
            // btnResSearch
            // 
            this.btnResSearch.Location = new System.Drawing.Point(90, 692);
            this.btnResSearch.Name = "btnResSearch";
            this.btnResSearch.Size = new System.Drawing.Size(97, 30);
            this.btnResSearch.TabIndex = 34;
            this.btnResSearch.Text = "Search";
            this.btnResSearch.UseVisualStyleBackColor = true;
            this.btnResSearch.Visible = false;
            this.btnResSearch.Click += new System.EventHandler(this.btnResSearch_Click);
            // 
            // txtResource
            // 
            this.txtResource.Location = new System.Drawing.Point(27, 649);
            this.txtResource.Name = "txtResource";
            this.txtResource.Size = new System.Drawing.Size(224, 22);
            this.txtResource.TabIndex = 33;
            this.txtResource.Visible = false;
            // 
            // lblResTitleTitle
            // 
            this.lblResTitleTitle.AutoSize = true;
            this.lblResTitleTitle.Location = new System.Drawing.Point(34, 41);
            this.lblResTitleTitle.Name = "lblResTitleTitle";
            this.lblResTitleTitle.Size = new System.Drawing.Size(35, 17);
            this.lblResTitleTitle.TabIndex = 36;
            this.lblResTitleTitle.Text = "Title";
            // 
            // lblResources
            // 
            this.lblResources.AutoSize = true;
            this.lblResources.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResources.Location = new System.Drawing.Point(16, 11);
            this.lblResources.Name = "lblResources";
            this.lblResources.Size = new System.Drawing.Size(132, 25);
            this.lblResources.TabIndex = 37;
            this.lblResources.Text = "Resource Info";
            // 
            // lblReserveStatTitle
            // 
            this.lblReserveStatTitle.AutoSize = true;
            this.lblReserveStatTitle.Location = new System.Drawing.Point(262, 104);
            this.lblReserveStatTitle.Name = "lblReserveStatTitle";
            this.lblReserveStatTitle.Size = new System.Drawing.Size(105, 17);
            this.lblReserveStatTitle.TabIndex = 38;
            this.lblReserveStatTitle.Text = "Reserve Status";
            // 
            // lblResStatTitle
            // 
            this.lblResStatTitle.AutoSize = true;
            this.lblResStatTitle.Location = new System.Drawing.Point(262, 41);
            this.lblResStatTitle.Name = "lblResStatTitle";
            this.lblResStatTitle.Size = new System.Drawing.Size(113, 17);
            this.lblResStatTitle.TabIndex = 39;
            this.lblResStatTitle.Text = "Resource Status";
            // 
            // lblResTypeTitle
            // 
            this.lblResTypeTitle.AutoSize = true;
            this.lblResTypeTitle.Location = new System.Drawing.Point(34, 104);
            this.lblResTypeTitle.Name = "lblResTypeTitle";
            this.lblResTypeTitle.Size = new System.Drawing.Size(40, 17);
            this.lblResTypeTitle.TabIndex = 40;
            this.lblResTypeTitle.Text = "Type";
            // 
            // lblResTitle
            // 
            this.lblResTitle.AutoSize = true;
            this.lblResTitle.Location = new System.Drawing.Point(34, 58);
            this.lblResTitle.Name = "lblResTitle";
            this.lblResTitle.Size = new System.Drawing.Size(46, 17);
            this.lblResTitle.TabIndex = 41;
            this.lblResTitle.Text = "label5";
            // 
            // lblResType
            // 
            this.lblResType.AutoSize = true;
            this.lblResType.Location = new System.Drawing.Point(34, 121);
            this.lblResType.Name = "lblResType";
            this.lblResType.Size = new System.Drawing.Size(46, 17);
            this.lblResType.TabIndex = 42;
            this.lblResType.Text = "label6";
            // 
            // lblResStatus
            // 
            this.lblResStatus.AutoSize = true;
            this.lblResStatus.Location = new System.Drawing.Point(262, 58);
            this.lblResStatus.Name = "lblResStatus";
            this.lblResStatus.Size = new System.Drawing.Size(46, 17);
            this.lblResStatus.TabIndex = 43;
            this.lblResStatus.Text = "label7";
            // 
            // lblReserveStat
            // 
            this.lblReserveStat.AutoSize = true;
            this.lblReserveStat.Location = new System.Drawing.Point(262, 121);
            this.lblReserveStat.Name = "lblReserveStat";
            this.lblReserveStat.Size = new System.Drawing.Size(46, 17);
            this.lblReserveStat.TabIndex = 44;
            this.lblReserveStat.Text = "label8";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(402, 102);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 47);
            this.btnAdd.TabIndex = 45;
            this.btnAdd.Text = "Add To List";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // cmbSearchResult
            // 
            this.cmbSearchResult.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSearchResult.FormattingEnabled = true;
            this.cmbSearchResult.Location = new System.Drawing.Point(39, 123);
            this.cmbSearchResult.Name = "cmbSearchResult";
            this.cmbSearchResult.Size = new System.Drawing.Size(224, 24);
            this.cmbSearchResult.TabIndex = 46;
            this.cmbSearchResult.Visible = false;
            this.cmbSearchResult.SelectionChangeCommitted += new System.EventHandler(this.cmbSearchResult_SelectionChangeCommitted);
            // 
            // pnlInfo
            // 
            this.pnlInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInfo.Controls.Add(this.txtfName);
            this.pnlInfo.Controls.Add(this.txtLName);
            this.pnlInfo.Controls.Add(this.txtProgram);
            this.pnlInfo.Controls.Add(this.txtBalance);
            this.pnlInfo.Controls.Add(this.txtStudentStatus);
            this.pnlInfo.Controls.Add(this.dtpEnd);
            this.pnlInfo.Controls.Add(this.dtpStart);
            this.pnlInfo.Controls.Add(this.lblStudent);
            this.pnlInfo.Controls.Add(this.lblLName);
            this.pnlInfo.Controls.Add(this.lblProgram);
            this.pnlInfo.Controls.Add(this.lblStartDate);
            this.pnlInfo.Controls.Add(this.lblEndDate);
            this.pnlInfo.Controls.Add(this.lblStudStatus);
            this.pnlInfo.Controls.Add(this.lblBalance);
            this.pnlInfo.Controls.Add(this.lblFName);
            this.pnlInfo.Location = new System.Drawing.Point(360, 53);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(348, 244);
            this.pnlInfo.TabIndex = 48;
            this.pnlInfo.Visible = false;
            // 
            // lblOutstanding
            // 
            this.lblOutstanding.AutoSize = true;
            this.lblOutstanding.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutstanding.Location = new System.Drawing.Point(267, 300);
            this.lblOutstanding.Name = "lblOutstanding";
            this.lblOutstanding.Size = new System.Drawing.Size(177, 25);
            this.lblOutstanding.TabIndex = 30;
            this.lblOutstanding.Text = "Outstanding Loans";
            this.lblOutstanding.Visible = false;
            // 
            // dgvLoans
            // 
            this.dgvLoans.AllowUserToAddRows = false;
            this.dgvLoans.AllowUserToDeleteRows = false;
            this.dgvLoans.AllowUserToResizeColumns = false;
            this.dgvLoans.AllowUserToResizeRows = false;
            this.dgvLoans.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLoans.Location = new System.Drawing.Point(26, 328);
            this.dgvLoans.Name = "dgvLoans";
            this.dgvLoans.RowTemplate.Height = 24;
            this.dgvLoans.Size = new System.Drawing.Size(682, 238);
            this.dgvLoans.TabIndex = 49;
            this.dgvLoans.Visible = false;
            // 
            // pnlResInfo
            // 
            this.pnlResInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlResInfo.Controls.Add(this.lblResID);
            this.pnlResInfo.Controls.Add(this.lblResources);
            this.pnlResInfo.Controls.Add(this.lblResTitleTitle);
            this.pnlResInfo.Controls.Add(this.btnAdd);
            this.pnlResInfo.Controls.Add(this.lblReserveStatTitle);
            this.pnlResInfo.Controls.Add(this.lblReserveStat);
            this.pnlResInfo.Controls.Add(this.lblResStatTitle);
            this.pnlResInfo.Controls.Add(this.lblResStatus);
            this.pnlResInfo.Controls.Add(this.lblResTypeTitle);
            this.pnlResInfo.Controls.Add(this.lblResType);
            this.pnlResInfo.Controls.Add(this.lblResTitle);
            this.pnlResInfo.Location = new System.Drawing.Point(290, 582);
            this.pnlResInfo.Name = "pnlResInfo";
            this.pnlResInfo.Size = new System.Drawing.Size(514, 162);
            this.pnlResInfo.TabIndex = 50;
            this.pnlResInfo.Visible = false;
            // 
            // lblResID
            // 
            this.lblResID.AutoSize = true;
            this.lblResID.Location = new System.Drawing.Point(146, 18);
            this.lblResID.Name = "lblResID";
            this.lblResID.Size = new System.Drawing.Size(0, 17);
            this.lblResID.TabIndex = 46;
            this.lblResID.Visible = false;
            // 
            // lblSelRes
            // 
            this.lblSelRes.AutoSize = true;
            this.lblSelRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelRes.Location = new System.Drawing.Point(845, 554);
            this.lblSelRes.Name = "lblSelRes";
            this.lblSelRes.Size = new System.Drawing.Size(187, 25);
            this.lblSelRes.TabIndex = 51;
            this.lblSelRes.Text = "Selected Resources";
            this.lblSelRes.Visible = false;
            // 
            // btnCreateLoan
            // 
            this.btnCreateLoan.Location = new System.Drawing.Point(948, 704);
            this.btnCreateLoan.Name = "btnCreateLoan";
            this.btnCreateLoan.Size = new System.Drawing.Size(100, 47);
            this.btnCreateLoan.TabIndex = 53;
            this.btnCreateLoan.Text = "Create Loan";
            this.btnCreateLoan.UseVisualStyleBackColor = true;
            this.btnCreateLoan.Visible = false;
            this.btnCreateLoan.Click += new System.EventHandler(this.btnCreateLoan_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(810, 704);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(130, 47);
            this.btnRemove.TabIndex = 55;
            this.btnRemove.Text = "Remove Selected";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Visible = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // lstSelRes
            // 
            this.lstSelRes.FormattingEnabled = true;
            this.lstSelRes.ItemHeight = 16;
            this.lstSelRes.Location = new System.Drawing.Point(810, 582);
            this.lstSelRes.Name = "lstSelRes";
            this.lstSelRes.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lstSelRes.Size = new System.Drawing.Size(238, 116);
            this.lstSelRes.TabIndex = 56;
            this.lstSelRes.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.ErrorImage")));
            this.pictureBox1.Location = new System.Drawing.Point(730, 328);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(318, 223);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 57;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // Loans
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 773);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lstSelRes);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnCreateLoan);
            this.Controls.Add(this.lblSelRes);
            this.Controls.Add(this.dgvLoans);
            this.Controls.Add(this.cmbSearchResult);
            this.Controls.Add(this.lblOutstanding);
            this.Controls.Add(this.lblResSearch);
            this.Controls.Add(this.btnResSearch);
            this.Controls.Add(this.txtResource);
            this.Controls.Add(this.lblStudSearch);
            this.Controls.Add(this.btnStudSearch);
            this.Controls.Add(this.txtSearchStud);
            this.Controls.Add(this.pnlInfo);
            this.Controls.Add(this.pnlResInfo);
            this.Name = "Loans";
            this.Text = "Loans";
            this.Load += new System.EventHandler(this.Loans_Load);
            this.pnlInfo.ResumeLayout(false);
            this.pnlInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLoans)).EndInit();
            this.pnlResInfo.ResumeLayout(false);
            this.pnlResInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtSearchStud;
        private System.Windows.Forms.Button btnStudSearch;
        private System.Windows.Forms.TextBox txtfName;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtProgram;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.TextBox txtStudentStatus;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.Label lblStudent;
        private System.Windows.Forms.Label lblLName;
        private System.Windows.Forms.Label lblProgram;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblFName;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label lblStudStatus;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblStudSearch;
        private System.Windows.Forms.Label lblResSearch;
        private System.Windows.Forms.Button btnResSearch;
        private System.Windows.Forms.TextBox txtResource;
        private System.Windows.Forms.Label lblResTitleTitle;
        private System.Windows.Forms.Label lblResources;
        private System.Windows.Forms.Label lblReserveStatTitle;
        private System.Windows.Forms.Label lblResStatTitle;
        private System.Windows.Forms.Label lblResTypeTitle;
        private System.Windows.Forms.Label lblResTitle;
        private System.Windows.Forms.Label lblResType;
        private System.Windows.Forms.Label lblResStatus;
        private System.Windows.Forms.Label lblReserveStat;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ComboBox cmbSearchResult;
        private System.Windows.Forms.Panel pnlInfo;
        private System.Windows.Forms.Label lblOutstanding;
        private System.Windows.Forms.DataGridView dgvLoans;
        private System.Windows.Forms.Panel pnlResInfo;
        private System.Windows.Forms.Label lblResID;
        private System.Windows.Forms.Label lblSelRes;
        private System.Windows.Forms.Button btnCreateLoan;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.ListBox lstSelRes;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}