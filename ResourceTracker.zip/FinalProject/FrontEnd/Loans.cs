﻿using BLL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Types;
using static Model.Lists.Lookups;


namespace FrontEnd
{
    public partial class Loans : Form
    {
        private Form1 myParent;
        public Loans(Form1 Re)
        {
            InitializeComponent();
        }
        private List<Loan> loans = new List<Loan>();
        private Loan lon = new Loan();
        private Student stu = new Student();
        private Resource res = new Resource();
        private void btnStudSearch_Click(object sender, EventArgs e)
        {
            string errMsg = CheckNameAndLength();

            if (errMsg != string.Empty)
            {
                MessageBox.Show(errMsg);
            }
            else
            {
                
                ListsBL listsBl = new ListsBL();
                List<StudentLookup> sups = listsBl.GetStudentList(txtSearchStud.Text);
                if (sups.Count > 0)
                {
                    cmbSearchResult.DataSource = sups;
                    cmbSearchResult.DisplayMember = "LastName";
                    cmbSearchResult.ValueMember = "StudentId";
                    cmbSearchResult.SelectedIndex = 0;
                    cmbSearchResult.Visible = true;
                }
                else
                {
                    MessageBox.Show("No Student With That Name or ID, Please Try Again.");
                }
            }
        }

        private string CheckNameAndLength()
        {
            string errMsg = string.Empty;
            if (txtSearchStud.Text == string.Empty || txtSearchStud.TextLength > 50)
            {
                errMsg = "Please Supply a Valid Name.";
            }
            return errMsg;
        }

        private void cmbSearchResult_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                
                    StudentBL StuBL = new StudentBL();
                    stu = StuBL.getStudent(Convert.ToInt32(cmbSearchResult.SelectedValue));
                
                PopulateStudentRecord();
                FillDataGridView();
                txtResource.Visible = true;
                lblResSearch.Visible = true;
                btnResSearch.Visible = true;
                lblOutstanding.Visible = true;
                dgvLoans.Visible = true;
                pnlInfo.Visible = true;
                txtResource.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void FillDataGridView()
        {
            LoanBL lnBl = new LoanBL();
            DataTable Basic = new DataTable();
            Basic = lnBl.GetLoan(Convert.ToInt32(cmbSearchResult.SelectedValue));
            dgvLoans.DataSource = Basic;
            dgvLoans.RowHeadersVisible = false;
            dgvLoans.AutoSizeColumnsMode =
            DataGridViewAutoSizeColumnsMode.Fill;
            dgvLoans.Columns[0].HeaderText = "Resource Id";
            dgvLoans.Columns[1].HeaderText = "Resource Type";
            dgvLoans.Columns[2].HeaderText = "Check Out Date";
            dgvLoans.Columns[3].HeaderText = "Due Date";
            dgvLoans.Columns[4].HeaderText = "Loan Status";
            dgvLoans.Columns[5].HeaderText = "Student ID";
            dgvLoans.Columns[6].HeaderText = "Loan ID";
        }
        private void PopulateStudentRecord()
        {
            txtfName.Text = stu.FirstName.ToString();
            txtLName.Text = stu.LastName.ToString();
            if (stu.Program.ToString() == "True") { txtProgram.Text = "Regular Program"; }
            else { txtProgram.Text = "Block Release"; }
            if (Convert.ToInt32(stu.StudentStatus) == 1) { txtStudentStatus.Text = "Active";}
            else { txtStudentStatus.Text = "Inactive";}
            txtBalance.Text = stu.BalanceDue.ToString("c");
            dtpStart.Text = stu.StartDate.ToString();
            dtpEnd.Text = stu.EndDate.ToString();
        }
        private void PopulateResourceRecord()
        {
            pictureBox1.Image = Image.FromFile("D:\\Adam\\N-TIER\\FinalProject\\images\\"+res.Image.ToString());
            lblResID.Text = res.ResourceID.ToString();
            lblResTitle.Text = res.ResourceName.ToString();
            lblResType.Text = res.ResourceType.ToString();
            lblResStatus.Text = res.ResourceStatus.ToString();
            if (Convert.ToInt32(res.ReserveStatus) == 1) { lblReserveStat.Text = "Reserved"; }
            else { lblReserveStat.Text = "Available"; }
        }
        private void btnResSearch_Click(object sender, EventArgs e)
        {
            string errMsg = CheckResourceID();

            if (errMsg != string.Empty)
            {
                MessageBox.Show(errMsg);
            }
            else
            {
                try
                {

                    ResourceBL ResBL = new ResourceBL();
                    if (!int.TryParse(txtResource.Text, out int result)) { MessageBox.Show("No Resource With That ID, Please Try Again."); }
                    else
                    {
                        res = ResBL.getResource(txtResource.Text);
                        if (res != null)
                        {
                            PopulateResourceRecord();
                            pnlResInfo.Visible = true;
                            pictureBox1.Visible = true;
                        }
                        else
                        {
                            MessageBox.Show("No Resource With That ID, Please Try Again.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
            private string CheckResourceID()
            {
                string errMsg = string.Empty;
                if (txtResource.Text == string.Empty)
                {
                    errMsg = "Please Supply a Valid ID.";
                }
                return errMsg;
            }
        private void FillLoan()
        {
            lon = new Loan();
            lon.ResourceID = Convert.ToInt32(lblResID.Text);
            lon.ResourceType = (ResourceType)Enum.Parse(typeof(ResourceType),lblResType.Text);
            lon.LoanStatus = Types.LoanStatus.OnLoan;
            lon.StudentID = Convert.ToInt32(cmbSearchResult.SelectedValue);
            lon.DueDate = DateTime.Today.AddHours(8).AddMinutes(30).AddDays(2);
            if (lon.DueDate.DayOfWeek.ToString() == "Saturday") { lon.DueDate.AddDays(2); }
            if (lon.DueDate.DayOfWeek.ToString() == "Sunday") { lon.DueDate.AddDays(1); }
        }
        private bool checkListDupes()
        {
            foreach (Loan loan in loans)
            {
                if (loan.ResourceID == Convert.ToInt32(lblResID.Text))
                {
                    return false;
                }
                if(loan.ResourceType.ToString()== lblResType.Text)
                {
                    return false;
                }
                return true;
            }
            return true;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (checkListDupes())
                {
                    FillLoan();
                    LoanBL lonBL = new LoanBL();
                    bool res = lonBL.testLoan(lon);
                    if (res)
                    {
                        
                        loans.Add(lon);
                        lstSelRes.Items.Add(lblResTitle.Text);
                        MessageBox.Show("Added To List");
                        loanAddClear();
                        lstSelRes.Visible = true;
                        btnCreateLoan.Visible = true;
                        lblSelRes.Visible = true;
                        btnRemove.Visible = true;
                    }
                    else
                    {
                        string message = "";
                        foreach (ValidationErrors error in lonBL.validationErrors)
                        {
                            message += error.description + Environment.NewLine;
                        }
                        MessageBox.Show(message);
                    }
                }
                else {
                MessageBox.Show("This Resource or One of It's Type Exist In The List Already.");
            }
            
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void loanAddClear()
        {
            txtResource.Clear();
            pnlResInfo.Visible = false;
            pictureBox1.Visible = false;
        }

        private void btnCreateLoan_Click(object sender, EventArgs e)
        {
            try
            {
                LoanBL lonBL = new LoanBL();
                foreach (Loan loan in loans)
                {
                    bool res = lonBL.insertLoan(loan);

                    if (res)
                    {                     
                        loanAddClear();
                        lstSelRes.Visible = false;
                        btnCreateLoan.Visible = false;
                        lblSelRes.Visible = false;
                        btnRemove.Visible = false;
                        lstSelRes.Items.Clear();
                        txtResource.Focus();
                    }
                    else
                    {
                        string message = "";
                        foreach (ValidationErrors error in lonBL.validationErrors)
                        {
                            message += error.description + Environment.NewLine;
                        }
                        MessageBox.Show(message);
                    }
                }
                MessageBox.Show("Created Loans");
                FillDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (lstSelRes.SelectedIndex != -1)
            {
                loans.RemoveAt(lstSelRes.SelectedIndex);
                lstSelRes.Items.RemoveAt(lstSelRes.SelectedIndex);

                lblResID.Text = "";
            }
        }

        private void Loans_Load(object sender, EventArgs e)
        {
            txtSearchStud.Focus();
        }
    }
}  