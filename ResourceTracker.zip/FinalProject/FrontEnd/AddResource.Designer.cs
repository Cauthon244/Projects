﻿namespace FrontEnd
{
    partial class AddResource
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreate = new System.Windows.Forms.Button();
            this.pnlInfo = new System.Windows.Forms.Panel();
            this.txtImage = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.txtPubID = new System.Windows.Forms.TextBox();
            this.lblPubID = new System.Windows.Forms.Label();
            this.txtResName = new System.Windows.Forms.TextBox();
            this.lblResName = new System.Windows.Forms.Label();
            this.txtPub = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.dtpDoP = new System.Windows.Forms.DateTimePicker();
            this.lblResource = new System.Windows.Forms.Label();
            this.lblPub = new System.Windows.Forms.Label();
            this.lblDoP = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.txtDescript = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(465, 486);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(145, 47);
            this.btnCreate.TabIndex = 8;
            this.btnCreate.Text = "Add New Resource";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // pnlInfo
            // 
            this.pnlInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInfo.Controls.Add(this.txtDescript);
            this.pnlInfo.Controls.Add(this.label2);
            this.pnlInfo.Controls.Add(this.txtImage);
            this.pnlInfo.Controls.Add(this.label1);
            this.pnlInfo.Controls.Add(this.cmbType);
            this.pnlInfo.Controls.Add(this.txtPubID);
            this.pnlInfo.Controls.Add(this.lblPubID);
            this.pnlInfo.Controls.Add(this.txtResName);
            this.pnlInfo.Controls.Add(this.lblResName);
            this.pnlInfo.Controls.Add(this.txtPub);
            this.pnlInfo.Controls.Add(this.txtPrice);
            this.pnlInfo.Controls.Add(this.dtpDoP);
            this.pnlInfo.Controls.Add(this.lblResource);
            this.pnlInfo.Controls.Add(this.lblPub);
            this.pnlInfo.Controls.Add(this.lblDoP);
            this.pnlInfo.Controls.Add(this.lblPrice);
            this.pnlInfo.Controls.Add(this.lblType);
            this.pnlInfo.Location = new System.Drawing.Point(324, 178);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(416, 302);
            this.pnlInfo.TabIndex = 51;
            // 
            // txtImage
            // 
            this.txtImage.Location = new System.Drawing.Point(140, 223);
            this.txtImage.Name = "txtImage";
            this.txtImage.Size = new System.Drawing.Size(254, 22);
            this.txtImage.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 228);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 17);
            this.label1.TabIndex = 43;
            this.label1.Text = "Image Path";
            // 
            // cmbType
            // 
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Location = new System.Drawing.Point(140, 80);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(254, 24);
            this.cmbType.TabIndex = 1;
            // 
            // txtPubID
            // 
            this.txtPubID.Location = new System.Drawing.Point(140, 167);
            this.txtPubID.Name = "txtPubID";
            this.txtPubID.Size = new System.Drawing.Size(254, 22);
            this.txtPubID.TabIndex = 4;
            // 
            // lblPubID
            // 
            this.lblPubID.AutoSize = true;
            this.lblPubID.Location = new System.Drawing.Point(52, 172);
            this.lblPubID.Name = "lblPubID";
            this.lblPubID.Size = new System.Drawing.Size(82, 17);
            this.lblPubID.TabIndex = 34;
            this.lblPubID.Text = "Publisher Id";
            // 
            // txtResName
            // 
            this.txtResName.Location = new System.Drawing.Point(140, 52);
            this.txtResName.Name = "txtResName";
            this.txtResName.Size = new System.Drawing.Size(254, 22);
            this.txtResName.TabIndex = 0;
            // 
            // lblResName
            // 
            this.lblResName.AutoSize = true;
            this.lblResName.Location = new System.Drawing.Point(34, 57);
            this.lblResName.Name = "lblResName";
            this.lblResName.Size = new System.Drawing.Size(100, 17);
            this.lblResName.TabIndex = 31;
            this.lblResName.Text = "Resource Title";
            // 
            // txtPub
            // 
            this.txtPub.Location = new System.Drawing.Point(140, 110);
            this.txtPub.Name = "txtPub";
            this.txtPub.Size = new System.Drawing.Size(254, 22);
            this.txtPub.TabIndex = 2;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(140, 139);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(254, 22);
            this.txtPrice.TabIndex = 3;
            // 
            // dtpDoP
            // 
            this.dtpDoP.Location = new System.Drawing.Point(140, 195);
            this.dtpDoP.Name = "dtpDoP";
            this.dtpDoP.Size = new System.Drawing.Size(254, 22);
            this.dtpDoP.TabIndex = 5;
            // 
            // lblResource
            // 
            this.lblResource.AutoSize = true;
            this.lblResource.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResource.Location = new System.Drawing.Point(153, 12);
            this.lblResource.Name = "lblResource";
            this.lblResource.Size = new System.Drawing.Size(132, 25);
            this.lblResource.TabIndex = 16;
            this.lblResource.Text = "Resource Info";
            // 
            // lblPub
            // 
            this.lblPub.AutoSize = true;
            this.lblPub.Location = new System.Drawing.Point(67, 115);
            this.lblPub.Name = "lblPub";
            this.lblPub.Size = new System.Drawing.Size(67, 17);
            this.lblPub.TabIndex = 17;
            this.lblPub.Text = "Publisher";
            // 
            // lblDoP
            // 
            this.lblDoP.AutoSize = true;
            this.lblDoP.Location = new System.Drawing.Point(16, 200);
            this.lblDoP.Name = "lblDoP";
            this.lblDoP.Size = new System.Drawing.Size(118, 17);
            this.lblDoP.TabIndex = 19;
            this.lblDoP.Text = "Date of Purchase";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(90, 144);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(40, 17);
            this.lblPrice.TabIndex = 26;
            this.lblPrice.Text = "Price";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(90, 87);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(40, 17);
            this.lblType.TabIndex = 25;
            this.lblType.Text = "Type";
            // 
            // txtDescript
            // 
            this.txtDescript.Location = new System.Drawing.Point(140, 251);
            this.txtDescript.Name = "txtDescript";
            this.txtDescript.Size = new System.Drawing.Size(254, 22);
            this.txtDescript.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 256);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 17);
            this.label2.TabIndex = 45;
            this.label2.Text = "Description";
            // 
            // AddResource
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 773);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.pnlInfo);
            this.Name = "AddResource";
            this.Text = "AddResource";
            this.Load += new System.EventHandler(this.AddResource_Load);
            this.pnlInfo.ResumeLayout(false);
            this.pnlInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Panel pnlInfo;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.TextBox txtPubID;
        private System.Windows.Forms.Label lblPubID;
        private System.Windows.Forms.TextBox txtResName;
        private System.Windows.Forms.Label lblResName;
        private System.Windows.Forms.TextBox txtPub;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.DateTimePicker dtpDoP;
        private System.Windows.Forms.Label lblResource;
        private System.Windows.Forms.Label lblPub;
        private System.Windows.Forms.Label lblDoP;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.TextBox txtImage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDescript;
        private System.Windows.Forms.Label label2;
    }
}