﻿using BLL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Types;

namespace FrontEnd
{
    public partial class ModifyResourceStatus : Form
    {
        private Form1 myParent;
        public ModifyResourceStatus(Form1 Re)
        {
            InitializeComponent();
        }
        private List<Loan> loans = new List<Loan>();
        private Loan lon = new Loan();
        private Student stu = new Student();
        private Resource reso = new Resource();

        private void btnResSearch_Click(object sender, EventArgs e)
        {
                string errMsg = CheckResourceID();

                if (errMsg != string.Empty)
                {
                    MessageBox.Show(errMsg);
                }
                else
                {
                    try
                    {

                        ResourceBL ResBL = new ResourceBL();
                        if (!int.TryParse(txtResource.Text, out int result)) { MessageBox.Show("No Resource With That ID, Please Try Again."); }
                        else
                        {
                            reso = ResBL.getResource(txtResource.Text);
                            if (reso != null)
                            {
                                PopulateResourceRecord();                     
                            }
                            else
                            {
                                MessageBox.Show("No Resource With That ID, Please Try Again.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        private void PopulateResourceRecord()
            {
            if (Convert.ToInt32(reso.ResourceStatus) != 2)
            {
                txtPrice.Text = "$"+reso.Price.ToString();
                if (reso.DateRemoved.ToShortDateString() == "0001-01-01") { txtDateRem.Text = "None"; }
                else { txtDateRem.Text = reso.DateRemoved.ToShortDateString(); }
                txtPub.Text = reso.Publisher.ToString();
                txtDoP.Text = reso.DateOfPurchase.ToShortDateString();
                lblResID.Text = reso.ResourceID.ToString();
                txtTitle.Text = reso.ResourceName.ToString();
                txtType.Text = reso.ResourceType.ToString();
                if (Convert.ToInt32(reso.ReserveStatus) == 1) { txtStatus.Text = "Reserved"; }
                else { txtStatus.Text = "Available"; }
                if (Convert.ToInt32(reso.ResourceStatus) == 1) { chkAvailable.Checked = true; }
                else { chkAvailable.Checked = false; }
                pnlResInfo.Visible = true;
                btnUpdate.Visible = true;
            }
            else
            {
                MessageBox.Show("This Resource is currently on loan and may not have it's status changed.");
            }
        }
        private string CheckResourceID()
            {
                string errMsg = string.Empty;
                if (txtResource.Text == string.Empty)
                {
                    errMsg = "Please Supply a Valid ID.";
                }
                return errMsg;
            }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (chkAvailable.Checked) { reso.ResourceStatus = (ResourceStatus)Enum.Parse(typeof(ResourceStatus), "Available"); }
                else { reso.ResourceStatus = (ResourceStatus)Enum.Parse(typeof(ResourceStatus), "NotAvailable"); }
                ResourceBL resBL = new ResourceBL();
                bool res = resBL.ResourceStatusChange(reso);

                if (res)
                {
                    MessageBox.Show("Resource Updated Successfully");
                    ClearForm();
                }
                else
                {
                    string message = "";
                    foreach (ValidationErrors error in resBL.validationErrors)
                    {
                        message += error.description + Environment.NewLine;
                    }
                    MessageBox.Show(message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearForm()
        {
            pnlResInfo.Visible = false;
            btnUpdate.Visible = false;
        }
        private void ModifyResourceStatus_Load(object sender, EventArgs e)
        {
            txtResource.Focus();
        }
    }
}
