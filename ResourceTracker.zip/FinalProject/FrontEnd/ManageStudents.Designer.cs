﻿namespace FrontEnd
{
    partial class ManageStudents
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpdate = new System.Windows.Forms.Button();
            this.pnlInfo = new System.Windows.Forms.Panel();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.lblBalance = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.chkActive = new System.Windows.Forms.CheckBox();
            this.rdoBlock = new System.Windows.Forms.RadioButton();
            this.rdoStandard = new System.Windows.Forms.RadioButton();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtPost = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblPostalCode = new System.Windows.Forms.Label();
            this.txtStudID = new System.Windows.Forms.TextBox();
            this.lblStudId = new System.Windows.Forms.Label();
            this.txtfName = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.lblStudent = new System.Windows.Forms.Label();
            this.lblLName = new System.Windows.Forms.Label();
            this.lblProgram = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblStudStatus = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblFName = new System.Windows.Forms.Label();
            this.cmbSearchResult = new System.Windows.Forms.ComboBox();
            this.lblStudSearch = new System.Windows.Forms.Label();
            this.btnStudSearch = new System.Windows.Forms.Button();
            this.txtSearchStud = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.pnlInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(446, 539);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(145, 47);
            this.btnUpdate.TabIndex = 52;
            this.btnUpdate.Text = "Update Student";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Visible = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // pnlInfo
            // 
            this.pnlInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInfo.Controls.Add(this.txtBalance);
            this.pnlInfo.Controls.Add(this.lblBalance);
            this.pnlInfo.Controls.Add(this.txtPhone);
            this.pnlInfo.Controls.Add(this.lblPhone);
            this.pnlInfo.Controls.Add(this.chkActive);
            this.pnlInfo.Controls.Add(this.rdoBlock);
            this.pnlInfo.Controls.Add(this.rdoStandard);
            this.pnlInfo.Controls.Add(this.txtCity);
            this.pnlInfo.Controls.Add(this.txtPost);
            this.pnlInfo.Controls.Add(this.lblCity);
            this.pnlInfo.Controls.Add(this.lblPostalCode);
            this.pnlInfo.Controls.Add(this.txtStudID);
            this.pnlInfo.Controls.Add(this.lblStudId);
            this.pnlInfo.Controls.Add(this.txtfName);
            this.pnlInfo.Controls.Add(this.txtLName);
            this.pnlInfo.Controls.Add(this.txtAddress);
            this.pnlInfo.Controls.Add(this.dtpEnd);
            this.pnlInfo.Controls.Add(this.dtpStart);
            this.pnlInfo.Controls.Add(this.lblStudent);
            this.pnlInfo.Controls.Add(this.lblLName);
            this.pnlInfo.Controls.Add(this.lblProgram);
            this.pnlInfo.Controls.Add(this.lblStartDate);
            this.pnlInfo.Controls.Add(this.lblEndDate);
            this.pnlInfo.Controls.Add(this.lblStudStatus);
            this.pnlInfo.Controls.Add(this.lblAddress);
            this.pnlInfo.Controls.Add(this.lblFName);
            this.pnlInfo.Location = new System.Drawing.Point(342, 154);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(398, 379);
            this.pnlInfo.TabIndex = 51;
            this.pnlInfo.Visible = false;
            // 
            // txtBalance
            // 
            this.txtBalance.Enabled = false;
            this.txtBalance.Location = new System.Drawing.Point(114, 119);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.Size = new System.Drawing.Size(200, 22);
            this.txtBalance.TabIndex = 41;
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Location = new System.Drawing.Point(19, 122);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(89, 17);
            this.lblBalance.TabIndex = 42;
            this.lblBalance.Text = "Balance Due";
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(114, 231);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(200, 22);
            this.txtPhone.TabIndex = 39;
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(55, 236);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(49, 17);
            this.lblPhone.TabIndex = 40;
            this.lblPhone.Text = "Phone";
            // 
            // chkActive
            // 
            this.chkActive.AutoSize = true;
            this.chkActive.Location = new System.Drawing.Point(114, 346);
            this.chkActive.Name = "chkActive";
            this.chkActive.Size = new System.Drawing.Size(76, 21);
            this.chkActive.TabIndex = 38;
            this.chkActive.Text = "Active?";
            this.chkActive.UseVisualStyleBackColor = true;
            // 
            // rdoBlock
            // 
            this.rdoBlock.AutoSize = true;
            this.rdoBlock.Location = new System.Drawing.Point(207, 318);
            this.rdoBlock.Name = "rdoBlock";
            this.rdoBlock.Size = new System.Drawing.Size(119, 21);
            this.rdoBlock.TabIndex = 37;
            this.rdoBlock.Text = "Block Release";
            this.rdoBlock.UseVisualStyleBackColor = true;
            // 
            // rdoStandard
            // 
            this.rdoStandard.AutoSize = true;
            this.rdoStandard.Checked = true;
            this.rdoStandard.Location = new System.Drawing.Point(114, 318);
            this.rdoStandard.Name = "rdoStandard";
            this.rdoStandard.Size = new System.Drawing.Size(87, 21);
            this.rdoStandard.TabIndex = 36;
            this.rdoStandard.TabStop = true;
            this.rdoStandard.Text = "Standard";
            this.rdoStandard.UseVisualStyleBackColor = true;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(114, 175);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(200, 22);
            this.txtCity.TabIndex = 32;
            // 
            // txtPost
            // 
            this.txtPost.Location = new System.Drawing.Point(114, 203);
            this.txtPost.Name = "txtPost";
            this.txtPost.Size = new System.Drawing.Size(200, 22);
            this.txtPost.TabIndex = 33;
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(73, 180);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(31, 17);
            this.lblCity.TabIndex = 34;
            this.lblCity.Text = "City";
            // 
            // lblPostalCode
            // 
            this.lblPostalCode.AutoSize = true;
            this.lblPostalCode.Location = new System.Drawing.Point(20, 206);
            this.lblPostalCode.Name = "lblPostalCode";
            this.lblPostalCode.Size = new System.Drawing.Size(84, 17);
            this.lblPostalCode.TabIndex = 35;
            this.lblPostalCode.Text = "Postal Code";
            // 
            // txtStudID
            // 
            this.txtStudID.Location = new System.Drawing.Point(114, 34);
            this.txtStudID.Name = "txtStudID";
            this.txtStudID.ReadOnly = true;
            this.txtStudID.Size = new System.Drawing.Size(200, 22);
            this.txtStudID.TabIndex = 30;
            // 
            // lblStudId
            // 
            this.lblStudId.AutoSize = true;
            this.lblStudId.Location = new System.Drawing.Point(32, 37);
            this.lblStudId.Name = "lblStudId";
            this.lblStudId.Size = new System.Drawing.Size(72, 17);
            this.lblStudId.TabIndex = 31;
            this.lblStudId.Text = "Student Id";
            // 
            // txtfName
            // 
            this.txtfName.Location = new System.Drawing.Point(114, 63);
            this.txtfName.Name = "txtfName";
            this.txtfName.Size = new System.Drawing.Size(200, 22);
            this.txtfName.TabIndex = 3;
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(114, 91);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(200, 22);
            this.txtLName.TabIndex = 4;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(114, 147);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(200, 22);
            this.txtAddress.TabIndex = 6;
            // 
            // dtpEnd
            // 
            this.dtpEnd.Location = new System.Drawing.Point(114, 287);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(200, 22);
            this.dtpEnd.TabIndex = 8;
            // 
            // dtpStart
            // 
            this.dtpStart.Location = new System.Drawing.Point(114, 259);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(200, 22);
            this.dtpStart.TabIndex = 9;
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudent.Location = new System.Drawing.Point(131, 6);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(117, 25);
            this.lblStudent.TabIndex = 16;
            this.lblStudent.Text = "Student Info";
            // 
            // lblLName
            // 
            this.lblLName.AutoSize = true;
            this.lblLName.Location = new System.Drawing.Point(32, 94);
            this.lblLName.Name = "lblLName";
            this.lblLName.Size = new System.Drawing.Size(76, 17);
            this.lblLName.TabIndex = 17;
            this.lblLName.Text = "Last Name";
            // 
            // lblProgram
            // 
            this.lblProgram.AutoSize = true;
            this.lblProgram.Location = new System.Drawing.Point(46, 318);
            this.lblProgram.Name = "lblProgram";
            this.lblProgram.Size = new System.Drawing.Size(62, 17);
            this.lblProgram.TabIndex = 18;
            this.lblProgram.Text = "Program";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(36, 264);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(72, 17);
            this.lblStartDate.TabIndex = 19;
            this.lblStartDate.Text = "Start Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Location = new System.Drawing.Point(46, 292);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(67, 17);
            this.lblEndDate.TabIndex = 29;
            this.lblEndDate.Text = "End Date";
            // 
            // lblStudStatus
            // 
            this.lblStudStatus.AutoSize = true;
            this.lblStudStatus.Location = new System.Drawing.Point(7, 346);
            this.lblStudStatus.Name = "lblStudStatus";
            this.lblStudStatus.Size = new System.Drawing.Size(101, 17);
            this.lblStudStatus.TabIndex = 27;
            this.lblStudStatus.Text = "Student Status";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(44, 152);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(60, 17);
            this.lblAddress.TabIndex = 26;
            this.lblAddress.Text = "Address";
            // 
            // lblFName
            // 
            this.lblFName.AutoSize = true;
            this.lblFName.Location = new System.Drawing.Point(32, 66);
            this.lblFName.Name = "lblFName";
            this.lblFName.Size = new System.Drawing.Size(76, 17);
            this.lblFName.TabIndex = 25;
            this.lblFName.Text = "First Name";
            // 
            // cmbSearchResult
            // 
            this.cmbSearchResult.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSearchResult.FormattingEnabled = true;
            this.cmbSearchResult.Location = new System.Drawing.Point(61, 166);
            this.cmbSearchResult.Name = "cmbSearchResult";
            this.cmbSearchResult.Size = new System.Drawing.Size(224, 24);
            this.cmbSearchResult.TabIndex = 56;
            this.cmbSearchResult.Visible = false;
            this.cmbSearchResult.SelectionChangeCommitted += new System.EventHandler(this.cmbSearchResult_SelectionChangeCommitted);
            // 
            // lblStudSearch
            // 
            this.lblStudSearch.AutoSize = true;
            this.lblStudSearch.Location = new System.Drawing.Point(108, 76);
            this.lblStudSearch.Name = "lblStudSearch";
            this.lblStudSearch.Size = new System.Drawing.Size(131, 17);
            this.lblStudSearch.TabIndex = 55;
            this.lblStudSearch.Text = "Search For Student";
            // 
            // btnStudSearch
            // 
            this.btnStudSearch.Location = new System.Drawing.Point(124, 128);
            this.btnStudSearch.Name = "btnStudSearch";
            this.btnStudSearch.Size = new System.Drawing.Size(97, 30);
            this.btnStudSearch.TabIndex = 54;
            this.btnStudSearch.Text = "Search";
            this.btnStudSearch.UseVisualStyleBackColor = true;
            this.btnStudSearch.Click += new System.EventHandler(this.btnStudSearch_Click);
            // 
            // txtSearchStud
            // 
            this.txtSearchStud.Location = new System.Drawing.Point(62, 96);
            this.txtSearchStud.Name = "txtSearchStud";
            this.txtSearchStud.Size = new System.Drawing.Size(224, 22);
            this.txtSearchStud.TabIndex = 53;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(595, 539);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(145, 47);
            this.btnDelete.TabIndex = 57;
            this.btnDelete.Text = "Delete Student";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Visible = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // ManageStudents
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 773);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.cmbSearchResult);
            this.Controls.Add(this.lblStudSearch);
            this.Controls.Add(this.btnStudSearch);
            this.Controls.Add(this.txtSearchStud);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.pnlInfo);
            this.Name = "ManageStudents";
            this.Text = "ManageStudents";
            this.Load += new System.EventHandler(this.ManageStudents_Load);
            this.pnlInfo.ResumeLayout(false);
            this.pnlInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Panel pnlInfo;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.CheckBox chkActive;
        private System.Windows.Forms.RadioButton rdoBlock;
        private System.Windows.Forms.RadioButton rdoStandard;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtPost;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblPostalCode;
        private System.Windows.Forms.TextBox txtStudID;
        private System.Windows.Forms.Label lblStudId;
        private System.Windows.Forms.TextBox txtfName;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.Label lblStudent;
        private System.Windows.Forms.Label lblLName;
        private System.Windows.Forms.Label lblProgram;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblStudStatus;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblFName;
        private System.Windows.Forms.ComboBox cmbSearchResult;
        private System.Windows.Forms.Label lblStudSearch;
        private System.Windows.Forms.Button btnStudSearch;
        private System.Windows.Forms.TextBox txtSearchStud;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Button btnDelete;
    }
}