﻿using BLL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Model.Lists.Lookups;

namespace FrontEnd
{
    public partial class Reserve : Form
    {
        private Form1 myParent;
        public Reserve(Form1 Re)
        {
            InitializeComponent();
        }
        private List<Loan> loans = new List<Loan>();
        private Loan lon = new Loan();
        private Student stu = new Student();
        private Resource res = new Resource();

        private void Reserve_Load(object sender, EventArgs e)
        {
            txtResource.Focus();
        }

        private void PopulateResourceRecord()
        {
            lblResID.Text = res.ResourceID.ToString();
            lblResTitle.Text = res.ResourceName.ToString();
            lblResType.Text = res.ResourceType.ToString();
            lblResStatus.Text = res.ResourceStatus.ToString();
            if (Convert.ToInt32(res.ReserveStatus) == 1) { lblReserveStat.Text = "Reserved"; }
            else { lblReserveStat.Text = "Available"; }
        }
        private void btnResSearch_Click(object sender, EventArgs e)
        {
            string errMsg = CheckResourceID();

            if (errMsg != string.Empty)
            {
                MessageBox.Show(errMsg);
            }
            else
            {
                try
                {

                    ResourceBL ResBL = new ResourceBL();
                    if (!int.TryParse(txtResource.Text, out int result)) { MessageBox.Show("No Resource With That ID, Please Try Again."); }
                    else
                    {
                        if (ResBL.CheckStatus(txtResource.Text) == true)
                        {
                            res = ResBL.getResource(txtResource.Text);
                            if (res != null)
                            {
                                PopulateResourceRecord();
                                pnlResInfo.Visible = true;
                                txtSearchStud.Visible = true;
                                lblStudSearch.Visible = true;
                                btnStudSearch.Visible = true;
                            }
                            else
                            {
                                MessageBox.Show("No Resource With That ID, Please Try Again.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("This Resource Cannot Be Reserved");
                        }
                        }
                    }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                } 
            }
        }
        private string CheckResourceID()
        {
            string errMsg = string.Empty;
            if (txtResource.Text == string.Empty)
            {
                errMsg = "Please Supply a Valid ID.";
            }
            return errMsg;
        }

        private void btnStudSearch_Click(object sender, EventArgs e)
        {
            string errMsg = CheckNameAndLength();

            if (errMsg != string.Empty)
            {
                MessageBox.Show(errMsg);
            }
            else
            {
                ListsBL listsBl = new ListsBL();
                List<StudentLookup> sups = listsBl.GetStudentList(txtSearchStud.Text);
                if (sups.Count > 0)
                {
                    cmbSearchResult.DataSource = sups;
                    cmbSearchResult.DisplayMember = "LastName";
                    cmbSearchResult.ValueMember = "StudentId";
                    cmbSearchResult.SelectedIndex = 0;
                    cmbSearchResult.Visible = true;
                }
                else
                {
                    MessageBox.Show("No Student With That Name or ID, Please Try Again.");
                }
            }
        }

        private string CheckNameAndLength()
        {
            string errMsg = string.Empty;
            if (txtSearchStud.Text == string.Empty || txtSearchStud.TextLength > 50)
            {
                errMsg = "Please Supply a Valid Name.";
            }
            return errMsg;
        }

        private void cmbSearchResult_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                StudentBL StuBL = new StudentBL();
                if (StuBL.IsActive(Convert.ToInt32(cmbSearchResult.SelectedValue)) == true)
                {
                    if (StuBL.OwesBalance(Convert.ToInt32(cmbSearchResult.SelectedValue)) == true)
                    {

                        stu = StuBL.getStudent(Convert.ToInt32(cmbSearchResult.SelectedValue));

                        PopulateStudentRecord();
                        txtResource.Visible = true;
                        lblResSearch.Visible = true;
                        btnResSearch.Visible = true;
                        pnlInfo.Visible = true;
                        txtResource.Focus();
                        btnSubmit.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show("This Student Has an Outstanding Balance.");
                    }
                }
                else
                {
                    MessageBox.Show("This Student is Inactive.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void PopulateStudentRecord()
        {
            lblStuId.Text = stu.StudentID.ToString();
            txtfName.Text = stu.FirstName.ToString();
            txtLName.Text = stu.LastName.ToString();
            if (stu.Program.ToString() == "True") { txtProgram.Text = "Regular Program"; }
            else { txtProgram.Text = "Block Release"; }
            if (Convert.ToInt32(stu.StudentStatus) == 1) { txtStudentStatus.Text = "Active"; }
            else { txtStudentStatus.Text = "Inactive"; }
            txtBalance.Text = stu.BalanceDue.ToString("c");
            dtpStart.Text = stu.StartDate.ToString();
            dtpEnd.Text = stu.EndDate.ToString();
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                ResourceBL ResBL = new ResourceBL();
                bool res = ResBL.reserveResource(Convert.ToInt32(lblResID.Text), Convert.ToInt32(lblStuId.Text));
                if (res)
                {
                    MessageBox.Show("Resource Reserved");
                    btnStudSearch.Visible = false;
                    btnSubmit.Visible = false;
                    pnlInfo.Visible = false;
                    pnlResInfo.Visible = false;
                }
                else
                {
                    string message = "";
                    foreach (ValidationErrors error in ResBL.validationErrors)
                    {
                        message += error.description + Environment.NewLine;
                    }
                    MessageBox.Show(message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
