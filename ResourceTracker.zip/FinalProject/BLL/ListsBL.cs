﻿using SQLLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Model.Lists.Lookups;

namespace BLL
{
    public class ListsBL
    {
        public List<StudentLookup> GetStudentList(string search)
        {
            ComboLists listsCb = new ComboLists();
            return listsCb.RetrieveStudentList(search);
        }
    }
}
