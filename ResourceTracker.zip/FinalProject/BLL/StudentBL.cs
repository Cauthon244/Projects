﻿using Model.Entities;
using SQLLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class StudentBL
    {
        private StudentDB db = new StudentDB();
        private Student _Stu;
        public List<ValidationErrors> validationErrors = new List<ValidationErrors>();
        public Student getStudent(int id)
        {
            return db.StudentGet(id);
        }
        public bool addStudent(Student stu)
        {
            _Stu = stu;
            Validate();

            if (validationErrors.Count == 0)
            {
                return db.CreateStudent(_Stu);
            }
            return false;
        }
        public bool updateStudent(Student stu)
        {
            _Stu = stu;
            IsValidEntity();
            StartBeforeEnd();
            if (validationErrors.Count == 0)
            {
                return db.UpdateStudent(_Stu);
            }
            return false;
        }
        public void deleteStudent(string id)
        {
                db.RemoveStudent(id);
        }
        private bool IsValidEntity()
        {
            ValidationContext context = new ValidationContext(_Stu);
            List<ValidationResult> results = new List<ValidationResult>();

            bool isValid = Validator.TryValidateObject(_Stu, context, results,true);

            foreach (ValidationResult r in results)
            {
                validationErrors.Add(new ValidationErrors(r.ErrorMessage));
            }

            return isValid;
        }
        private bool ProperID()
        {
            if (_Stu.StudentID.ToString().Length == 8 && _Stu.StudentID.ToString().Substring(0, 4) == _Stu.StartDate.ToString().Substring(0, 4))
            {
                if (db.IdIsAvailable(_Stu.StudentID))
                {
                    return true;
                }
                else
                {
                    validationErrors.Add(new ValidationErrors("ID Already In Use."));
                    return false;
                }
            }
            validationErrors.Add(new ValidationErrors("Invalid ID Format."));
            return false;
        }
        public bool IsActive(int id)
        {
            if (db.isActive(id))
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("This is not an Active Student."));
            return false;
        }
        public bool OwesBalance(int id)
        {
            if (db.NoBalanceOwing(id) == 0.00)
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("This Student Has a Balance Due."));
            return false;
        }
        private bool StartBeforeEnd()
        {
            if (_Stu.StartDate<_Stu.EndDate)
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("Start Date Must Be Prior to End Date."));
            return false;
        }
        private void Validate()
        {
           
            IsValidEntity();
            ProperID();
            StartBeforeEnd();
        }
    }
}
