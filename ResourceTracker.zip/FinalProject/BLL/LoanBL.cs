﻿using Model.Entities;
using SQLLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace BLL
{
    public class LoanBL
    {
        private LoanDB db = new LoanDB();
        private Loan _Loan;
        public List<ValidationErrors> validationErrors = new List<ValidationErrors>();

        public DataTable GetLoan(int id)
        {
            return db.getLoan(id);
        }
        public DataTable GetLoanForReturn(int sid,int rid)
        {
            return db.getLoanForReturn(sid,rid);
        }
        public void ReturnLoan(Loan lon,ResourceStatus resStat)
        {
            db.ReturnLoan(lon,resStat);
        }
        public bool testLoan(Loan lon)
        {
            _Loan = lon;
            Validate();
            if (validationErrors.Count == 0)
            {
                return true;
            }
            return false;
        }
        public Loan GetLoanAndResource(int rid)
        {
            return db.RetrieveLoanAndResource(rid);
        }
        public int NumbOfLoans(int id)
        {
            return db.NumbOfLoans(id);
        }
        public bool insertLoan(Loan lon)
        {
            _Loan = lon;
            Validate();
            
            if (validationErrors.Count == 0)
            {
                return db.CreateLoan(_Loan);
            }
            return false;
        }
        private bool IsActive()
        {
            if (db.isActive(_Loan.StudentID))
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("This is not an Active Student."));
            return false;
        }
        private bool IsAvailable()
        {
            if (db.isAvailable(_Loan.ResourceID))
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("This Resource is Unavailable for Loan."));
            return false;
        }
        private bool OwesBalance()
        {
            if (db.NoBalanceOwing(_Loan.StudentID)==0.00)
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("This Student Has a Balance Due."));
            return false;
        }
        private bool CurrentlyHasType()
        {
            if (db.CurrentlyHasType(_Loan.StudentID, _Loan.ResourceType))
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("This Student Has a Loan with This Type of Resource Already."));
            return false;
        }
        private bool IsReserved()
        {
            if (db.IsReserved(_Loan.StudentID, _Loan.ResourceID))
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("This Resource is Reserved by Another Student."));
            return false;
        }
        private bool IsValidEntity()
        {
            ValidationContext context = new ValidationContext(_Loan);
            List<ValidationResult> results = new List<ValidationResult>();

            bool isValid = Validator.TryValidateObject(_Loan, context, results);

            foreach (ValidationResult r in results)
            {
                validationErrors.Add(new ValidationErrors(r.ErrorMessage));
            }

            return isValid;
        }
        private void Validate()
        {
            IsReserved();
            IsValidEntity();
            IsActive();
            IsAvailable();
            OwesBalance();
            CurrentlyHasType();
        }
    }
}
