﻿using Model.Entities;
using SQLLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace BLL
{
    public class PaymentBL
    {
        private PaymentDB db = new PaymentDB();
        private Payment _Pay;
        public List<ValidationErrors> validationErrors = new List<ValidationErrors>();

        public bool MakePayment(Payment pay)
        {
            _Pay = pay;
            Validate(_Pay);

            if (validationErrors.Count == 0)
            {
                return db.MakePayment(_Pay);
            }
            return false;
        }
        private void Validate(Payment pay)
        {
            IsValidEntity();
            CheckOverPay(pay);
        }
        private bool IsValidEntity()
        {
            ValidationContext context = new ValidationContext(_Pay);
            List<ValidationResult> results = new List<ValidationResult>();

            bool isValid = Validator.TryValidateObject(_Pay, context, results);

            foreach (ValidationResult r in results)
            {
                validationErrors.Add(new ValidationErrors(r.ErrorMessage));
            }

            return isValid;
        }
        public bool CheckOverPay(Payment pay)
        {
            if (db.CheckOverPay(pay))
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("You Cannot Pay More Than You Owe."));
            return false;
        }
        public void GetOverdues()
        {
            DataTable dt = new DataTable();
            DateTime dttm = new DateTime();
            dt=db.GetOverdues();
            if (dt.Rows.Count != 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dttm = (DateTime)dt.Rows[i][3];
                    if (GetBusinessDays(dttm, DateTime.Now) >= 10)
                    {
                        db.SetMissing(Convert.ToInt32(dt.Rows[i][0]), Convert.ToInt32(dt.Rows[i][5]));
                    }
                    else
                    {
                        db.IncreaseBalance(Convert.ToInt32(dt.Rows[i][5]));
                    }
                }
            }
        }
        public string NonReturnedList()
        {
            string FullList = "";
            DataTable dt = new DataTable();
            dt = db.GetNonReturns();
            if (dt.Rows.Count != 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    FullList+="Resource Name: "+dt.Rows[i][0]+ "\nResource Type: " + dt.Rows[i][1] + "\nStudent ID: " + dt.Rows[i][3] + "\nStudent Name: " + dt.Rows[i][4] + "\nResource Value: " + dt.Rows[i][2]+ "\n\n";
                }
            }
            else
            {
                FullList = "Nothing to Report.";
            }
            return FullList;

        }
        public static double GetBusinessDays(DateTime startD, DateTime endD)
        {
            double calcBusinessDays =
                1 + ((endD - startD).TotalDays * 5 -
                (startD.DayOfWeek - endD.DayOfWeek) * 2) / 7;

            if (endD.DayOfWeek == DayOfWeek.Saturday) calcBusinessDays--;
            if (startD.DayOfWeek == DayOfWeek.Sunday) calcBusinessDays--;

            return calcBusinessDays;
        }
    }
}
