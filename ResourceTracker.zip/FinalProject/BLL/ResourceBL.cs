﻿using Model.Entities;
using SQLLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ResourceBL
    {
        private ResourceDB db = new ResourceDB();
        private Resource _Res;
        public List<ValidationErrors> validationErrors = new List<ValidationErrors>();
        public Resource getResource(string search)
        {
            if (DoesExist(search))
            {
                return db.ResourceSearch(search);
            }
            else { return null; }
        }
        public Resource getResourceRet(int id)
        {

                return db.GetResource(id);

        }
        public bool addResource(Resource res)
        {
            _Res = res;
            Validate();

            if (validationErrors.Count == 0)
            {
                return db.CreateResource(_Res);
            }
            return false;
        }
        public bool reserveResource(int resID,int StuID)
        {
                return db.ReserveResource(resID,StuID);
        }
        public bool ResourceStatusChange(Resource res)
        {
            _Res = res;

                return db.UpdateStatus(_Res);
        }
        private bool IsValidEntity()
        {
            ValidationContext context = new ValidationContext(_Res);
            List<ValidationResult> results = new List<ValidationResult>();

            bool isValid = Validator.TryValidateObject(_Res, context, results);

            foreach (ValidationResult r in results)
            {
                validationErrors.Add(new ValidationErrors(r.ErrorMessage));
            }

            return isValid;
        }
        public bool CheckStatus(string search)
        {
            if (db.CheckStatus1(search) && db.CheckStatus2(search))
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("There's No Resource With This ID."));
            return false;
        }
        private bool DoesExist(string search)
        {
            if (db.DoesExist(search))
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("There's No Resource With This ID."));
            return false;
        }
        private void Validate()
        {
            IsValidEntity();
        }
        public bool CheckResourceForLoan(int id)
        {
            if (db.CheckResourceForLoan(id))
            {
                return true;
            }
            validationErrors.Add(new ValidationErrors("There's No Resource With This ID."));
            return false;
        }
    }
}
