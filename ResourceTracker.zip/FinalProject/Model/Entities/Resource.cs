﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace Model.Entities
{
    public class Resource
    {   [Required]
        public int ResourceID { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "The description cannot exceed 50 characters.")]
        public string Description { get; set; }

        [Required]
        public ResourceType ResourceType { get; set; }

        [Required]
        public ResourceStatus ResourceStatus { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "The Publisher cannot exceed 50 characters.")]
        public string Publisher { get; set; }

        [Required]
        public DateTime DateOfPurchase { get; set; }

        [Required]
        public double? Price { get; set; }

        public int? PubID { get; set; }

        [Required]
        public int ReserveStatus { get; set; }

        public DateTime DateRemoved { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "The Resource Name cannot exceed 50 characters.")]
        public string ResourceName { get; set; }


        public string Reserver { get; set; }
        [Required]
        public string Image { get; set; }
    }
}
