﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.Entities
{
    public class Student
    {
        [Required]
        public int StudentID { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "The First Name cannot exceed 50 characters.")]
        public string FirstName { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "The Last Name cannot exceed 50 characters.")]
        public string LastName { get; set; }

        [Required]
        public double BalanceDue { get; set; }

        [Required]
        public int Program { get; set; }

        [Required]
        public DateTime StartDate { get; set; }

        [Required]
        public DateTime EndDate { get; set; }

        [Required]
        public int StudentStatus { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "The Address cannot exceed 50 characters.")]
        public string Address { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "The City Name cannot exceed 50 characters.")]
        public string City { get; set; }

        [Required]
        [RegularExpression("[ABCEGHJKLMNPRSTVXY][0-9][ABCEGHJKLMNPRSTVWXYZ] ?[0-9][ABCEGHJKLMNPRSTVWXYZ][0-9]", ErrorMessage = "Postal Code is in an Invalid Format.")]
        public string PostalCode { get; set; }

        [Required]
        [RegularExpression("^(1?)(-| ?)(\\()?([0-9]{3})(\\)|-| |\\)-|\\) )?([0-9]{3})(-| )?([0-9]{4}|[0-9]{4})$", ErrorMessage = "Phone Number is in an Invalid Format.")]
        public string Phone { get; set; }

    }
}
