﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace Model.Entities
{
    public class Payment
    {
        [Required]
        public int StudentID { get; set; }
        [Required]
        public double PaymentAmount { get; set; }
        [Required]
        public int PaymentType { get; set; }
    }
}
