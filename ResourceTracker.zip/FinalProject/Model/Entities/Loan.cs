﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace Model.Entities
{
   public class Loan
    {
        [Required]
        public int ResourceID { get; set; }

        [Required]
        public ResourceType ResourceType { get; set; }

        [Required]
        public DateTime CheckoutDate { get; set; }

        [Required]
        public DateTime DueDate { get; set; }

        [Required]
        public LoanStatus LoanStatus { get; set; }

        [Required]
        public int StudentID { get; set; }

        [Required]
        public int LoanID { get; set; }

    }
}
