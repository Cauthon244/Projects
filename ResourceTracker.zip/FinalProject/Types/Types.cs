﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Types
{
    #region Structures
    public struct ParmStruct
    {
        public string Name;
        public object Value;
        public int Size;
        public SqlDbType DataType;
        public ParameterDirection Direction;

        public ParmStruct(string name, object value, int size, SqlDbType dataType, ParameterDirection direction)
        {
            Name = name;
            Value = value;
            Size = size;
            DataType = dataType;
            Direction = direction;
        }
        public ParmStruct(string name, object value, SqlDbType dataType, ParameterDirection direction)
        {
            Name = name;
            Value = value;
            Size = 0;
            DataType = dataType;
            Direction = direction;
        }
    }
    #endregion
    #region Enum
    public enum ResourceType
    {
        ManufacturersDVD=1,
        ManufacturersReferenceManual = 2,
        NonManufacturerReferenceBook = 3
    }
    public enum ResourceStatus
    {
       Available = 1,
       OnLoan = 2,
       NotAvailable = 3
    }
    public enum LoanStatus
    {
        OnLoan = 1,
        Returned = 2,
        Damaged = 3,
        NotReturned = 4
    }
    #endregion
}
