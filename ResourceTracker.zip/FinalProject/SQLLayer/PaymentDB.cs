﻿using DAL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace SQLLayer
{
    public class PaymentDB
    {
        public bool MakePayment(Payment pay)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", pay.StudentID,SqlDbType.Int, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Amount", pay.PaymentAmount, SqlDbType.Money, 0));
            parms.Add(new ParmStruct("@PaymentType", pay.PaymentType,SqlDbType.Bit, ParameterDirection.Input));
            Data db = new Data();
            if (db.ExecuteNonQuery("spMakePayment", CommandType.StoredProcedure, parms) > 0)
            {
                return true;
            }
            return false;
        }
        public bool CheckOverPay(Payment pay)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@Amount", pay.PaymentAmount, SqlDbType.Money, ParameterDirection.Input));
            parms.Add(new ParmStruct("@StudentID", pay.StudentID, SqlDbType.Int, ParameterDirection.Input));

            Data db = new Data();
            string sql = "SELECT (balanceDue-@Amount) FROM Students WHERE studentId=@StudentID";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) <0) { return false; }
            return true;
        }
        public DataTable GetOverdues()
        {
            List<ParmStruct> parms = new List<ParmStruct>();
            Data db = new Data();
            DataTable dt = db.Execute("SELECT * FROM Loans WHERE loanStatus = 1 AND dueDate < GETDATE();", CommandType.Text, parms);

            return dt;
        }
        public DataTable GetNonReturns()
        {
            List<ParmStruct> parms = new List<ParmStruct>();
            Data db = new Data();
            DataTable dt = db.Execute("SELECT resourceName,Loans.resourceType,price,Loans.studentId,(firstName+' '+lastName) AS 'StudentName' FROM Resource INNER JOIN Loans ON Resource.resourceId=Loans.resourceId INNER JOIN Students ON Loans.studentId=Students.studentId WHERE loanStatus=4 AND Resource.dateRemoved=(SELECT CONVERT(VARCHAR,GETDATE(),23))", CommandType.Text, parms);

            return dt;
        }
        public void IncreaseBalance(int stuid)
        {
                List<ParmStruct> parms = new List<ParmStruct>();
            parms.Add(new ParmStruct("@StudentID", stuid, SqlDbType.Int, ParameterDirection.Input));

            Data db = new Data();
                db.ExecuteNonQuery("spIncreaseOverdues", CommandType.StoredProcedure, parms);
        }
        public void SetMissing(int resid,int stuid)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceID", resid, SqlDbType.Int, ParameterDirection.Input));
            parms.Add(new ParmStruct("@StudentID", stuid, SqlDbType.Int, ParameterDirection.Input));

            Data db = new Data();
            db.ExecuteNonQuery("spMarkNonReturn", CommandType.StoredProcedure, parms);

        }
    }
}
