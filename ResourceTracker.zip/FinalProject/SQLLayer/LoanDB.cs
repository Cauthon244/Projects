﻿using DAL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace SQLLayer
{
    public class LoanDB
    {
        public DataTable getLoan(int id)
        {
            List<ParmStruct> parms = new List<ParmStruct>();
            parms.Add(new ParmStruct("@StudentId", id, 0, SqlDbType.Int, ParameterDirection.Input));
            Data db = new Data();
            DataTable dt = db.Execute("spRetrieveLoan", CommandType.StoredProcedure, parms);

            return dt;
        }
        public DataTable getLoanForReturn(int sid,int rid)
        {
            List<ParmStruct> parms = new List<ParmStruct>();
            parms.Add(new ParmStruct("@StudentID", sid, 0, SqlDbType.Int, ParameterDirection.Input));
            parms.Add(new ParmStruct("@ResourceID", rid, 0, SqlDbType.Int, ParameterDirection.Input));
            Data db = new Data();
            DataTable dt = db.Execute("spRetrieveLoanAlternate", CommandType.StoredProcedure, parms);

            return dt;
        }
        public void ReturnLoan(Loan lon,ResourceStatus resStat)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceID", lon.ResourceID, SqlDbType.Int, ParameterDirection.Input));
            parms.Add(new ParmStruct("@ResourceStatus", resStat, SqlDbType.Int, 0));
            parms.Add(new ParmStruct("@LoanStatus", lon.LoanStatus, SqlDbType.Int, 0));
            parms.Add(new ParmStruct("@StudID", lon.StudentID, SqlDbType.Int, ParameterDirection.Input));

            Data db = new Data();
            db.ExecuteNonQuery("spReturnLoan", CommandType.StoredProcedure, parms);
        }
        public bool CreateLoan(Loan lon)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceID", lon.ResourceID, SqlDbType.Int, ParameterDirection.Input));
            parms.Add(new ParmStruct("@DueDate", lon.DueDate, SqlDbType.DateTime, 0));
            parms.Add(new ParmStruct("@ResourceType", lon.ResourceType, SqlDbType.Int, 0));
            parms.Add(new ParmStruct("@LoanStatus", lon.LoanStatus, SqlDbType.Int, 0));
            parms.Add(new ParmStruct("@StudID", lon.StudentID, SqlDbType.Int, ParameterDirection.Input));

            Data db = new Data();
            if (db.ExecuteNonQuery("spCreateLoan", CommandType.StoredProcedure, parms) > 0)
            {
                return true;
            }
            return false;
        }
        public Loan RetrieveLoanAndResource(int rid)
        {
            List<ParmStruct> parms = new List<ParmStruct>();
            parms.Add(new ParmStruct("@ResourceID", rid, 0, SqlDbType.Int, ParameterDirection.Input));
            Data db = new Data();
            DataTable dt = db.Execute("spRetrieveLoanByRes", CommandType.StoredProcedure, parms);

            return PopulateDataRecord(dt.Rows[0]);
        }
        private Loan PopulateDataRecord(DataRow row)
        {
            Loan l = new Loan();
            l.ResourceID = Convert.ToInt32(row["resourceId"]);
            l.LoanID = Convert.ToInt32(row["loanId"]);
            l.StudentID = Convert.ToInt32(row["studentId"]);
            l.ResourceType = (ResourceType)Convert.ToInt32(row["resourceType"]);
            l.CheckoutDate = (DateTime)row["checkOutDate"];
            l.DueDate = (DateTime)row["dueDate"];
            l.LoanStatus = (LoanStatus)row["loanStatus"];
            return l;
        }
        public bool isActive(int stuId)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", stuId, SqlDbType.Int, 0));

            Data db = new Data();
            string sql = "SELECT studentStatus FROM Students WHERE StudentId = @StudentID";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) == 1) { return true; }
            return false;
        }
        public int NumbOfLoans(int id)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", id, SqlDbType.Int, 0));

            Data db = new Data();
            string sql = "SELECT COUNT(loanId) FROM Loans WHERE StudentId = @StudentID AND loanStatus=1";
            return Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms));
        }
        public bool isAvailable(int resID)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceID", resID, SqlDbType.Int, 0));

            Data db = new Data();
            string sql = "SELECT resourceStatus FROM Resource WHERE resourceID = @ResourceID";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) == 1) { return true; }
            return false;
        }
        public double NoBalanceOwing(int stuId)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", stuId, SqlDbType.Int, 0));

            Data db = new Data();
            string sql = "SELECT balanceDue FROM Students WHERE studentId = @StudentID";
            return Convert.ToDouble(db.ExecuteScaler(sql, CommandType.Text, parms));
        }
        public bool CurrentlyHasType(int stuId, ResourceType resType)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", stuId, SqlDbType.Int, 0));
            parms.Add(new ParmStruct("@ResType", resType, SqlDbType.Int, 0));

            Data db = new Data();
            string sql = "SELECT COUNT(resourceType) FROM Loans WHERE studentId = @StudentID AND resourceType=@ResType AND loanStatus=1";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) > 0 && DayPassed(stuId, resType)) { return false; }
            return true;
        }
        public bool IsReserved(int stuId, int resId)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceId", resId, SqlDbType.Int, 0));

            Data db = new Data();
            string sql = "SELECT reserveStatus FROM Resource WHERE resourceId = @ResourceId";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) ==  1 && ReservedBy(stuId,resId)) { return true; }
            else if(Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) == 0) { return true; }
            return false;
        }
        public bool ReservedBy(int stuId, int resId)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceId", resId, SqlDbType.Int, 0));

            Data db = new Data();
            string sql = "SELECT Reserver FROM Resource WHERE resourceId = @ResourceId";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) == stuId) { return true; }
            return false;
        }
        public bool DayPassed(int stuId, ResourceType resType)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", stuId, SqlDbType.Int, 0));
            parms.Add(new ParmStruct("@ResType", resType, SqlDbType.Int, 0));

            Data db = new Data();
            string sql = "SELECT loanStatus FROM Loans WHERE studentId = @StudentID AND resourceType=@ResType";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms))==2)
            {
                sql = "SELECT dueDate FROM Loans WHERE studentId = @StudentID AND resourceType=@ResType";
                if (DateTime.Today.AddDays(1) > (DateTime)(db.ExecuteScaler(sql, CommandType.Text, parms))) { return true; }
                return false;
            }
            return true;
        }
    }
}
