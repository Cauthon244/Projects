﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
using static Model.Lists.Lookups;

namespace SQLLayer
{
   public class ComboLists
    {
        public List<StudentLookup> RetrieveStudentList(string search)
        {
            List<ParmStruct> parms = new List<ParmStruct>();
            parms.Add(new ParmStruct("@KeyWord", search, 50, SqlDbType.VarChar, ParameterDirection.Input));
            Data db = new Data();
            DataTable dt = db.Execute("spSearchStud", CommandType.StoredProcedure, parms);

            List<StudentLookup> stus = new List<StudentLookup>();
            foreach (DataRow row in dt.Rows)
            {
                StudentLookup stu = new StudentLookup();
                stu.StudentId = Convert.ToInt32(row["studentId"]);
                stu.LastName = row["StudentName"].ToString();
                stus.Add(stu);
            }

            return stus;
        }
    }
}
