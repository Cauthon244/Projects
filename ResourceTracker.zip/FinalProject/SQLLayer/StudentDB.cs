﻿using DAL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace SQLLayer
{
    public class StudentDB
    {
        public Student StudentSearch(string search)
        {
            List<ParmStruct> parms = new List<ParmStruct>();
            parms.Add(new ParmStruct("@KeyWord", search, 50, SqlDbType.VarChar,ParameterDirection.Input));
            Data db = new Data();
            DataTable dt = db.Execute("spSearchStud", CommandType.StoredProcedure, parms);

            return PopulateDataRecord(dt.Rows[0]);
        }
        public bool CreateStudent(Student stu)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", stu.StudentID, SqlDbType.Int, ParameterDirection.Input));
            parms.Add(new ParmStruct("@LastName", stu.LastName,50, SqlDbType.NVarChar, ParameterDirection.Input));
            parms.Add(new ParmStruct("@FirstName", stu.FirstName,50, SqlDbType.NVarChar, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Status", stu.StudentStatus, 0, SqlDbType.Int, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Program", stu.Program, SqlDbType.Int, 0));
            parms.Add(new ParmStruct("@StartDate", stu.StartDate, SqlDbType.Date, ParameterDirection.Input));
            parms.Add(new ParmStruct("@EndDate", stu.EndDate, SqlDbType.Date, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Address", stu.Address, 50, SqlDbType.NVarChar, ParameterDirection.Input));
            parms.Add(new ParmStruct("@City", stu.City,50, SqlDbType.NVarChar,ParameterDirection.Input));
            parms.Add(new ParmStruct("@Postal", stu.PostalCode,6 ,SqlDbType.Char, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Phone", stu.Phone,10, SqlDbType.Char, ParameterDirection.Input));
            Data db = new Data();
            if (db.ExecuteNonQuery("spAddStudent", CommandType.StoredProcedure, parms) > 0)
            {
                return true;
            }
            return false;
        }
        public bool UpdateStudent(Student stu)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", stu.StudentID, SqlDbType.Int, ParameterDirection.Input));
            parms.Add(new ParmStruct("@LastName", stu.LastName, 50, SqlDbType.NVarChar, ParameterDirection.Input));
            parms.Add(new ParmStruct("@FirstName", stu.FirstName, 50, SqlDbType.NVarChar, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Status", stu.StudentStatus, 0, SqlDbType.Int, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Program", stu.Program, SqlDbType.Int, 0));
            parms.Add(new ParmStruct("@StartDate", stu.StartDate, SqlDbType.Date, ParameterDirection.Input));
            parms.Add(new ParmStruct("@EndDate", stu.EndDate, SqlDbType.Date, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Address", stu.Address, 50, SqlDbType.NVarChar, ParameterDirection.Input));
            parms.Add(new ParmStruct("@City", stu.City, 50, SqlDbType.NVarChar, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Postal", stu.PostalCode, 6, SqlDbType.Char, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Phone", stu.Phone, 10, SqlDbType.Char, ParameterDirection.Input));
            Data db = new Data();
            if (db.ExecuteNonQuery("spEditStudent", CommandType.StoredProcedure, parms) > 0)
            {
                return true;
            }
            return false;
        }
        public void RemoveStudent(string id)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", id, SqlDbType.Int, ParameterDirection.Input));
            Data db = new Data();
            db.ExecuteNonQuery("spRemoveStudent", CommandType.StoredProcedure, parms);

        }
        public bool IdIsAvailable(int stuID)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", stuID, SqlDbType.Int, 0));

            Data db = new Data();
            string sql = "SELECT studentId FROM Students WHERE studentId = @StudentID";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) == 0) { return true; }
            return false;
        }
        public Student StudentGet(int id)
        {
            List<ParmStruct> parms = new List<ParmStruct>();
            parms.Add(new ParmStruct("@KeyWord", id, 0, SqlDbType.VarChar, ParameterDirection.Input));
            Data db = new Data();
            DataTable dt = db.Execute("spSearchStudInfo", CommandType.StoredProcedure, parms);

            return PopulateDataRecord(dt.Rows[0]);
        }
        private Student PopulateDataRecord(DataRow row)
        {
            Student s = new Student();
            s.StudentID = Convert.ToInt32(row["studentId"]);
            s.FirstName = row["firstName"].ToString();
            s.LastName = row["lastName"].ToString();
            s.Program = Convert.ToInt32(row["program"]);
            s.StartDate = (DateTime)row["startDate"];
            s.EndDate = (DateTime)row["endDate"];
            s.StudentStatus = Convert.ToInt32(row["studentStatus"]);
            s.BalanceDue = Convert.ToDouble(row["balanceDue"]);
            s.Address = row["address"].ToString();
            s.City = row["city"].ToString();
            s.PostalCode = row["postalCode"].ToString();
            s.Phone = row["telephone"].ToString();
            return s;
        }
        public bool isActive(int id)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", id, SqlDbType.Int, 0));

            Data db = new Data();
            string sql = "SELECT studentStatus FROM Students WHERE StudentId = @StudentID";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) == 1) { return true; }
            return false;
        }
        public double NoBalanceOwing(int id)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentID", id, SqlDbType.Int, 0));

            Data db = new Data();
            string sql = "SELECT balanceDue FROM Students WHERE studentId = @StudentID";
            return Convert.ToDouble(db.ExecuteScaler(sql, CommandType.Text, parms));
        }
    }
}
