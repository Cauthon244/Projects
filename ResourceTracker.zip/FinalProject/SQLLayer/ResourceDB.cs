﻿using DAL;
using Model.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace SQLLayer
{
    public class ResourceDB
    {
        public Resource ResourceSearch(string search)
        {
            List<ParmStruct> parms = new List<ParmStruct>();
            parms.Add(new ParmStruct("@KeyWord", search, 50, SqlDbType.VarChar, ParameterDirection.Input));
            Data db = new Data();
            DataTable dt = db.Execute("spSearchResource", CommandType.StoredProcedure, parms);
            return PopulateDataRecord(dt.Rows[0]);
        }
        public Resource GetResource(int id)
        {
            List<ParmStruct> parms = new List<ParmStruct>();
            parms.Add(new ParmStruct("@ResourceID", id, SqlDbType.Int, ParameterDirection.Input));
            Data db = new Data();
            DataTable dt = db.Execute("spGetResource", CommandType.StoredProcedure, parms);
            return PopulateDataRecord(dt.Rows[0]);
        }
        private Resource PopulateDataRecord(DataRow row)
        {
            Resource r = new Resource();
            r.ResourceID = Convert.ToInt32(row["resourceId"]);
            r.ResourceName = row["resourceName"].ToString();
            r.ResourceStatus = (ResourceStatus)row["resourceStatus"];
            r.ResourceType = (ResourceType)row["resourceType"];
            r.Description = row["description"].ToString();
            if (row["pubId"] == DBNull.Value) { r.PubID = null; }
            else { r.PubID = Convert.ToInt32(row["pubId"]); }
            r.Publisher = row["publisher"].ToString();
            r.Price = Convert.ToDouble(row["price"]);
            r.ReserveStatus = Convert.ToInt32(row["reserveStatus"]);
            if (row["Reserver"] == DBNull.Value) { r.Reserver = "None"; }
            else { r.Reserver = FindReserver(Convert.ToInt32(row["Reserver"])); }
            r.DateOfPurchase = (DateTime)row["dateOfPurchase"];
            if (row["dateRemoved"] == DBNull.Value) { }
            else { r.DateRemoved = (DateTime)row["dateRemoved"]; }
            r.Image = row["image"].ToString();
            return r;
        }
        public bool CreateResource(Resource res)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@Description", res.Description,50, SqlDbType.NVarChar, ParameterDirection.Input));
            parms.Add(new ParmStruct("@ResourceType", res.ResourceType, SqlDbType.Int, 0));
            parms.Add(new ParmStruct("@Publisher", res.Publisher, 50, SqlDbType.NVarChar, ParameterDirection.Input));
            parms.Add(new ParmStruct("@DoP", res.DateOfPurchase, 0, SqlDbType.Date, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Price", res.Price, SqlDbType.Money, 0));
            parms.Add(new ParmStruct("@PubId", res.PubID, SqlDbType.Int, ParameterDirection.Input));
            parms.Add(new ParmStruct("@ResourceName", res.ResourceName,50, SqlDbType.NVarChar, ParameterDirection.Input));
            parms.Add(new ParmStruct("@Image", res.Image, 100, SqlDbType.NVarChar, ParameterDirection.Input));
            Data db = new Data();
            if (db.ExecuteNonQuery("spAddResource", CommandType.StoredProcedure, parms) > 0)
            {
                return true;
            }
            return false;
        }
        public bool UpdateStatus(Resource res)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceID", res.ResourceID, SqlDbType.Int, 0));
            parms.Add(new ParmStruct("@ResourceStatus", res.ResourceStatus, SqlDbType.Int, 0));

            Data db = new Data();
            if (db.ExecuteNonQuery("spResourceStatusChange", CommandType.StoredProcedure, parms) > 0)
            {
                return true;
            }
            return false;
        }
        public bool ReserveResource(int resID, int StuID)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceID", resID, SqlDbType.Int, 0));
            parms.Add(new ParmStruct("@StudentId", StuID, SqlDbType.Int, 0));

            Data db = new Data();
            if (db.ExecuteNonQuery("spReserve", CommandType.StoredProcedure, parms) > 0)
            {
                return true;
            }
            return false;
        }
        public bool DoesExist(string search)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceID", search, 50, SqlDbType.VarChar, ParameterDirection.Input));

            Data db = new Data();
            string sql = "SELECT COUNT(resourceId) FROM Resource WHERE resourceID = @ResourceID";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) == 1) { return true; }
            return false;
        }
        public bool CheckStatus1(string search)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceID", search, SqlDbType.VarChar, ParameterDirection.Input));

            Data db = new Data();
            string sql = "SELECT resourceStatus FROM Resource WHERE resourceId=@ResourceID";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms))==1) { return true; }
            return false;
        }
        public bool CheckStatus2(string search)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceID", search, SqlDbType.VarChar, ParameterDirection.Input));

            Data db = new Data();
            string sql = "SELECT reserveStatus FROM Resource WHERE resourceId=@ResourceID";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) ==0) { return true; }
            return false;
        }
        public string FindReserver(int id)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@StudentId", id, SqlDbType.NVarChar, ParameterDirection.Input));

            Data db = new Data();
            string sql = "SELECT lastName+' '+firstName AS 'StudentName' From Students WHERE studentId=@StudentId;";
            return db.ExecuteScaler(sql, CommandType.Text, parms).ToString();
        }
        public bool CheckResourceForLoan(int id)
        {
            List<ParmStruct> parms = new List<ParmStruct>();

            parms.Add(new ParmStruct("@ResourceID", id, SqlDbType.VarChar, ParameterDirection.Input));

            Data db = new Data();
            string sql = "SELECT * FROM Loans WHERE resourceId=@ResourceID AND loanStatus=1";
            if (Convert.ToInt32(db.ExecuteScaler(sql, CommandType.Text, parms)) == 0) { return true; }
            return false;
        }
    }
}
