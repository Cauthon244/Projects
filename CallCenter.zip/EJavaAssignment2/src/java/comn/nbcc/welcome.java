/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comn.nbcc;

import java.io.IOException;
import java.util.Date;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/**
 *
 * @author Adam Crooks
 * Assignment 2
 * February 7 2019
 */
public class welcome extends SimpleTagSupport {
    Date dateWel=new Date();
    String currentDateWel=dateWel.toString();
    public void doTag() throws JspException, IOException{
        JspWriter out = getJspContext().getOut();
        out.println("<div  align = \"center\"><h1>Welcome to Our Wonderful Site</h1><br><p>Current Date: "+currentDateWel+"</p></div>");
    }
}
