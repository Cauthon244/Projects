/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nbcc.customtags;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import static javax.servlet.jsp.tagext.Tag.EVAL_PAGE;
import static javax.servlet.jsp.tagext.Tag.SKIP_BODY;
import javax.servlet.jsp.tagext.TagSupport;

/**
 *
 * @author Adam Crooks
 * Assignment 2
 * February 7 2019
 */
public class DropDownList extends TagSupport{
    private String valueField;
    private String textField;
    private String controlName;
    private String tableName;

   
    //<editor-fold defaultstate="collapsed" desc="DB props">
    private String url = "";
    private String user = "";
    private String password = "";
//</editor-fold>

    /**
     * 
     * @return
     * @throws JspException 
     */
    @Override
    public int doStartTag() throws JspException {
        //Query the country table in world
        String sqlFillBox = "SELECT * FROM "+tableName+" ";

        //Get the JspWriter Instance
        JspWriter out = pageContext.getOut();
        try {
            ///Use a string builder for building my html
            StringBuilder dynamicSelect = new StringBuilder("<select name=\"" + getControlName() + "\">");

            //Set DB Properties
            getProperties();

            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            //Create a connection object
            try (Connection conn = DriverManager.getConnection(url, user, password)) {
                try (Statement stmnt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE)) {
                    try (ResultSet rs = stmnt.executeQuery(sqlFillBox)) {
                        dynamicSelect.append("<option value=\"0\">--Select an Option</option>");
                        while (rs.next()) {
                            dynamicSelect.append("<option value=\"");
                            dynamicSelect.append(rs.getString(this.getValueField()));
                            dynamicSelect.append("\">");
                            dynamicSelect.append(rs.getString(this.getTextField()));
                            dynamicSelect.append("</option>");
                        }
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            dynamicSelect.append("</select>");
            out.println(dynamicSelect.toString());
        } catch (Exception e) {
        }

        return SKIP_BODY;
    }
    
    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    public String getValueField() {
        return valueField;
    }

    public void setValueField(String valueField) {
        this.valueField = valueField;
    }

    public String getTextField() {
        return textField;
    }

    public void setTextField(String textField) {
        this.textField = textField;
    }

    public String getControlName() {
        return controlName;
    }

    public void setControlName(String controlName) {
        this.controlName = controlName;
    }

    @Override
    public int doEndTag() throws JspException {
        return EVAL_PAGE;
    }
/**
 * 
 * @return 
 */
    private Properties getProperties() {
        //Ensure the properties file has been created
        //Project Properties > Other > Other > Properties File > Name the file db
        Properties props = new Properties();

        try {
            //Get the path to my db.properties file
            String propertiesPath = pageContext.getServletContext().getRealPath("/WEB-INF/db.properties");
            FileInputStream in = new FileInputStream(propertiesPath);
            props.load(in);
            in.close();

            //Set the conn string props
            url = props.getProperty("mysql.url");
            user = props.getProperty("mysql.username");
            password = props.getProperty("mysql.password");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return props;
    }
}
