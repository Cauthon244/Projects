﻿namespace frontEnd
{
    partial class Table
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Table));
            this.btn_Start = new System.Windows.Forms.Button();
            this.btnHit = new System.Windows.Forms.Button();
            this.btnStay = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnDeal = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblPS = new System.Windows.Forms.Label();
            this.lblDS = new System.Windows.Forms.Label();
            this.lblDSText = new System.Windows.Forms.Label();
            this.lblPSText = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Start
            // 
            this.btn_Start.Location = new System.Drawing.Point(212, 296);
            this.btn_Start.Name = "btn_Start";
            this.btn_Start.Size = new System.Drawing.Size(147, 60);
            this.btn_Start.TabIndex = 0;
            this.btn_Start.Text = "Start a Game";
            this.btn_Start.UseVisualStyleBackColor = true;
            this.btn_Start.Click += new System.EventHandler(this.btn_Start_Click_1);
            // 
            // btnHit
            // 
            this.btnHit.Location = new System.Drawing.Point(158, 252);
            this.btnHit.Name = "btnHit";
            this.btnHit.Size = new System.Drawing.Size(75, 23);
            this.btnHit.TabIndex = 4;
            this.btnHit.Text = "Hit Me";
            this.btnHit.UseVisualStyleBackColor = true;
            this.btnHit.Visible = false;
            this.btnHit.Click += new System.EventHandler(this.btnHit_Click);
            // 
            // btnStay
            // 
            this.btnStay.Location = new System.Drawing.Point(341, 252);
            this.btnStay.Name = "btnStay";
            this.btnStay.Size = new System.Drawing.Size(75, 23);
            this.btnStay.TabIndex = 5;
            this.btnStay.Text = "I\'ll Stay";
            this.btnStay.UseVisualStyleBackColor = true;
            this.btnStay.Visible = false;
            this.btnStay.Click += new System.EventHandler(this.btnStay_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(239, 179);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(71, 96);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // btnDeal
            // 
            this.btnDeal.Location = new System.Drawing.Point(250, 133);
            this.btnDeal.Name = "btnDeal";
            this.btnDeal.Size = new System.Drawing.Size(71, 40);
            this.btnDeal.TabIndex = 16;
            this.btnDeal.Text = "Deal";
            this.btnDeal.UseVisualStyleBackColor = true;
            this.btnDeal.Visible = false;
            this.btnDeal.Click += new System.EventHandler(this.btnDeal_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Location = new System.Drawing.Point(12, 372);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(558, 124);
            this.panel1.TabIndex = 18;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Location = new System.Drawing.Point(12, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(558, 123);
            this.panel2.TabIndex = 19;
            // 
            // lblPS
            // 
            this.lblPS.AutoSize = true;
            this.lblPS.BackColor = System.Drawing.Color.Transparent;
            this.lblPS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPS.ForeColor = System.Drawing.Color.Red;
            this.lblPS.Location = new System.Drawing.Point(136, 336);
            this.lblPS.Name = "lblPS";
            this.lblPS.Size = new System.Drawing.Size(59, 20);
            this.lblPS.TabIndex = 20;
            this.lblPS.Text = "label1";
            this.lblPS.Visible = false;
            // 
            // lblDS
            // 
            this.lblDS.AutoSize = true;
            this.lblDS.BackColor = System.Drawing.Color.Transparent;
            this.lblDS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDS.ForeColor = System.Drawing.Color.Red;
            this.lblDS.Location = new System.Drawing.Point(136, 133);
            this.lblDS.Name = "lblDS";
            this.lblDS.Size = new System.Drawing.Size(59, 20);
            this.lblDS.TabIndex = 21;
            this.lblDS.Text = "label2";
            this.lblDS.Visible = false;
            // 
            // lblDSText
            // 
            this.lblDSText.AutoSize = true;
            this.lblDSText.BackColor = System.Drawing.Color.Transparent;
            this.lblDSText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDSText.ForeColor = System.Drawing.Color.Red;
            this.lblDSText.Location = new System.Drawing.Point(9, 133);
            this.lblDSText.Name = "lblDSText";
            this.lblDSText.Size = new System.Drawing.Size(111, 20);
            this.lblDSText.TabIndex = 22;
            this.lblDSText.Text = "House Wins";
            this.lblDSText.Visible = false;
            // 
            // lblPSText
            // 
            this.lblPSText.AutoSize = true;
            this.lblPSText.BackColor = System.Drawing.Color.Transparent;
            this.lblPSText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPSText.ForeColor = System.Drawing.Color.Red;
            this.lblPSText.Location = new System.Drawing.Point(9, 336);
            this.lblPSText.Name = "lblPSText";
            this.lblPSText.Size = new System.Drawing.Size(95, 20);
            this.lblPSText.TabIndex = 23;
            this.lblPSText.Text = "Your Wins";
            this.lblPSText.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            // 
            // Table
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(582, 508);
            this.Controls.Add(this.lblPSText);
            this.Controls.Add(this.lblDSText);
            this.Controls.Add(this.lblDS);
            this.Controls.Add(this.lblPS);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnDeal);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnStay);
            this.Controls.Add(this.btnHit);
            this.Controls.Add(this.btn_Start);
            this.Controls.Add(this.panel1);
            this.Name = "Table";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Table_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Start;
        private System.Windows.Forms.Button btnHit;
        private System.Windows.Forms.Button btnStay;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnDeal;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblPS;
        private System.Windows.Forms.Label lblDS;
        private System.Windows.Forms.Label lblDSText;
        private System.Windows.Forms.Label lblPSText;
        private System.Windows.Forms.Timer timer1;
    }
}

