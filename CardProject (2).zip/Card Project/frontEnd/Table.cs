﻿using Card_Project;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frontEnd
{
    public partial class Table : Form
    {
        private int winCount;
        private int loseCount;
        private Hand myHand1;
        private Hand myHand2;
        Deck inUse = new Deck();
        public Table()
        {
            InitializeComponent();
        }

        private void btn_Start_Click_1(object sender, EventArgs e)
        {
            pictureBox2.Visible = true;
            btn_Start.Visible = false;
            btnDeal.Visible = true;
            lblPS.Visible = true;
            lblDS.Visible = true;
            lblDSText.Visible = true;
            lblPSText.Visible = true;
        }

        private void btnStay_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Dealers Turn.");
            ShowHand(panel2, myHand2);
            while (myHand2.ScoreUp(myHand2)<17)
            {
                onHit(myHand2, panel2);
                ShowHand(panel2, myHand2);
            }
            if (House.isBust(myHand2.ScoreUp(myHand2)))
            {
                MessageBox.Show("Dealer's Bust!");
                winCount += 1;
                Clear_Table_Hand();
                if (House.winOrLose(winCount))
                {
                    MessageBox.Show("You've won the game.");
                    Clear_Table_Match();
                    return;
                }
                btnDeal.Visible = true;
                return;
            }
            if (House.isFiveAndUnder(myHand2.Count))
            {
                MessageBox.Show("Five Card Hand With No Bust, Dealer Wins!");
                loseCount += 1;
                Clear_Table_Hand();
                if (House.winOrLose(loseCount))
                {
                    MessageBox.Show("The House wins the game, this time.");
                    Clear_Table_Match();
                    return;
                }
                btnDeal.Visible = true;
                return;
            }
            int Ps= myHand1.ScoreUp(myHand1);
            int Ds= myHand2.ScoreUp(myHand2);
            if(House.isWinHand(Ds, Ps))
            {
                winCount += 1;
                lblDS.Text = loseCount.ToString();
                lblPS.Text = winCount.ToString();
                MessageBox.Show("Congratulations, you've won the Hand!");
                Clear_Table_Hand();
                if (winCount == 10)
                {
                    MessageBox.Show("Congratulations, you've won the game!");
                    Clear_Table_Match();
                    return;
                }
                btnDeal.Visible = true;
            }
            else
            {
                loseCount += 1;
                lblDS.Text = loseCount.ToString();
                lblPS.Text = winCount.ToString();
                MessageBox.Show("Dealer Wins This Hand.");
                Clear_Table_Hand();
                if (loseCount == 10)
                {
                    MessageBox.Show("The House has won.");
                    Clear_Table_Match();
                    return;
                }
                btnDeal.Visible = true;
            }
        }
        #region ProvidingHands
        private void ShowHand(Panel thePanel, Hand theHand)
        {
            thePanel.Controls.Clear();
            Card aCard;
            PictureBox aPic;
            for (int x = 0; x < theHand.Count; x++)
            {
                aCard = theHand[x];
                string i = "images\\" + aCard.Face.ToString() + aCard.Suit.ToString() + ".jpg";
                aPic = new PictureBox()
                {
                    Image = Image.FromFile(i),
                    Text = aCard.Face.ToString(),
                    Width = 75,
                    Height = 120,
                    Left = 75 * x,
                    Tag = aCard
                };
                thePanel.Controls.Add(aPic);
            }
        }
        private void btnDeal_Click(object sender, EventArgs e)
        {
            try
            {
                myHand1 = inUse.DealHand(2);
                ShowHand(panel1, myHand1);
                myHand2 = inUse.DealHand(2);
                ShowHand(panel2, myHand2);
                PictureBox covPic = new PictureBox()
                {
                    Image = Image.FromFile("images\\cardback.gif"),
                    Width = 75,
                    Height = 120,
                    Left = 0,
                };
                panel2.Controls.Add(covPic);
                covPic.BringToFront();
            }
            catch
            {
                MessageBox.Show("No cards left, Re-Shuffling Deck.");
            }
            btnDeal.Visible = false;
            btnHit.Visible = true;
            btnStay.Visible = true;
        }
        #endregion
        #region ScoringHits
        private void btnHit_Click(object sender, EventArgs e)
        {
            try
            {
                onHit(myHand1, panel1);
                if(House.isBust(myHand1.ScoreUp(myHand1)))
                {                 
                    MessageBox.Show("You're Bust!");
                    loseCount += 1;
                    Clear_Table_Hand();
                    if (House.winOrLose(loseCount))
                    {
                        MessageBox.Show("The House has won.");
                        Clear_Table_Match();
                        return;
                    }
                    btnDeal.Visible = true;
                }
                if (House.isFiveAndUnder(myHand1.Count))
                {   MessageBox.Show("Five Card Hand With No Bust, You Win!");
                    winCount += 1;
                    Clear_Table_Hand();
                    if (House.winOrLose(winCount))
                    {
                        MessageBox.Show("Congratulations, you've won the game!");
                        Clear_Table_Match();
                        return;
                    }
                    btnDeal.Visible = true;
                    return;
                }
            }
            catch
            {
                MessageBox.Show("No cards left, Re-Shuffling Deck.");
            }
        }
        private void onHit(Hand theHand, Panel thePanel)
        {
            Card temp = inUse.DrawOneCard();
            theHand.AddCard(temp);
            ShowHand(thePanel, theHand);
        }
        #endregion
        #region LoadsAndClears
        private void Table_Load(object sender, EventArgs e)
        {
            lblDS.Text = loseCount.ToString();
            lblPS.Text = winCount.ToString();
        }
        private void Clear_Table_Hand()
        {
            lblDS.Text = loseCount.ToString();
            lblPS.Text = winCount.ToString();
            for (int i = 0; i < myHand1.Count; i++)
            {
                myHand1.RemoveCard(i);
            }
            for (int i = 0; i < myHand2.Count; i++)
            {
                myHand2.RemoveCard(i);
            }
            panel1.Controls.Clear();
            panel2.Controls.Clear();
            btnHit.Visible = false;
            btnStay.Visible = false;
        }
        private void Clear_Table_Match()
        {
            loseCount = 0;
            winCount = 0;
            btn_Start.Visible = true;
            lblPS.Visible = false;
            lblDS.Visible = false;
            lblDSText.Visible = false;
            lblPSText.Visible = false;
            lblDS.Text = loseCount.ToString();
            lblPS.Text = winCount.ToString();
        }
        #endregion
    }
}
