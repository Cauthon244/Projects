﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Card_Project
{
    public static class House
    {
        public static bool isBust(int Current)
        {
            if (Current > 21)
            {
                return true;
            }
            return false;
        }
        public static bool isWinHand(int DS,int PS)
        {
            if (DS >= PS)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public static bool isFiveAndUnder(int handCount)
        {
            if (handCount == 5)
            {
                return true;
            }
            return false;
        }
        public static bool winOrLose(int givenScore)
        {
            if (givenScore == 10)
            {
                return true;
            }
            return false;
        }

    }
}
