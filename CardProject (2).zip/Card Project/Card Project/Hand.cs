﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Card_Project
{
   public class Hand
    {
        private List<Card> _cards = new List<Card>();

        public int Count
        {
            get
            {
                return _cards.Count;
            }
        }

        public Card this[int index]
        {
            get
            {
                return _cards[index];
            }
        }

        public void AddCard(Card newCard)
        {
            if (ContainsCard(newCard))
            {
                throw new ConstraintException(newCard.Face.ToString() + " of " + newCard.Suit.ToString() + " is in the Hand");
            }
            _cards.Add(newCard);
        }

        private bool ContainsCard(Card newCard)
        {
            foreach (Card card in _cards)
            {
                if (card.Face == newCard.Face && card.Suit == newCard.Suit)
                {
                    return true;
                }
            }
            return false;
        }

        public void RemoveCard(Card theCard)
        {
            _cards.Remove(theCard);
        }

        public void RemoveCard(int index)
        {
            _cards.RemoveAt(index);
        }

        public void RemoveCard(Suit theSuit, FaceValue theValue)
        {
            Card myCard = new Card(theSuit, theValue);
            _cards.Remove(myCard);
        }
        #region Score
        public int ScoreUp(Hand theHand)
        {
            int cCount = 0;
            for (int i = 0; i < theHand.Count; i++)
            {
                string temp = theHand[i].Face.ToString();
                if (temp == "Ace")
                {
                    cCount += 11;
                }
                else if (temp == "Two")
                {
                    cCount += 2;
                }
                else if (temp == "Three")
                {
                    cCount += 3;
                }
                else if (temp == "Four")
                {
                    cCount += 4;
                }
                else if (temp == "Five")
                {
                    cCount += 5;
                }
                else if (temp == "Six")
                {
                    cCount += 6;
                }
                else if (temp == "Seven")
                {
                    cCount += 7;
                }
                else if (temp == "Eight")
                {
                    cCount += 8;
                }
                else if (temp == "Nine")
                {
                    cCount += 9;
                }
                else
                {
                    cCount += 10;
                }
            }
            if (cCount > 21)
            {
                for (int i = 0; i < theHand.Count; i++)
                {
                    string isAce = theHand[i].Face.ToString();
                    if (isAce == "Ace")
                    {
                        cCount -= 10;
                    }
                }
            }
            return cCount;
        }
        #endregion

    }
}
