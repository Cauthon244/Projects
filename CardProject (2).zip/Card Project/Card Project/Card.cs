﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Card_Project
{
    public class Card
    {
        private Suit _Suit;
        private FaceValue _FaceValue;

        public Card(Suit newSuit, FaceValue newValue)
        {
            Suit = newSuit;
            Face = newValue;
        }
        public FaceValue Face { get; set; }
        public Suit Suit { get; set; }
    }
    public enum Suit
    {
        Hearts, Diamonds, Clubs, Spades,
    }
    public enum FaceValue
    {
        Ace, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King,
    }
}
