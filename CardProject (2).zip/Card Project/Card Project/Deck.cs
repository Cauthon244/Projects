﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Card_Project
{
    public class Deck
    {
        private List<Card> _Deck = new List<Card>();
        public void ProvideShuffledDeck()
        {
            for (int f = 0; f < 4; f++)
            {
                for (int i = 0; i < 13; i++)
                {
                    Card rez = new Card((Suit)f, (FaceValue)i);
                    _Deck.Add(rez);
                }
            }
            List<Card> shuffled = new List<Card>();
            Random myRandom = new Random();
            while (shuffled.Count() < _Deck.Count())
            {
                int x = myRandom.Next(_Deck.Count);
                Card toAdd = _Deck[x];
                _Deck.Remove(_Deck[x]);
                shuffled.Add(toAdd);
            }
            _Deck = shuffled;
        }
        public Deck()
        {
            ProvideShuffledDeck();
        }
        public Card DrawOneCard()
        {
            if (_Deck.Count == 0)
            {
                ProvideShuffledDeck();
            }
            Card stuff = _Deck[0];
            _Deck.Remove(_Deck[0]);
            return stuff;
        }
        public Hand DealHand(int number)
        {
            if (_Deck.Count == 0)
            {
                ProvideShuffledDeck();
            }
            Hand hand = new Hand();
            for (int i = 0; i < number; i++)
            {
                hand.AddCard(DrawOneCard());
            }
            return hand;
        }
    }
}
