﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals
{
    public partial class Cart : System.Web.UI.Page
    {
        string id;
        protected void Page_Load(object sender, EventArgs e)
        {
            date.InnerHtml = DateTime.Today.ToShortDateString();
            try
            {

                if (!IsPostBack)
                {
                    if (Session["username"] != null)
                    {
                        if (Request.Cookies["CartId"] == null || string.IsNullOrEmpty(Request.Cookies["CartId"].Value))
                        {
                            id = CreateCart();
                            
                            List<param> pa = new List<param>();
                            pa.Add(new param("@CartId", id, SqlDbType.Int, 0, ParameterDirection.Input));
                            pa.Add(new param("@Username", Session["username"].ToString(), SqlDbType.NVarChar, 50, ParameterDirection.Input));
                            Data.SendData("spCartUserAssign", pa);

                            Response.Cookies["CartId"].Value = id;
                            Response.Cookies["CartId"].Expires = DateTime.Today.AddDays(30);
                          
                        }
                        else
                        {
                            id = Request.Cookies["CartId"].Value;
                            List<param> pa = new List<param>();
                            pa.Add(new param("@CartId", id, SqlDbType.Int, 0, ParameterDirection.Input));
                            pa.Add(new param("@Username", Session["username"].ToString(), SqlDbType.NVarChar, 50, ParameterDirection.Input));
                            Data.SendData("spCartUserAssign", pa);
                        }
                    }
                    else
                    {
                        if (Request.Cookies["CartId"] == null || string.IsNullOrEmpty(Request.Cookies["CartId"].Value))
                        {
                            id = CreateCart();

                           

                            Response.Cookies["CartId"].Value = id;
                            Response.Cookies["CartId"].Expires = DateTime.Today.AddDays(30);

                        }
                        else
                        {
                            id = Request.Cookies["CartId"].Value;
                        }
                    }
                   
                    
                    if (!string.IsNullOrEmpty(Request.QueryString["prod_id"]))
                        {
                        AddToCart(id);
                        LoadCart(id);
                        Response.Redirect(Request.Url.AbsolutePath, false);
                        }
                    LoadCart(id);
                }



            }
            catch (Exception ex)
            {
                if (ex.Message == "Quantity Updated")
                {
                    LoadCart(id);
                    Response.Redirect(Request.Url.AbsolutePath, false);
                }
            }
            finally
            {
                layout l = Master as layout;
                l.hideCart();
            }
        }
        private void LoadCart(string id)
        {
            

            
                SqlCommand cmd = new SqlCommand("spGetCartItems", new SqlConnection(ConfigurationManager.ConnectionStrings["cnn"].ConnectionString));
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
            SqlParameter par = new SqlParameter("@CartId", SqlDbType.Int, 0);
            par.Direction = ParameterDirection.Input;
            par.Value = id;
            SqlParameter subtotal = new SqlParameter("@SubTotal", SqlDbType.Money, 0);
            subtotal.Direction = ParameterDirection.Output;
            SqlParameter total = new SqlParameter("@Total", SqlDbType.Money, 0);
            total.Direction = ParameterDirection.Output;
            SqlParameter shipping = new SqlParameter("@Shipping", SqlDbType.Money, 0);
            shipping.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(par);
            cmd.Parameters.Add(subtotal);
            cmd.Parameters.Add(total);
            cmd.Parameters.Add(shipping);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable ds = new DataTable();
            da.Fill(ds);
            double sub = double.Parse(subtotal.Value.ToString());
            double ship = double.Parse(shipping.Value.ToString());
            double tot = double.Parse(total.Value.ToString());
            double tax = sub * .15;
            lblCartSubtotal.Text = sub.ToString();
            lblShipping.Text = ship.ToString();
            lblTax.Text = tax.ToString();
            lblTotal.Text = tot.ToString();
            cartGrid.DataSource = ds;
            cartGrid.DataBind();
        }
        private void AddToCart(string cartId)
        {
            string product = Request.QueryString["prod_id"];
            if (!string.IsNullOrEmpty(product))
            {
                SqlDataReader dr = default(SqlDataReader);
                SqlCommand cmd = default(SqlCommand);


                List<param> pa = new List<param>();
                pa.Add(new param("@CartID", cartId, System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input));
                pa.Add(new param("@ProdID", product, System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input));
                pa.Add(new param("@Quantity", 1, System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input));
                Data.SendData("spAddToCart", pa);


            }
        }
        private string CreateCart()
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["cnn"].ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("spCreateCart", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlParameter output = new SqlParameter("@ID", System.Data.SqlDbType.Int);
                output.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(output);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                

                cmd.Connection.Open();

                cmd.ExecuteNonQuery();
                string id = output.Value.ToString();
                Response.Cookies["CartId"].Value = id;
                Response.Cookies["CartId"].Expires = DateTime.Today.AddDays(30);
                return id;
            }
        }

        protected void cartGrid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
                int rowIndex = int.Parse(e.CommandArgument.ToString());
           
            if (e.CommandName == "DeleteItem" || ((TextBox)cartGrid.Rows[rowIndex].Cells[2].FindControl("Quantity")).Text == "0" || ((TextBox)cartGrid.Rows[rowIndex].Cells[2].FindControl("Quantity")).Text == "")
            {
                List<param> pa = new List<param>();
                pa.Add(new param("@CartID", Request.Cookies["CartId"].Value, SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@ProdID", cartGrid.DataKeys[rowIndex][1].ToString(), SqlDbType.Int, 0, ParameterDirection.Input));
                Data.SendData("spCartItemDelete", pa);
                
                List<param> pa1 = new List<param>();
                pa1.Add(new param("@CartID", Request.Cookies["CartId"].Value, SqlDbType.Int, 0, ParameterDirection.Input));
                if (Data.GetData("spCheckCartExist", pa1).Rows[0][0].ToString() == "0")
                {
                    HttpCookie cookie = new HttpCookie("CartId");
                    cookie.Value = null;
                    cookie.Path += ";HttpOnly";
                    Response.Cookies.Add(cookie);
                    Response.Redirect("index.aspx");
                    return;
                }
              
                Response.Redirect("Cart.aspx");
            }
            else if (e.CommandName == "UpdateQty")
            {
                List<param> pa = new List<param>();

                pa.Add(new param("@QTY", ((TextBox)cartGrid.Rows[rowIndex].Cells[2].FindControl("Quantity")).Text, SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@CartID", Request.Cookies["CartId"].Value, SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@ProdID", cartGrid.DataKeys[rowIndex][1].ToString(), SqlDbType.Int, 0, ParameterDirection.Input));
                Data.SendData("spUpdateQty", pa);
                Response.Redirect("Cart.aspx");
                //int rowIndex = int.Parse(e.CommandArgument.ToString());
                //string val = cartGrid.DataKeys[rowIndex][1].ToString();

            }
        }

        protected void btnCheckOut_Click(object sender, EventArgs e)
        {
            if (Session["username"]==null)
            {
                layout m = (layout)this.Master;
                m.btnLog_Click(sender, EventArgs.Empty);
            }
            else
            {
                Response.Redirect("Account.aspx?check_out=1");
            }
        }
    }
}
    
