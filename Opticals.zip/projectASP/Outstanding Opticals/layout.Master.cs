﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals
{
    public partial class layout : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                FillCat();
            }
            try
            {
                if (Session["username"] == null)
                {
                    if (Request.Cookies["CartId"] == null || Request.Cookies["CartId"].Value == "")
                        hideCart();
                    else
                        displayCartButton((Request.Cookies["CartId"].Value), false);
                }
                else
                {
                    if (!(Request.Cookies["CartId"] == null || Request.Cookies["CartId"].Value == ""))
                        displayCartButton(Session["username"].ToString(), true);
                    else
                        hideCart();
                }
            }
            catch(Exception ex)
            {
                
            }
            LoadUsername();
        }
        private void displayCartButton(string id, bool user)
        {
            DataTable dt = new DataTable();
            List<param> pa = new List<param>();
            if (!user)
            {
                pa.Add(new param("@CartID", id, SqlDbType.Int, 0, ParameterDirection.Input));
                dt = Data.GetData("spGetBriefCart", pa);
            }
            else
            {
                try
                {
                    pa.Add(new param("@Username", Session["username"], SqlDbType.NVarChar, 50, ParameterDirection.Input));
                    dt = Data.GetData("spGetBriefCartByUserName", pa);
                }
                catch(Exception ex)
                {
                    //
                }
                }
            if (dt.Rows.Count > 0)
            {
            showCart();
                btnCartItems.Text = "Go to Cart ( Items: " + dt.Rows[0][0].ToString() + " )";
            }
        }
        //
        private void FillCat()
        {
            DataTable dt = Data.GetData("spCategoriesRetrieve", new List<param>());

            rptCat.DataSource = dt;
            rptCat.DataBind();
        }

        protected void btnSear_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtSearch.Text))
            {
                Response.Redirect("MultipleProducts.aspx?command_type=search&search_keyword=" + txtSearch.Text);
            }
            lblMessage.Text = "Search Field Empty";
            lblMessage.Visible = true;
        }
        private void LoadUsername()
        {
            if (Session["username"] != null)
            {
                login.Style.Add("display", "none");
                lblUsername.Text = Session["username"].ToString();
                btnLogOut.Visible = true;
                btnEditCust.Visible = true;
            }
            else
            {
                login.Style.Clear();
                btnLogOut.Visible = false;
                lblUsername.Text = "";
                btnEditCust.Visible = false;
            }
        }

        protected void btnCancelLogin_Click(object sender, EventArgs e)
        {
            id01.Style.Add("display","none");
        }

        public void btnLog_Click(object sender, EventArgs e)
        {
            id01.Style.Add("display", "block");
        }

        protected void btnLogIn_Click(object sender, EventArgs e)
        {
            try
            {
                List<param> pa = new List<param>();
                pa.Add(new param("@USERNAME", txtUresname.Text, System.Data.SqlDbType.VarChar, 25, System.Data.ParameterDirection.Input));
                pa.Add(new param("@PASSWORD", txtPassword.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));

                Data.GetData("spLogIn", pa);

                Session["username"] = txtUresname.Text;
                id01.Style.Add("display", "none");
                Response.Redirect(Request.Url.ToString());
            }
            catch (Exception ex)
            {
                lblMessageLogin.InnerText = ex.Message;
            }
        }

        protected void btnCartItems_Click(object sender, EventArgs e)
        {
            Response.Redirect("Cart.aspx");
        }

        internal void hideCart()
        {
            cartIcon.Visible = false;
            cartIcon.Style.Remove("display");
            cartIcon.Style.Add("display", "none");
        }
        internal void showCart()
        {
            cartIcon.Style.Remove("display");
            cartIcon.Style.Add("display", "block");
        }
        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            Session["username"] = null;
            Response.Redirect("index.aspx");
        }

        protected void btnEditCust_Click(object sender, EventArgs e)
        {
            Response.Redirect("Account.aspx");
        }
        //document.getElementById('id01').style.display='none'
    }
}