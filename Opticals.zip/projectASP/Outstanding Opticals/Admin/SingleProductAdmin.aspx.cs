﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals
{
    public partial class SingleProductAdmin : System.Web.UI.Page
    {
        private object ddlImages;

        private void LoadDropDowns()
        {
            Dictionary<int, string> StatusDict = new Dictionary<int, string>();

            foreach (int value in Enum.GetValues(typeof(Status)))
            {
                string name = Enum.GetName(typeof(Status), value);
                StatusDict.Add(value + 1, name);
            }

            ddlStatus.DataSource = StatusDict;
            ddlStatus.DataTextField = "Value";
            ddlStatus.DataValueField = "Key";
            ddlStatus.DataBind();

            DataTable temp = Data.GetData("spBrandsRetrieve", new List<param>());
            ddlBrands.DataSource = temp;
            ddlBrands.DataTextField = "brand_name";
            ddlBrands.DataValueField = "brand_id";
            ddlBrands.DataBind();

            temp = Data.GetData("spCategoriesRetrieve", new List<param>());
            ddlCat.DataSource = temp;
            ddlCat.DataTextField = "cat_name";
            ddlCat.DataValueField = "cat_id";
            ddlCat.DataBind();

            temp = Data.GetData("spGetImages", new List<param>());
            ddlImg.DataSource = temp;
            ddlImg.DataTextField = "ImgName";
            ddlImg.DataValueField = "ImgId";
            ddlImg.DataBind();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string proId = Request.QueryString["prod_id"];
                string inserting = Request.QueryString["inserting"];
                LoadDropDowns();
                if(inserting==null)
                {
                    LoadData(proId);
                    Insert.Visible = false;
                }
                else{
                    btnDelete.Visible = false;
                    btnUpdate.Visible = false;
                    Insert.Visible = true;
                    imgImage.ImageUrl = "~/Images/default.png";
                    ddlImg.Visible = false;
                }
                
                ViewState["PreviousPage"] = Request.UrlReferrer;
            }
        }

        private void LoadData(string id)
        {
            if (!IsPostBack)
            {
                List<param> pa = new List<param>();
                pa.Add(new param("@ID", id, SqlDbType.Int, 0, ParameterDirection.Input));
                DataTable dt = Data.GetData("spProductRetrieveById", pa);

                lblId.Text = dt.Rows[0]["prod_id"].ToString();
                txtName.Text = dt.Rows[0]["prod_name"].ToString();
                txtPrice.Text = dt.Rows[0]["prod_price"].ToString();
                txtShortDesc.Text = dt.Rows[0]["prod_descriptionShort"].ToString();
                txtDesc.Text = dt.Rows[0]["prod_description"].ToString();
                imgImage.ImageUrl = "~/images/" + dt.Rows[0]["ImgName"].ToString();
                cbxFeatured.Checked = (Boolean)dt.Rows[0]["prod_isFeatured"];

                ddlBrands.SelectedValue = dt.Rows[0]["brand_id"].ToString();
                ddlCat.SelectedValue = dt.Rows[0]["cat_id"].ToString();
                ddlStatus.SelectedValue = dt.Rows[0]["status"].ToString();
                ddlImg.SelectedValue = dt.Rows[0]["ImgName"].ToString();
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                List<param> pa = new List<param>();
                pa.Add(new param("@ProdID", int.Parse(lblId.Text), SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@ProdName", txtName.Text, SqlDbType.VarChar, 50, ParameterDirection.Input));
                pa.Add(new param("@ProdDesc", txtDesc.Text, SqlDbType.Text, 0, ParameterDirection.Input));
                pa.Add(new param("@ProdDescShort", txtShortDesc.Text, SqlDbType.VarChar, 144, ParameterDirection.Input));
                pa.Add(new param("@ProdPrice", double.Parse(txtPrice.Text), SqlDbType.Money, 0, ParameterDirection.Input));
                pa.Add(new param("@Status", int.Parse(ddlStatus.SelectedValue), SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@IsFeat", cbxFeatured.Checked, SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@Image", ddlImg.SelectedValue, SqlDbType.VarChar, 30, ParameterDirection.Input));
                pa.Add(new param("@BrandID", int.Parse(ddlBrands.SelectedValue), SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@CatID", int.Parse(ddlCat.SelectedValue), SqlDbType.Int, 0, ParameterDirection.Input));

                Data.SendData("spprodUpdate", pa);
                Label lblMessage = (Label)(Master.FindControl("lblMessage"));
                lblMessage.Visible = true;
                lblMessage.Text = "Updated succesfully";
            }
            catch(Exception ex)
            {
                Label lblMessage = (Label)(Master.FindControl("lblMessage"));
                lblMessage.Visible = true;
                lblMessage.Text = ex.Message;
            }

        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect(ViewState["PreviousPage"].ToString());
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                List<param> pa = new List<param>();
                pa.Add(new param("@ProdID", int.Parse(lblId.Text), SqlDbType.Int, 0, ParameterDirection.Input));

                Data.SendData("spProdDelete", pa);
                Label lblMessage = (Label)(Master.FindControl("lblMessage"));
                lblMessage.Visible = true;
                lblMessage.Text = "Deleted succesfully";
            }
            catch (Exception ex)
            {
                Label lblMessage = (Label)(Master.FindControl("lblMessage"));
                lblMessage.Visible = true;
                lblMessage.Text = ex.Message;
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                List<param> pa = new List<param>();
                //pa.Add(new param("@ProdID", int.Parse(lblId.Text), SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@ProdName", txtName.Text, SqlDbType.VarChar, 50, ParameterDirection.Input));
                pa.Add(new param("@ProdDesc", txtDesc.Text, SqlDbType.Text, 0, ParameterDirection.Input));
                pa.Add(new param("@ProdDescShort", txtShortDesc.Text, SqlDbType.VarChar, 144, ParameterDirection.Input));
                pa.Add(new param("@ProdPrice", double.Parse(txtPrice.Text), SqlDbType.Money, 0, ParameterDirection.Input));
                pa.Add(new param("@Status", int.Parse(ddlStatus.SelectedValue), SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@IsFeat", cbxFeatured.Checked, SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@Image", "default.png", SqlDbType.VarChar, 30, ParameterDirection.Input));
                pa.Add(new param("@BrandID", int.Parse(ddlBrands.SelectedValue), SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@CatID", int.Parse(ddlCat.SelectedValue), SqlDbType.Int, 0, ParameterDirection.Input));

                Data.SendData("spprodInsert", pa);
                Label lblMessage = (Label)(Master.FindControl("lblMessage"));
                lblMessage.Visible = true;
                lblMessage.Text = "Added succesfully";
            }
            catch(Exception ex)
            {
                Label lblMessage = (Label)(Master.FindControl("lblMessage"));
                lblMessage.Visible = true;
                lblMessage.Text = ex.Message;
            }
        }
    }
}