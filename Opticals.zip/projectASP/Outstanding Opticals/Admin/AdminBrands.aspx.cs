﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals
{
    public partial class AdminBrands : System.Web.UI.Page
    {
        Label lblMessage;
        private void setUpForm()
        {
            hideme.Visible = false;
            insertDiv.Visible = false;
            hideRow.Visible = true;
            ddlBrand.Items.Clear();
            ddlBrand.Items.Add(new ListItem("--Choose Item To Update--", "0"));
            FillBrand();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
                lblMessage = (Label)(Master.FindControl("lblMessage"));
            lblMessage.Visible = true;
            if (!IsPostBack)
            {
                setUpForm();
            }
        }
            DataTable dt = Data.GetData("spBrandsRetrieve", new List<param>());
        private void FillBrand()
        {
            List<param> pa = new List<param>();
            dt = Data.GetData("spBrandsRetrieve", new List<param>());
            ddlBrand.DataSource = dt;
            ddlBrand.DataTextField = "brand_name";
            ddlBrand.DataValueField = "brand_id";
            ddlBrand.DataBind();
        }

        protected void ddlBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (((DropDownList)sender).SelectedValue.ToString() != "0")
            {
                hideme.Visible = true;
                txtName.Text = ddlBrand.SelectedItem.Text;
                txtDesc.Text = dt.Rows[ddlBrand.SelectedIndex - 1]["brand_desc"].ToString();
                //lblCatName.Text;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            List<param> pa = new List<param>();

            pa.Add(new param("@BrandID", ddlBrand.SelectedValue, SqlDbType.Int, 0, ParameterDirection.Input));
            pa.Add(new param("@BrandName", txtName.Text, SqlDbType.VarChar, 50, ParameterDirection.Input));
            pa.Add(new param("@BrandDesc", txtDesc.Text, SqlDbType.Text,0, ParameterDirection.Input));

            Data.SendData("spBrandUpdate", pa);
            lblMessage.Text = "Update Successfully";
            hideme.Visible = false;
            setUpForm();
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtDesc.Text = "";
            hideRow.Visible = false;
            hideme.Visible = false;
            insertDiv.Visible = true;
        }

        protected void btnActuallyInsert_Click(object sender, EventArgs e)
        {
            try
            {

                List<param> pa = new List<param>();


                pa.Add(new param("@BrandName", txtInsert.Text, SqlDbType.VarChar, 50, ParameterDirection.Input));
                pa.Add(new param("@BrandDesc", txtInsertDesc.Text, SqlDbType.Text,0, ParameterDirection.Input));
                //pa.Add(new param("@BrandLogo", txtInsertLogo.Text, SqlDbType.VarChar, 30, ParameterDirection.Input));

                Data.SendData("spBrandInsert", pa);
                lblMessage.Text = "Inserted Successfully";
                hideme.Visible = false;
                setUpForm();
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message;
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            setUpForm();
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {


                List<param> pa = new List<param>();

                pa.Add(new param("@BrandID", ddlBrand.SelectedValue, SqlDbType.Int, 0, ParameterDirection.Input));


                Data.SendData("spBrandDelete", pa);
                lblMessage.Text = "Deleted Successfully";
                hideme.Visible = false;
                setUpForm();
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message;
            }
        }
    }
}