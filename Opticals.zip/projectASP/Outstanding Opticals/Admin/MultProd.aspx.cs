﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals.Admin
{
    public partial class MultProd : System.Web.UI.Page
    {
        private void FillDdl()
        {
            Dictionary<int, string> StatusDict = new Dictionary<int, string>();

            foreach (int value in Enum.GetValues(typeof(Status)))
            {
                string name = Enum.GetName(typeof(Status), value);
                StatusDict.Add(value + 1, name);
            }


            DataTable temp = Data.GetData("spBrandsRetrieve", new List<param>());
            ddlBrands.DataSource = temp;
            ddlBrands.DataTextField = "brand_name";
            ddlBrands.DataValueField = "brand_id";
            ddlBrands.DataBind();
            ddlBrands.SelectedIndex = 0;

            temp = Data.GetData("spCategoriesRetrieve", new List<param>());
            ddlCat.DataSource = temp;
            ddlCat.DataTextField = "cat_name";
            ddlCat.DataValueField = "cat_id";
            ddlCat.DataBind();
            ddlCat.SelectedIndex = 0;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (String.IsNullOrEmpty(Request.QueryString["search"]))
                {
                    FillDdl();
                    FillRptWithAllProd();
                }
                else
                {
                    hideme.Visible = false;
                    DisplayBySearch(Request.QueryString["search"]);
                }
            }
        }
        private void DisplayBySearch(string key)
        {
            List<param> pa = new List<param>();
            pa.Add(new param("@KeyWord", key, SqlDbType.VarChar, 50, ParameterDirection.Input));
            DataTable dt = Data.GetData("spProductSearch", pa);
            if (dt.Rows.Count > 0)
            {
                rptProd.DataSource = dt;
                rptProd.DataBind();
                headerForRpt.InnerText = "Products by keyword: " + key;
            }
            else
            {
                headerForRpt.InnerText = "No Rows Found";
            }
        }
        private void FillRptWithAllProd()
        {
            DataTable dt = Data.GetData("spProductsRetrieve", new List<param>());
            rptProd.DataSource = dt;
            rptProd.DataBind();
        }

        protected void btnCat_Click1(object sender, EventArgs e)
        {
            ddlBrands.SelectedIndex = 0;
            DataTable dt = new DataTable();
            List<param> pa = new List<param>();
            if (ddlCat.SelectedValue != "0")
            {
                pa.Add(new param("@Cat", int.Parse(ddlCat.SelectedValue), SqlDbType.Int, 0, ParameterDirection.Input));
                dt = Data.GetData("spProductRetrieveByCategory", pa);
            }
            else
            {
                dt = Data.GetData("spProductsRetrieve", new List<param>());
            }
            rptProd.DataSource = dt;
            rptProd.DataBind();

        }


        protected void btnBrands_Click(object sender, EventArgs e)
        {
            ddlCat.SelectedIndex = 0;
            DataTable dt = new DataTable();
            List<param> pa = new List<param>();
            if (ddlBrands.SelectedValue != "0")
            {
                pa.Add(new param("@Brand", int.Parse(ddlBrands.SelectedValue), SqlDbType.Int, 0, ParameterDirection.Input));
                dt = Data.GetData("spProductRetrieveByBrand", pa);
            }
            else
            {
                dt = Data.GetData("spProductsRetrieve", new List<param>());
            }
            rptProd.DataSource = dt;
            rptProd.DataBind();
        }
    }
}