﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals.Admin
{
    public partial class ManageCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            chosenInfo.Visible = false;           
            ddlCustChoice.Items.Clear();
            ddlCustChoice.Items.Add("-Select User-");
            List<param> pa = new List<param>();
            pa.Add(new param("@KeyWord", txtSearch.Text, System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input));
            ddlCustChoice.DataSource = Data.GetData("spSearchCustomer", pa);
            ddlCustChoice.DataTextField = "username";
            ddlCustChoice.DataBind();
            searchResults.Visible = true;
            ((Label)Master.FindControl("lblMessage")).Text = "";
        }

        protected void ddlCustChoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlCustChoice.Text != "-Select User-")
            {
                List<param> pa = new List<param>();
                pa.Add(new param("@UserName", ddlCustChoice.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                DataTable dt = Data.GetData("spCustEditRetrieve", pa);
                lblID.Text = dt.Rows[0]["Custid"].ToString();
                txtFName.Text = dt.Rows[0]["fname"].ToString();
                txtMname.Text = dt.Rows[0]["mname"].ToString();
                txtLastName.Text = dt.Rows[0]["lname"].ToString();
                DateTime date = (DateTime)dt.Rows[0]["dateOfBirth"];
                txtDoB.Text = String.Format("{0:yyyy-MM-dd}", date);
                txtEmail.Text = dt.Rows[0]["email"].ToString();
                txtPhone.Text = dt.Rows[0]["phone"].ToString();
                if (dt.Rows[0]["isArchived"].ToString() == "True")
                {
                    chkArc.Checked = true;
                }
                else
                {
                    chkArc.Checked = false;
                }
                chosenInfo.Visible = true;
            }
        }

        protected void btnChangeSave_Click(object sender, EventArgs e)
        {
            ((Label)Master.FindControl("lblMessage")).Visible = true;
            if (Page.IsValid)
            {
                try
                {
                    List<param> pa = new List<param>();
                    pa.Add(new param("@UserName", ddlCustChoice.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@FirstName", txtFName.Text, SqlDbType.NVarChar, 50, ParameterDirection.Input));
                    pa.Add(new param("@MiddleName", txtMname.Text, SqlDbType.NVarChar, 50, ParameterDirection.Input));
                    pa.Add(new param("@LastName", txtLastName.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@Phone", txtPhone.Text, SqlDbType.NVarChar, 10, ParameterDirection.Input));
                    pa.Add(new param("@Email", txtEmail.Text, SqlDbType.NVarChar, 50, ParameterDirection.Input));
                    pa.Add(new param("@DoB", txtDoB.Text, System.Data.SqlDbType.Date, 0, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@isArc", chkArc.Checked.ToString(), System.Data.SqlDbType.Bit, 0, System.Data.ParameterDirection.Input));
                    Data.SendData("spEditCustAdmin", pa);
                    ((Label)Master.FindControl("lblMessage")).Text = "<h1>Customer updated</h1>";
                    chosenInfo.Visible = false;
                    searchResults.Visible = false;
                    txtSearch.Text = "";
                }
                catch (Exception ex)
                {
                    ((Label)Master.FindControl("lblMessage")).Text = "<h1>" + ex.Message + "</h1>";
                }
            }
            else
            {
                ((Label)Master.FindControl("lblMessage")).Text = "Please Fix Improper Information";
            }
        }
    }
}