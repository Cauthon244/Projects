﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals.Admin
{
    public partial class AdminView : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSear_Click(object sender, EventArgs e)
        {
            Response.Redirect("MultProd.aspx?search=" + txtSearch.Text);
        }
    }
}