﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals
{
    public partial class manageCatInfo : System.Web.UI.Page
    {
        Label lblMessage;
        private void setUpForm()
        {
            hideme.Visible = false;
            insertDiv.Visible = false;
            hideRow.Visible = true;
            ddlCat.Items.Clear();
            ddlCat.Items.Add(new ListItem("--Choose Item To Update--", "0"));
            FillCat();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMessage = (Label)(Master.FindControl("lblMessage"));
            lblMessage.Visible = true;
            if (!IsPostBack)
            {
                setUpForm();
            }
        }
        DataTable dt= Data.GetData("spCategoriesRetrieve", new List<param>());
        private void FillCat()
        {
            List<param> pa = new List<param>();
            dt = Data.GetData("spCategoriesRetrieve", new List<param>());
            ddlCat.DataSource = dt;
            ddlCat.DataTextField = "cat_name";
            ddlCat.DataValueField = "cat_id";
            ddlCat.DataBind();
            
        }

        protected void ddlCat_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (((DropDownList)sender).SelectedValue.ToString() != "0")
            {
                hideme.Visible = true;
                hideRow.Visible = false;
                txtName.Text = ddlCat.SelectedItem.Text;

                txtDesc.Text =  dt.Rows[ddlCat.SelectedIndex - 1]["cat_desc"].ToString();
                //lblCatName.Text;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            List<param> pa = new List<param>();

            pa.Add(new param("@CatID", ddlCat.SelectedValue, SqlDbType.Int, 0, ParameterDirection.Input));
            pa.Add(new param("@CatName", txtName.Text, SqlDbType.VarChar, 30, ParameterDirection.Input));
            pa.Add(new param("@CatDesc", txtDesc.Text, SqlDbType.VarChar, 144, ParameterDirection.Input));

            Data.SendData("spcatUpdate", pa);
            lblMessage.Text = "Update Successfully";
            hideme.Visible = false;
            setUpForm();
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtDesc.Text = "";
            hideRow.Visible = false;
            hideme.Visible = false;
            insertDiv.Visible = true;
        }

        protected void btnActuallyInsert_Click(object sender, EventArgs e)
        {
            try
            {

            List<param> pa = new List<param>();

            
            pa.Add(new param("@CatName", txtInsert.Text, SqlDbType.VarChar, 30, ParameterDirection.Input));
            pa.Add(new param("@CatDesc", txtInsertDesc.Text, SqlDbType.VarChar, 144, ParameterDirection.Input));

                Data.SendData("spCatInsert", pa);
                lblMessage.Text = "Inserted Successfully";
            hideme.Visible = false;
                setUpForm();
            }
            catch(Exception ex)
            {
                lblMessage.Text = ex.Message;
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            setUpForm();
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {


                List<param> pa = new List<param>();

                pa.Add(new param("@CatID", ddlCat.SelectedValue, SqlDbType.Int, 0, ParameterDirection.Input));


                Data.SendData("spCatDelete", pa);
                lblMessage.Text = "Deleted Successfully";
                hideme.Visible = false;
                setUpForm();
            }
            catch(Exception ex)
            {
                lblMessage.Text = ex.Message;
            }
        }
    }
}