﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals
{
    public partial class Verif : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ((Label)Master.FindControl("lblMessage")).Visible = true;
            try
            {
                string token = Request.QueryString["key"];
                List<param> pa = new List<param>();
                pa.Add(new param("@Key", token, System.Data.SqlDbType.VarChar, 50, System.Data.ParameterDirection.Input));
                Data.SendData("spVerify", pa);
                ((Label)Master.FindControl("lblMessage")).Text = "<h1>Customer updated</h1>";
            }
            catch(Exception ex)
            {
                ((Label)Master.FindControl("lblMessage")).Text = "<h1>" + ex.Message + "</h1>";
            }
        }
    }
}