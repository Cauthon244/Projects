﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals
{
    public partial class MultipleProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string commandType = Request.QueryString["command_type"];
                switch(commandType)
                {
                    case "category":
                        LoadByCat();
                        break;
                    case "search":
                        FillBySearch();
                        break;
                    default:
                        break;
                }
            }
        }
        private void LoadByCat()
        {
            string catId = Request.QueryString["cat_id"];
            List<param> pa = new List<param>();
            pa.Add(new param("@Cat",catId, System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input));
            DataTable dt = Data.GetData("spProductRetrieveByCategory", pa);



            rptResult.DataSource = dt;
            rptResult.DataBind();
        }

        private void FillBySearch()
        {
            string keyword = Request.QueryString["search_keyword"];
            List<param> pa = new List<param>();
            pa.Add(new param("@KeyWord", keyword, SqlDbType.VarChar, 50, ParameterDirection.Input));
            DataTable dt = Data.GetData("spProductSearch", pa);

            rptResult.DataSource = dt;
            rptResult.DataBind();
        }
       
        }
    }
