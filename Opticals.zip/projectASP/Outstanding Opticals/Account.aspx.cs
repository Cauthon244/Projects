﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals
{
    public partial class Account : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.MaintainScrollPositionOnPostBack = true;
            string checkoutVar = Request.QueryString["check_out"]==null?null: Request.QueryString["check_out"].ToString();
            if (!IsPostBack)
            {
                if (Session["username"] != null)
                {
                    UpdateHide1.Visible = false;
                    UpdateHide2.Visible = false;
                    dtpDOB.ReadOnly = true;
                    List<param> pa = new List<param>();
                    pa.Add(new param("@UserName", Session["username"].ToString(), System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));

                    DataTable dt = Data.GetData("spCustEditRetrieve", pa);
                    txtFName.Text = dt.Rows[0]["fname"].ToString();
                    txtLName.Text = dt.Rows[0]["lname"].ToString();
                    txtMName.Text = dt.Rows[0]["mname"].ToString();
                    txtPhone.Text = dt.Rows[0]["phone"].ToString().ToString();
                    txtEmail.Text = dt.Rows[0]["email"].ToString();
                    DateTime date = (DateTime)dt.Rows[0]["dateOfBirth"];
                    dtpDOB.Text = String.Format("{0:yyyy-MM-dd}", date);
                    lblAddHold.Text = dt.Rows[0]["address_id"].ToString();
                    txtStreet.Text = dt.Rows[0]["Address"].ToString();
                    txtProvince.Text = dt.Rows[0]["Province"].ToString();
                    txtPostal.Text = dt.Rows[0]["PostalCode"].ToString();
                    txtCity.Text = dt.Rows[0]["City"].ToString();
                    txtCountry.Text = dt.Rows[0]["Country"].ToString();
                    checkout.Visible = false;
                    btnBack.Visible = true;
                    card.Visible = false;
                }
                else
                {
                    btnUpdate.Visible = false;
                    btnUpdateAddress.Visible = false;
                    txtFName.ReadOnly = false;
                    card.Visible = false;
                    checkout.Visible = false;
                }
                hidecheckout.Visible = false;
                btnCheckOut.Visible = false;
            }
            if(checkoutVar=="1")
            {
                hidecheckout.Visible = !cbxShip.Checked;
                checkout.Visible = true;
                btnCheckOut.Visible = true;
                btnBack.Visible = false;
                card.Visible = true;
            }
        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            args.IsValid = (args.Value.Length > 8);
        }

        protected void vldProvince_ServerValidate(object source, ServerValidateEventArgs args)
        {
            args.IsValid = (args.Value.Length == 2);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                try
                {
                    List<param> pa = new List<param>();
                    pa.Add(new param("@UserName", txtUsername.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@Password", txtPass.Text, System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@Email", txtEmail.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@FirstName", txtFName.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@MiddleName", txtMName.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@LastName", txtLName.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@Phone", txtPhone.Text, System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@DoB", dtpDOB.Text, System.Data.SqlDbType.Date, 10, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@Country", txtCountry.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@Address", txtStreet.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@City", txtCity.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@Province", txtProvince.Text, System.Data.SqlDbType.Char, 2, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@Postal", txtPostal.Text, System.Data.SqlDbType.NChar, 6, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@AddressType", "Residence", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input));
                    Guid token = Guid.NewGuid();
                    pa.Add(new param("@Token", token.ToString(), System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                    Data.SendData("spCustInsertIniAddress", pa);
                    MailMessage mailMessage = new MailMessage();
                    mailMessage.To.Add(txtEmail.Text);
                    mailMessage.From = new MailAddress("admin@OutstandingOpticals.com");
                    mailMessage.Subject = "Confiramtion Link";
                    mailMessage.IsBodyHtml = true;
                    mailMessage.Body = "<h2>Hello " + txtFName.Text+"!</h2>" +
                                        "<p> Your confirmation link: <a href = \"http://" + HttpContext.Current.Request.Url.Host + ":64465/Verif.aspx?key=" + token.ToString() + "\" >http://" + HttpContext.Current.Request.Url.Host + ":64465/Verif.aspx?key=" + token.ToString()+"</a></p>";
                    SmtpClient smtpClient = new SmtpClient("localhost");
                    smtpClient.Send(mailMessage);
                    Session["username"] = txtUsername.Text;
                    Response.Redirect("index.aspx");
                }
                catch (SqlException ex)
                {
                    H1.InnerHtml = ex.Number + "   " + ex.Message;
                }
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("index.aspx");
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            List<param> pa = new List<param>();
            pa.Add(new param("@UserName", Session["username"].ToString(), System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
            pa.Add(new param("@Password", txtPass.Text, System.Data.SqlDbType.NVarChar, 15, System.Data.ParameterDirection.Input));
            pa.Add(new param("@Email", txtEmail.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
            pa.Add(new param("@FirstName", txtFName.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
            pa.Add(new param("@MiddleName", txtMName.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
            pa.Add(new param("@LastName", txtLName.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
            pa.Add(new param("@Phone", txtPhone.Text, System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input));
            //pa.Add(new param("@DoB", dtpDOB.Text, System.Data.SqlDbType.Date, 10, System.Data.ParameterDirection.Input));
            //pa.Add(new param("@Country", txtCountry.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
            //pa.Add(new param("@Address", txtStreet.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
            //pa.Add(new param("@City", txtCity.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
            //pa.Add(new param("@Province", txtProvince.Text, System.Data.SqlDbType.Char, 2, System.Data.ParameterDirection.Input));
            //pa.Add(new param("@Postal", txtPostal.Text, System.Data.SqlDbType.NChar, 6, System.Data.ParameterDirection.Input));
            //pa.Add(new param("@AddressType", "Residence", System.Data.SqlDbType.NVarChar, 10, System.Data.ParameterDirection.Input));
            Data.SendData("spCustomerUpdate", pa);
            //Response.Redirect("index.aspx");
        }
        bool State = false;
        protected void cbxShip_CheckedChanged(object sender, EventArgs e)
        {
            hidecheckout.Visible = !cbxShip.Checked;
            setstate(State);
        }
        protected void btnUpdateAdd_Click(object sender, EventArgs e)
        {
            List<param> pa = new List<param>();
            pa.Add(new param("@Country", txtCountry.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
            pa.Add(new param("@Address", txtStreet.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
            pa.Add(new param("@City", txtCity.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
            pa.Add(new param("@Province", txtProvince.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
            pa.Add(new param("@PostCode", txtPostal.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
            pa.Add(new param("@AddressId", lblAddHold.Text, System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input));

            Data.SendData("spUpdateAddress", pa);
        }
        protected void btnCheckOut_Click(object sender, EventArgs e)
        {
            try
            {
                List<param> pa = new List<param>();
                pa.Add(new param("@CartId", Request.Cookies["CartId"].Value.ToString(), SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@ShipAddress", lblShip.Text == "" ? lblAddHold.Text : lblShip.Text, SqlDbType.Int, 0, ParameterDirection.Input));
                pa.Add(new param("@PayType", rdoMethods.SelectedValue, SqlDbType.NVarChar, 2, ParameterDirection.Input));
                pa.Add(new param("@OrderStatus", "Awaiting Fullfilment", SqlDbType.NVarChar, 20, ParameterDirection.Input));
                pa.Add(new param("@UserName", Session["username"].ToString(), SqlDbType.VarChar, 50, ParameterDirection.Input));

                DataTable info = Data.GetData("spCheckOut", pa);



                List<param> par = new List<param>();
                par.Add(new param("@UserName", Session["username"].ToString(), SqlDbType.VarChar, 50, ParameterDirection.Input));
                DataTable dt = Data.GetData("spCustEditRetrieve", par);

                MailMessage mailMessage = new MailMessage();
                mailMessage.To.Add(dt.Rows[0]["email"].ToString());
                mailMessage.From = new MailAddress("admin@OutstandingOpticals.com");
                mailMessage.Subject = "Order Accepted";
                mailMessage.IsBodyHtml = true;
                mailMessage.Body = "<h2>Hello " + dt.Rows[0]["lname"].ToString() + ", " + dt.Rows[0]["fname"].ToString() + "</h2>" +
                                    "<p> Your order has been recieved</p>" + "<p>Subtotal: " + String.Format("{0:c}",info.Rows[0]["subtotal"])+ "</p><p> Shipping Cost: " + String.Format("{0:c}", info.Rows[0]["shippingCost"]) + "</p><p>Tax: " + String.Format("{0:c}", double.Parse(info.Rows[0]["subtotal"].ToString())* .15) + "</p><p>Final Total: " + String.Format("{0:c}", info.Rows[0]["totalCost"])
                                    + "<p>More info: <a href = \"http://" + HttpContext.Current.Request.Url.Host + ":64465/OrderDetails.aspx?key=" + info.Rows[0]["id"].ToString() + "\" >http://" + HttpContext.Current.Request.Url.Host + ":64465/OrderDetails.aspx?key=" + info.Rows[0]["id"].ToString() + "</a></p>";
                SmtpClient smtpClient = new SmtpClient("localhost");
                smtpClient.Send(mailMessage);

                Response.Cookies["CartId"].Value = "";
                Response.Redirect("index.aspx");
            }
            catch (SmtpException ex)
            {
                H1.InnerHtml = ex.Message + " Please contact Admin admin@OutstandingOpticals.com";
            }
            catch (Exception ex)
            {
                H1.InnerHtml = ex.Message;
            }
        }

        private void setstate(bool state)
        {
            txtShipCountry.ReadOnly = state;
            txtShipCity.ReadOnly = state;
            txtShipStreet.ReadOnly = state;
            txtShipProvince.ReadOnly = state;
            txtShipPostal.ReadOnly = state;
        }

        protected void btnInsertShip_Click(object sender, EventArgs e)
        {

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["cnn"].ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("spInsertAddress", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlParameter output = new SqlParameter("@AddressId", System.Data.SqlDbType.Int);
                output.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(output);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                List<param> pa = new List<param>();
                pa.Add(new param("@Country", txtShipCountry.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
                pa.Add(new param("@Address", txtShipStreet.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
                pa.Add(new param("@City", txtShipCity.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
                pa.Add(new param("@Province", txtShipProvince.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                pa.Add(new param("@PostCode", txtShipPostal.Text, System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                pa.Add(new param("@AddType", "Shippingad", System.Data.SqlDbType.NChar, 10, System.Data.ParameterDirection.Input));
                pa.Add(new param("@UserName", Session["username"].ToString(), System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input));
                foreach (param p in pa)
                {
                    SqlParameter par = new SqlParameter(p.name, p.type, p.size);
                    par.Value = p.value;
                    par.Direction = p.direction;
                    cmd.Parameters.Add(par);
                }


                cmd.Connection.Open();

                cmd.ExecuteNonQuery();
                lblShip.Text= output.Value.ToString();
            }

                
            btnInsertShip.Visible = false;
            setstate(true);
            State = true;
            hidecheckout.Visible = !cbxShip.Checked;
        }

        protected void CustomValidator4_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (DateTime.Now.AddYears(-19) >= DateTime.Parse(args.Value))
            {
                args.IsValid = true;
            }
            else
                args.IsValid = false;
        }

        protected void btnPayment_Click(object sender, EventArgs e)
        {
            
        }
    }
}
