﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals
{
    public partial class LogIn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogIn_Click(object sender, EventArgs e)
        {
            try
            {
                List<param> pa = new List<param>();
                pa.Add(new param("@USERNAME", txtUserName.Text, System.Data.SqlDbType.VarChar, 25, System.Data.ParameterDirection.Input));
                pa.Add(new param("@PASSWORD", txtPassword.Text, System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input));
                if (!(Request.Cookies["CartId"] == null || Request.Cookies["CartId"].Value == ""))
                {
                    pa = new List<param>();
                    pa.Add(new param("@Username", txtUserName.Text, System.Data.SqlDbType.VarChar, 25, System.Data.ParameterDirection.Input));
                    pa.Add(new param("@CartId", Request.Cookies["CartId"], System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input));
                    Data.SendData("spCartUserAssign", pa);
                }
                Data.GetData("spLogIn", pa);
                Session["username"] = txtUserName.Text;
                Response.Redirect("index.aspx");

                
            }
            catch(Exception ex)
            {
                lblMessage.Text = ex.Message;
            }
        }
    }
}