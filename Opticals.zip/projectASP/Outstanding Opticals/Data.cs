﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Outstanding_Opticals
{
    public static class Data
    {
        #region "Data Work"
        private static string cnnString = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
        public static  DataTable GetData(string sqlStat, List<param> paramlist)
        {
            SqlConnection cnn = new SqlConnection(cnnString);
            SqlCommand cmd = new SqlCommand(sqlStat, cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (param p in paramlist)
            {
                SqlParameter pa = new SqlParameter(p.name, p.type, p.size);
                pa.Value = p.value;
                pa.Direction = p.direction;
                cmd.Parameters.Add(pa);
            }
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable ds = new DataTable();
            da.Fill(ds);
            return ds;
        }

        public static void SendData(string SqlStatement, List<param> paramlist)
        {
            SqlConnection cnn = new SqlConnection(cnnString);
            SqlCommand cmd = new SqlCommand(SqlStatement, cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (param p in paramlist)
            {
                SqlParameter pa = new SqlParameter(p.name, p.type, p.size);
                pa.Value = p.value;
                pa.Direction = p.direction;
                cmd.Parameters.Add(pa);
            }
            using (cnn)
            {
                cnn.Open();
                int count = cmd.ExecuteNonQuery();
                cnn.Close();
            }
        }
        #endregion
    }
}