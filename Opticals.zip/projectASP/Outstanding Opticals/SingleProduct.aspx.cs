﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals
{
    public partial class SingleProduct : System.Web.UI.Page
    {
        string proId;
        protected void Page_Load(object sender, EventArgs e)
        {
           proId  = Request.QueryString["prod_id"];
            if (!IsPostBack)
            {
                //Dictionary<int, string> StatusDict = new Dictionary<int, string>();

                //foreach (int value in Enum.GetValues(typeof(Status)))
                //{
                //    string name = Enum.GetName(typeof(Status), value);
                //    StatusDict.Add(value + 1, name);
                //}

                //DropDownList

                //ddlStatus.DataSource = StatusDict;
                //ddlStatus.DataTextField = "Value";
                //ddlStatus.DataValueField = "Key";
                //ddlStatus.DataBind();



                //rptItem.DataSource = dt;
                //rptItem.DataBind();
                FillControls();
            }
        }
        private void FillControls()
        {
            List<param> pa = new List<param>();
            pa.Add(new param("@ID", proId, SqlDbType.Int, 0, ParameterDirection.Input));
            DataTable dt = Data.GetData("spProductRetrieveById", pa);

            product.InnerHtml = dt.Rows[0]["prod_name"].ToString();
            lblBrand.Text = dt.Rows[0]["brand_name"].ToString();
            lblCategory.Text = dt.Rows[0]["cat_name"].ToString();
            lblPrice.Text = double.Parse(dt.Rows[0]["prod_price"].ToString()).ToString("c");
            lblDescriptionShort.Text = dt.Rows[0]["prod_descriptionShort"].ToString();
            lblDescription.Text = dt.Rows[0]["prod_description"].ToString();
            imgImage.ImageUrl = "images/" + dt.Rows[0]["ImgName"].ToString();
            lblFeatured.Text = (bool)dt.Rows[0]["prod_isFeatured"] ? "Featured Product" : "Not Featured Product";
            switch (int.Parse(dt.Rows[0]["status"].ToString()))
            {
                case 1:
                    lblStatus.Text = "Available";
                    break;
                case 2:
                    lblStatus.Text = "Out of Stock";
                    break;
                case 3:
                    lblStatus.Text = "Back Ordered";
                    break;
                case 4:
                    lblStatus.Text = "Temporarily Available";
                    break;
                case 5:
                    lblStatus.Text = "Discontinued";
                    break;
                default:
                    break;
                    
            }
                           


        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("Cart.aspx?prod_id=" + proId);
        }
    }
}