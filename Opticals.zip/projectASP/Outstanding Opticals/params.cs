﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Outstanding_Opticals
{
    public struct param
    {
        public string name;
        public object value;
        public SqlDbType type;
        public int size;
        public ParameterDirection direction;
        public param(string Name, object Value, SqlDbType Type, int Size, ParameterDirection Direction)
        {
            name = Name;
            value = Value;
            type = Type;
            size = Size;
            direction = Direction;
        }
    }

    public enum Status {
        Available,
        OutOfStock,
        BackOrdered,
        TemporarilyAvailable,
        Discontinued
    }
}