﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Outstanding_Opticals
{
   
    public partial class index : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                FillRpt();
            }
        }

        private void FillRpt()
        {
            List<param> pa = new List<param>();
            
            DataTable dt = Data.GetData("spProductRetrieveFeatured", pa);

            rptFeauredNested.DataSource = dt;
            rptFeauredNested.DataBind();
        }
    }
}